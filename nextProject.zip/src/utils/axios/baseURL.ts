import { BaseUrlType } from '@/utils/axios/types';

const baseURL: BaseUrlType = {
    _baseURL: process.env.NEXT_PUBLIC_APP_BACKEND_URL as string,

    _serviceURL: process.env.NEXT_PUBLIC_APP_BACKEND_URL as string
};

export default baseURL;
