export type BaseUrlType = {
  _baseURL: string,
  _serviceURL: string
}

export type AxiosClientType = {
  type?: 'JSON' | 'formData',
  customRequestHeader?: object
}
