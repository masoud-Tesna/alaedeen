import axios, { AxiosError, AxiosResponse } from 'axios';
import baseURL from './baseURL';

const handleRefreshToken = async (): Promise<String> => {
    const refreshToken = localStorage.getItem('refreshToken');

    try {
        const result: AxiosResponse = await axios.post(`${ baseURL?._serviceURL }/auth/refresh-token`, {
            refreshToken
        });

        localStorage.setItem('accessToken', result?.data?.response?.newAccessToken);

        return Promise.resolve(result?.data?.response?.newAccessToken);

    } catch (error: AxiosError | any) {
        return Promise.reject(new Error(error?.response?.data?.message || 'error in refresh token'));
    }
};
export default handleRefreshToken;
