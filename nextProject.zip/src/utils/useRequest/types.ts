import { MutationOptions, QueryObserverOptions } from '@tanstack/react-query';
import { Method, RawAxiosRequestHeaders } from 'axios';
import { TypeOptions } from 'react-toastify';
import { AxiosClientType } from '@/utils/axios/types';

interface UseRequest {
    // API url
    url: string,
    params?: object,
    method?: Method,
    customRequestHeader?: RawAxiosRequestHeaders
}

export interface RequestUseQuery extends UseRequest, QueryObserverOptions {
    body?: object,
    // response data => res.data.response
    justResponse?: boolean,
}

export interface RequestUseMutation extends UseRequest, MutationOptions {
    formType?: AxiosClientType['type'],
    // show message in mutation request or not (true by default)
    showMessage?: boolean | {
        success?: boolean
        error?: boolean
    },
    // mutation request message type (success by default)
    successMessageType?: TypeOptions,
    // mutation request custom message for success
    customSuccessMessage?: string | null,
    // mutation request message type (success by default)
    errorMessageType?: TypeOptions,
    // mutation request custom message for error
    customErrorMessage?: string | null,
}
