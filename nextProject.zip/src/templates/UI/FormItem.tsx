import { Form, Form as AntdForm, FormItemProps } from 'antd';
import { cloneElement, HTMLAttributes, useState } from 'react';
import { inputRule } from '@/utils/helpers';
import FloatingLabel from './FloatingLabel';

interface IFormItem extends FormItemProps {
    requiredTitle?: boolean,
    requiredMessage?: string,
    requiredJustInSubmit?: boolean,
    noLabel?: boolean,
    required?: boolean,
    inputmode?: HTMLAttributes<HTMLLIElement>['inputMode'],
    maxLength?: number | string | any,
    minLength?: number | string | any,
    max?: number | string | any,
    placeholder?: string,
    floatingLabel?: boolean,
    floatingLabelBg?: string
}

const FormItem = (props: IFormItem) => {
    const formRef = AntdForm.useFormInstance();

    const {
              requiredTitle,
              requiredMessage,
              requiredJustInSubmit,
              noLabel,
              required,
              labelAlign,
              maxLength,
              minLength,
              max,
              extra,
              floatingLabel,
              floatingLabelBg,
              ...rest
          } = props;

    let rules     = props?.rules || [],
        inputmode = props?.inputmode;

    const [ active, setActive ] = useState(false);

    const onBlur = () => {
        setActive(false);
    };

    const onFocus = () => {
        setActive(true);
    };

    const inputWatch = AntdForm.useWatch(props?.name, formRef);

    if (!!props?.required) {
        const validateTrigger = props?.requiredJustInSubmit ? { validateTrigger: 'onBlur' } : {};
        rules                 = [
            ...rules,
            {
                required: true,
                message: props?.requiredMessage || inputRule('required input', { inputName: props?.requiredTitle || props?.label }),
                ...validateTrigger
            }
        ];
    }

    if (props?.minLength) {
        rules = [
            ...rules,
            {
                validator: (_, value) => {
                    if (value?.length && value?.length < props?.minLength) {
                        return Promise.reject(new Error(inputRule('minLength input', {
                            inputName: props?.label,
                            length: props?.minLength
                        })));
                    }

                    return Promise.resolve();
                },
                message: inputRule('minLength input', {
                    inputName: props?.label,
                    length: props?.minLength
                }),
                validateTrigger: 'onBlur'
            }
        ];
    }

    return (
        <Form.Item
            extra={ extra }
            rules={ rules }
            validateFirst
            { ...rest }
            label={ null }
        >
            { floatingLabel ?
                <FloatingLabel
                    active={ active }
                    value={ inputWatch }
                    label={ props?.label }
                    placeholder={ props?.placeholder || props?.label }
                    required={ required }
                    floatingLabelBg={ floatingLabelBg }
                >
                    { cloneElement(props.children as any, { inputName: props?.name }) }
                </FloatingLabel> :
                cloneElement(props.children as any, { inputName: props?.name })
            }

        </Form.Item>
    );
};

FormItem.defaultProps = {
    noLabel: false,
    requiredJustInSubmit: false,
    hiddenLabel: false,
    center: false,
    validateFirst: true,
    labelAlign: 'start',
    required: true,
    floatingLabel: true,
    floatingLabelBg: '#FFFFFF'
};

export { FormItem };