import React, { cloneElement, ReactElement, useState } from 'react';
import { FormItemProps } from 'antd';

import classNames from 'classnames';

type FloatInputTypes = {
    children?: ReactElement;
    active?: boolean;
    value?: any;
    required?: boolean;
    placeholder?: Pick<FormItemProps, 'label'> | any;
    onChange?: Function | unknown,
    floatingLabelBg?: string
};

const FloatingLabel = ({ label, value, placeholder, required, onChange, floatingLabelBg, children }: FloatInputTypes & Pick<FormItemProps, 'label'>) => {
    const [ focus, setFocus ] = useState(false);

    if (!placeholder) placeholder = label;

    const isOccupied = focus || (value && value.length !== 0);

    const labelClass = 'absolute pointer-events-none right-[12px] top-[50%] translate-y-[-50%] transition-all duration-[.2s] ease-in z-10 !text-buttonSm text-primary-shade-8';

    const isOccupiedClass = '!text-captionSm !text-primary-0 !top-0 px-[5px]';

    const requiredMark = (required && isOccupied) ? <span className='text-error-light'>*</span> : null;

    return (
        <div
            className='!relative mt-[8px]'
            onBlur={ () => setFocus(false) }
            onFocus={ () => setFocus(true) }
        >
            { cloneElement(children as any, { onChange: onChange }) }

            <label
                className={ classNames(labelClass, { [isOccupiedClass]: !!isOccupied }) }
                style={ { background: floatingLabelBg } }
            >
                { requiredMark } { isOccupied ? label : placeholder }
            </label>
        </div>
    );
};

export default FloatingLabel;
