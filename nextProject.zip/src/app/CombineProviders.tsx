'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React, { useState } from 'react';
import Entity from '@ant-design/cssinjs/es/Cache';
import { createCache, extractStyle, StyleProvider } from '@ant-design/cssinjs';
import { useServerInsertedHTML } from 'next/navigation';
import { antdConfig } from '@/theme/themeConfig';
import frFR from 'antd/locale/fr_FR';
import { ConfigProvider } from 'antd';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

export default function CombineProviders({ children }: React.PropsWithChildren) {
    const [ queryClient ] = useState(() => new QueryClient());

    const cache = React.useMemo<Entity>(() => createCache(), []);

    useServerInsertedHTML(() => (
        <style
            id='antd'
            dangerouslySetInnerHTML={ { __html: extractStyle(cache, true) } }
        />
    ));

    return (
        <QueryClientProvider client={ queryClient }>
            <StyleProvider cache={ cache }>
                <ConfigProvider
                    theme={ antdConfig }
                    locale={ frFR }
                    direction={ 'rtl' }
                >
                    { children }
                </ConfigProvider>
            </StyleProvider>

            <ReactQueryDevtools />
        </QueryClientProvider>
    );
}
