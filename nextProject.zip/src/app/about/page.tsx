'use client'

import {useState} from 'react';
import {Button} from 'antd';

export default function About() {
  
  const [count, setCount] = useState(0)
  return (
    <div>
      <p>in about - You clicked {count} times</p>
      <Button type="primary" onClick={() => setCount(current => current + 1)}>Button</Button>
    </div>
  )
}
