import React from 'react';
import { Col, Row } from 'antd';

export default function RootLayout({ children }: {
    children: React.ReactNode
}) {
    return (
        <Row
            className='bg-[#405189] h-full'
            justify={ 'center' }
            align={ 'middle' }
        >
            <Col className='w-full !max-w-[500px]'>
                { children }
            </Col>
        </Row>
    );
}
