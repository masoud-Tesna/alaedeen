'use client';

import { FC } from 'react';
import { Button, Checkbox, Col, Form, Input, Row, Spin } from 'antd';
import Image from 'next/image';
import { FormItem } from '@/templates/UI';
import { useRequest } from '@/utils/useRequest';

const Login: FC = () => {

    const [ formRef ] = Form.useForm();

    const request = useRequest();

    const { isLoading, mutateAsync: loginRequest } = request.useMutation({
        url: '/auth/login'
    });

    const handleLogin = async (values: object) => {
        try {
            await loginRequest(values);
        } catch (error) {
            console.log('error in handleLogin >>>', error);
        }
    };

    return (
        <Spin spinning={ isLoading }>
            <Row
                className='bg-white rounded-[8px] shadow-2 pt-[61px] pb-[15px] px-[5%] md:px-[30px] lg:px-[50px]'
                gutter={ [ 0, 24 ] }
            >
                <Col
                    span={ 24 }
                    className='space-y-[16px] [&>div]:text-center'
                >
                    <div>
                        <Image
                            src={ '/images/satpayLogo.svg' }
                            alt='SatPay'
                            width={ 84 }
                            height={ 30 }
                        />
                    </div>

                    <div className='text-primary-0 text-buttonSm'>
                        ورود
                    </div>
                </Col>

                <Col
                    span={ 24 }
                >
                    <Form
                        form={ formRef }
                        name='ulogin'
                        layout='vertical'
                        className='[&>.ant-form-item]:mb-[36px]'
                        onFinish={ handleLogin }
                    >
                        <FormItem
                            name={ 'mobile' }
                            label={ 'شماره موبایل' }
                        >
                            <Input />
                        </FormItem>

                        <FormItem
                            name={ 'password' }
                            label={ 'رمز عبور' }
                        >
                            <Input.Password />
                        </FormItem>

                        <FormItem
                            name={ 'rememberMe' }
                            floatingLabel={ false }
                            required={ false }
                        >
                            <Checkbox>مرا به خاطر بسپار</Checkbox>
                        </FormItem>

                        <Button
                            type='primary'
                            block
                            htmlType='submit'
                        >
                            ورود
                        </Button>
                    </Form>
                </Col>

                <Col
                    span={ 24 }
                    className='text-captionMd'
                >
                    فراموشی رمز عبور؟
                </Col>

                <Col
                    span={ 24 }
                    className='text-captionMd'
                >
                    ثبت نام؟
                </Col>
            </Row>
        </Spin>
    );
};

export default Login;
