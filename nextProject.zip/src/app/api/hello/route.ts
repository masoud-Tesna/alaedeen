import { NextResponse } from 'next/server';
import axios, { AxiosError } from 'axios';

const DATA_SOURCE_URL = 'http://192.168.80.61:3010/api/v1/wallet/micro-transaction?pageNumber=1&rowPage=30&startDate=2023-01-01&endDate=2023-10-10';

export async function GET() {
    try {
        const res = await axios.request({
            url: DATA_SOURCE_URL,
            method: 'get',
            headers: {
                Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtb2JpbGUiOiI5MTAyNzc4Mjg3IiwidXNlcklkIjoiMjAxMjEiLCJpYXQiOjE2OTcwMjI4NjEsImV4cCI6MTY5NzEwOTI2MX0.Egff4DjmlYayjKT-8UVXvmk44-eAPFN114pKpY1s_xE'
            }
        });

        return NextResponse.json(res?.data);
    } catch (error: AxiosError | any) {
        return NextResponse.json(error?.response?.data, { status: 400 });
    }

}