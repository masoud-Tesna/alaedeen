'use client';

import { ReactNode } from 'react';
import { Layout } from 'antd';

export default function Template({ children }: { children: ReactNode }) {
    return (
        <Layout className='h-full'>
            <Layout.Content>
                { children }
            </Layout.Content>
        </Layout>
    );
}