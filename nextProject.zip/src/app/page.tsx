'use client';

import React from 'react';
import { Button, Col, Form, Row } from 'antd';
import { Input } from '@/templates/UI/Input';
import { FormItem } from '@/templates/UI/FormItem';

const Home: React.FC = () => {

    return (
        <Row>
            <Col
                span={ 24 }
                className='mt-[50px]'
            >
                <Form
                    size='large'
                    name='user_login'
                    className='login-form'
                    layout='vertical'
                >
                    <FormItem
                        name={ 'salam' }
                        label={ 'salam' }
                        placeholder='placeholder test'
                    >
                        <Input />
                    </FormItem>

                    <Button htmlType='submit'>
                        send
                    </Button>
                </Form>
            </Col>
        </Row>
    );
};

export default Home;
