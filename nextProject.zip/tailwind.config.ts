import type { Config } from 'tailwindcss';
import { tailwindcssConfig } from './src/theme/themeConfig';

const config: Config = {
    corePlugins: {
        preflight: false
    },
    content: [ './src/**/*.{js,jsx,ts,tsx}' ],
    theme: tailwindcssConfig?.theme,
    plugins: []
};

export default config;
