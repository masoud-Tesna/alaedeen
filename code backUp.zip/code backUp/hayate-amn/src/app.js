const { join } = require("path");
const express = require("express");
const commonMiddlewaresWrapper = require("./utils/tools/general/commonWrapper");

const app = express();

require("dotenv").config({ path: `${join(__dirname, "./env/product.env")}` });

commonMiddlewaresWrapper(app);

module.exports = app;
