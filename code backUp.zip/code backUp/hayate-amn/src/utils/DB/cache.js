const NodeCache = require("node-cache");

class Cache {
  catch;
  async init() {
    const ttl = 60 * 60 * 24;
    this.cache = new NodeCache(ttl);
    console.log("NodeCache service is ready");
  }
}
module.exports = new Cache();
