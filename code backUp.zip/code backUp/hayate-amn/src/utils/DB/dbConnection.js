const Sequelize = require("sequelize");
const mongoose = require("mongoose");
const CustomError = require("../tools/general/customError");
const redis = require("redis");

class DbConnector {
  #_DbNameSql;
  #_DbPassSql;
  #_DbUserSql;
  #_DbHostSql;
  #_DbUrlMongo;
  #_DbHostRedis;
  #_DbPassRedis;
  instance;
  client;

  async init() {
    if (
      !process.env.DB_NAME_SQL ||
      !process.env.DB_PASS_SQL ||
      !process.env.DB_USER_SQL ||
      !process.env.DB_HOST_SQL ||
      !process.env.DB_HOST_REDIS ||
      !process.env.DB_PASS_REDIS ||
      !process.env.MONGO_CONNECTION_URL
    )
      throw new CustomError(
        400,
        "Db_name, Db_pass, Db_user , Db_host , Db_passRedis or MONGO_CONNECTION_URL not set in env!"
      );

    this.#_DbNameSql = process.env.DB_NAME_SQL;
    this.#_DbPassSql = process.env.DB_PASS_SQL;
    this.#_DbHostSql = process.env.DB_HOST_SQL;
    this.#_DbUserSql = process.env.DB_USER_SQL;
    this.#_DbHostRedis = process.env.DB_HOST_REDIS;
    this.#_DbPassRedis = process.env.DB_PASS_REDIS;
    this.#_DbUrlMongo = process.env.MONGO_CONNECTION_URL;
    const mongoConnection = await this.connectToMongo();
    const mySqlConnection = await this.connectToSql();
    const redisConnection = await this.connectToRedis();
    if (
      mongoConnection.hasError ||
      mySqlConnection.hasError ||
      redisConnection.hasError
    ) {
      const whichDB = mongoConnection.hasError
        ? mongoConnection
        : mySqlConnection.hasError
        ? mySqlConnection
        : redisConnection;
      throw new CustomError(
        400,
        `${whichDB.db} db connection failed because ${whichDB.desc}`
      );
    }

    console.log("redis, mongo & mySql are connected");
  }

  async connectToMongo() {
    let result = { db: "mongo", hasError: false, desc: "" };
    try {
      await mongoose.connect(this.#_DbUrlMongo);
      console.log("mongo is connected too");
      result.desc = "Connected";
    } catch (error) {
      console.log("mongo connection failed because : " + error);
      result.hasError = true;
      result.desc = error;
    }
    return result;
  }
  async connectToRedis() {
    let result = { db: "redis", hasError: false, desc: "" };
    try {
      this.client = await redis.createClient({
        url: `redis://default:${this.#_DbPassRedis}@${this.#_DbHostRedis}`,
      });
      await this.client.on("error", (err) => {
        throw new CustomError(500, err);
      });
      await this.client.connect();
      console.log("redis is connected too");
      result.desc = "Connected";
    } catch (error) {
      console.log("Redis connection failed because : " + error);
      result.hasError = true;
      result.desc = error;
    }

    return result;
  }

  async connectToSql() {
    let result = { db: "sql", hasError: false, desc: "" };
    try {
      const instance = new Sequelize(
        this.#_DbNameSql,
        this.#_DbUserSql,
        this.#_DbPassSql,
        {
          dialect: "mssql",
          host: this.#_DbHostSql,
          dialectOptions: {
            encrypt: true,
          },
        }
      );
      this.instance = instance;
      await this.instance.sync();
      console.log("sql is connected too");
      result.desc = "Connected";
    } catch (error) {
      console.log("mysql connection failed because : " + error);
      result.hasError = true;
      result.desc = error;
    }

    return result;
  }
}

module.exports = new DbConnector();
