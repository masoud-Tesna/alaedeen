const Temp = require("../../app/model/temp/temp");
const CustomError = require("../tools/general/customError");
module.exports = async (mobile) => {
  try {
    const temp = await Temp.findOne({
      to: mobile,
      otpVerified: false,
    });
    temp.otpVerified = true;
    temp.save;
    if (!temp)
      throw new CustomError(
        400,
        "Mobile with this status was not found in Database"
      );
  } catch (error) {
    throw error;
  }
};
