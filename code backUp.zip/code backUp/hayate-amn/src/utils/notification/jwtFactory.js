const jwt = require("jsonwebtoken");

class TokenGenerator {
  async tokenGenerator(args) {
    let token;
    try {
      const secretKey = process.env.SECRET_KEY;
      token = await jwt.sign({ record: args.record }, secretKey, {
        expiresIn: args.time,
      });
      return token;
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new TokenGenerator();
