const User = require("../../app/model/user/user");
const TokenGenerator = require("./jwtFactory");
const CustomError = require("../tools/general/customError");

module.exports = async (req) => {
  let accessToken;
  let refreshToken;
  let response;
  try {
    const record = req.record || req.body.record;
    if (!record) throw new CustomError(400, `No record was found in req`);
    accessToken = await TokenGenerator.tokenGenerator({
      record: record,
      time: "15m",
    });
    refreshToken = await TokenGenerator.tokenGenerator({
      record: record,
      time: "15d",
    });
    response = { accessToken: accessToken, refreshToken: refreshToken };
    return response;
  } catch (error) {
    throw error;
  }
};
