const utf8 = require("utf8");
const jwt = require("jsonwebtoken");
const CustomError = require("../../utils/tools/general/customError");
const dbConnector = require("../../utils/DB/dbConnection");

class Verifier {
  async verify(args) {
    switch (args.type) {
      case "refreshToken":
      case "accessToken":
      case "email":
        try {
          const decodedToken = jwt.verify(args.token, process.env.SECRET_KEY);
          if (!decodedToken)
            throw new CustomError(
              500,
              "Token is not available, Enter a correct one!"
            );
          return { success: true, data: { to: decodedToken.record } };
        } catch (error) {
          return { success: false, data: error };
        }

      case "sms":
        let client = dbConnector.client;
        let code;
        try {
          const code = await client.get(args.mobile);
          if (code !== args.inputCode) {
            throw new CustomError(422, "Wrong code");
          }
          return {
            success: true,
            data: "You phone number was succesfully verified.",
          };
        } catch (error) {
          return { success: false, data: error };
        }

      default:
        console.log("invalid case");
        break;
    }
  }
}

module.exports = new Verifier();
