const utf8 = require("utf8");
const CustomError = require("../../utils/tools/general/customError");
const dbConnector = require("../../utils/DB/dbConnection");
const { default: axios } = require("axios");
const Cache = require("../DB/cache");

class Notifier {
  #_smsUsername;
  #_smsPassword;
  #_smsFrom;

  async init() {
    if (
      !process.env.SMS_USERNAME ||
      !process.env.SMS_PASSWORD ||
      !process.env.SMS_FROM
    )
      throw new Error("SMS_USERNAME, SMS_PASSWORD or SMS_FROM not set in env!");

    this.#_smsUsername = process.env.SMS_USERNAME;
    this.#_smsPassword = process.env.SMS_PASSWORD;
    this.#_smsFrom = process.env.SMS_FROM;
    console.log("notifier service is ready");
  }

  async templateFactory(template, to) {
    let text;
    let code;
    let client = dbConnector.client;
    switch (template) {
      case "otp":
        code = Math.floor(100000 + Math.random() * 900000);
        text = "کد فعال سازی شما: " + code;
        console.log("here is text: ", text);
        console.log("here is code: ", code);
        try {
          await client.set(to, code);
          await client.expire(to, 120);
        } catch (error) {
          throw error;
        }

        break;
      case "lowCreditWarning":
        text = "Your credit is lower than 100000 rials.";
        const obj = { sent: true };
        const success = Cache.cache.set(`${to}_creditLow:cache`, true);

        break;
      default:
        break;
    }
    return { text, code };
  }

  async send(args) {
    switch (args.type) {
      case "sms":
        try {
          const resp = await this.templateFactory(args.template, args.to);

          const response =
            process.env.NODE_ENV !== "test"
              ? await axios.get(
                  `http://rahyabbulk.ir/url/send.ashx?username=${
                    this.#_smsUsername
                  }&password=${this.#_smsPassword}&from=${this.#_smsFrom}&to=${
                    args.to
                  }&farsi=true&ServiceID=0&ServiceCode=XXX%23XXX&message=${utf8.encode(
                    resp.text
                  )}`
                )
              : {};
          return { success: true, data: response };
        } catch (error) {
          return { success: false, data: error.message };
        }

      default:
        console.log("invalid case");
        break;
    }
  }
}

module.exports = new Notifier();
