const axios = require("axios");
const CustomError = require("../general/customError");

class Transaction {
  #_ipgUser;
  #_ipgPassword;
  #_ipgUserBill;
  #_ipgPasswordBill;
  #_terminalID;

  init() {
    if (
      !process.env.PARDAKHT_NOVIN_IPG_USER ||
      !process.env.PARDAKHT_NOVIN_IPG_PASSWORD ||
      !process.env.PARDAKHT_NOVIN_IPG_USER_BILL ||
      !process.env.PARDAKHT_NOVIN_IPG_PASSWORD_BILL ||
      !process.env.PARDAKHT_NOVIN_IPG_TERMINAL_ID
    )
      throw new Error(
        "USER, PASSWORD, USER_BILL, PASSWORD_BILL or TERMINAL_ID not set in env!"
      );

    this.#_ipgUser = process.env.PARDAKHT_NOVIN_IPG_USER;
    this.#_ipgPassword = process.env.PARDAKHT_NOVIN_IPG_PASSWORD;
    this.#_ipgUserBill = process.env.PARDAKHT_NOVIN_IPG_USER_BILL;
    this.#_ipgPasswordBill = process.env.PARDAKHT_NOVIN_IPG_PASSWORD_BILL;
    this.#_terminalID = process.env.PARDAKHT_NOVIN_IPG_TERMINAL_ID;
    console.log("transaction service is ready");
  }

  async merchantLogin(args) {
    try {
      const response = await axios({
        url: "https://pna.shaparak.ir/ref-payment2/RestServices/mts/merchantLogin/",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          UserName: this.#_terminalID,
          Password: this.#_ipgPassword,
        },
      });

      if (response.data.Result === "erSucceed") {
        return { status: response.data.Result, data: response.data };
      } else {
        throw new CustomError(400, response.data.Result);
      }
    } catch (err) {
      throw err;
    }
  }
  // { WSContext: { SessionId: 'LHR4jn64xpx0//wLpAr3SqOY+QrhW5x4' },
  // 0|server  |   TransType: 'EN_GOODS',
  // 0|server  |   ReserveNum: '8506551759',
  // 0|server  |   TerminalId: '',
  // 0|server  |   Amount: '1260',
  // 0|server  |   ProductId: '',
  // 0|server  |   GoodsReferenceID: '',
  // 0|server  |   MerchatGoodReferenceID: '',
  // 0|server  |   RedirectUrl:
  // 0|server  |    'https://tga.refahbon.com:443/dev/api/ipg/verifyToken/ourApp',
  // 0|server  |   MobileNo: '09102972559',
  // 0|server  |   Email: '',
  // 0|server  |   UserId: '18508',
  // 0|server  |   BillInfoList: [ { BillId: '', PayId: '', BillAmount: '' } ],
  // 0|server  |   ThpServiceId: '' }
  async generateTransactionDataToSign(args) {
    try {
      const response = await axios({
        url: "https://pna.shaparak.ir/ref-payment2/RestServices/mts/generateTransactionDataToSign/",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          WSContext: { SessionId: args.merchantLoginSessionId },
          TransType: "EN_GOODS",
          ReserveNum: args.orderID,
          TerminalId: null,
          Amount: args.amount,
          ProductId: null,
          GoodsReferenceID: null,
          MerchatGoodReferenceID: null,
          RedirectUrl:
            // `https://${process.env.PRODUCT_MODE === "NO"? "ms.local": "micro.satpay.ir"}/api/payment/back`,
            // `https://dev3.satpay.ir/api/payment/callback`,
            `http://pishkhan.local:4012/payment/callback`,
          MobileNo: args.mobile,
          Email: null,
          UserId: args.userId,
          BillInfoList: [
            {
              BillId: null,
              PayId: null,
              BillAmount: null,
            },
          ],
          ThpServiceId: null,
        },
      });

      if (response.data.Result === "erSucceed") {
        return { status: response.data.Result, data: response.data };
      } else {
        throw new CustomError(400, response.data.Result);
      }
    } catch (err) {
      throw err;
    }
  }

  async generateSignedDataToken(args) {
    try {
      const response = await axios({
        url: "https://pna.shaparak.ir/ref-payment2/RestServices/mts/generateSignedDataToken/",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          WSContext: { SessionId: args.merchantLoginSessionId },
          UniqueId: args.generateTransactionDataToSignUniqueId,
          Signature: args.generateTransactionDataToSignDataToSign,
        },
      });

      if (response.data.Result === "erSucceed") {
        return { status: response.data.Result, data: response.data };
      } else {
        throw new CustomError(400, response.data.Result);
      }
    } catch (err) {
      throw err;
    }
  }

  async inquiryMerchantToken(args) {
    try {
      console.log("yyyyyy=>", args.merchantLoginSessionId);
      const response = await axios({
        url: "https://pna.shaparak.ir/ref-payment2/RestServices/mts/inquiryMerchantToken/",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          WSContext: {
            SessionId: args.merchantLoginSessionId,
            // UserId: this.#_terminalID,
            // Password: this.#_ipgPassword,
          },
          Token: args.generateSignedDataTokentoken,
        },
      });

      if (response.data.Result === "erSucceed") {
        console.log("here is the reult#####", response.data.Result);

        return { status: response.data.Result, data: response.data };
      } else {
        throw new CustomError(400, response.data.Result);
      }
    } catch (err) {
      throw err;
    }
  }

  async verifyMerchantTrans(args) {
    try {
      const response = await axios({
        url: "https://pna.shaparak.ir/ref-payment2/RestServices/mts/verifyMerchantTrans/",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          WSContext: { SessionId: args.merchantLoginSessionId },
          RefNum: args.inquiryMerchantTokenRefNum,
          Token: args.generateSignedDataTokentoken,
        },
      });

      if (response.data.Result === "erSucceed") {
        return { status: response.data.Result, data: response.data };
      } else {
        throw new CustomError(400, response.data.Result);
      }
    } catch (err) {
      throw err;
    }
  }

  async merchantLogout(args) {
    try {
      const response = await axios({
        url: "https://pna.shaparak.ir/ref-payment2/RestServices/mts/merchantLogout/",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          SessionId: args.merchantLoginSessionId,
        },
      });
      if (response.data.Result === "erSucceed") {
        return { status: response.data.Result, data: response.data };
      } else {
        throw new CustomError(400, response.data.Result);
      }
    } catch (err) {
      throw err;
    }
  }
}
module.exports = new Transaction();
