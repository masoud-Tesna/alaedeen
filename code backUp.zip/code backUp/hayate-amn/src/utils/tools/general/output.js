module.exports = (req, res, status, data) => {
  const output = { status: status, data: data };
  res.status(req.status || 200).json({ output });
  return output;
};
