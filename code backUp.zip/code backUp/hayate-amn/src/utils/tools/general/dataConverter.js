const crypto = require("crypto");
const CutomError = require("./customError");

exports.encrypt = async (textToEncode, keyString, ivString) => {
  try {
    let key = new Buffer(keyString.substring(0, 8));
    let iv = new Buffer(JSON.parse(ivString));
    let cipher = crypto.createCipheriv("des-cbc", key, iv);
    let crypted = cipher.update(textToEncode, "utf8", "base64");
    crypted += cipher.final("base64");
    return crypted;
  } catch (error) {
    throw error;
  }
};

exports.decrypt = async (textToDecode, keyString, ivString) => {
  try {
    let key = new Buffer(keyString.substring(0, 8));
    let iv = new Buffer(JSON.parse(ivString));
    let decipher = crypto.createDecipheriv("des-cbc", key, iv);
    let decrypted = decipher.update(textToDecode, "base64", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  } catch (error) {
    throw error;
  }
};
