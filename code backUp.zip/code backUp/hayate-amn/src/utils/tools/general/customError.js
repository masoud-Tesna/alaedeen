class CutomError extends Error {
  message;
  statusCode;
  constructor(statusCode, message) {
    super(message);
    this.message = message;
    this.statusCode = statusCode || 500;
  }
}
module.exports = CutomError;
