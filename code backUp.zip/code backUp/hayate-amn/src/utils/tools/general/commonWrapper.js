const errorController = require("../../../app/http/request/error-handler/error-handler");
const userRoutes = require("../../../routes/user/user");
const insRoutes = require("../../../routes/insurance/insurance");
const transactionRoutes = require("../../../routes/transaction-routes/transaction-routes");
const express = require("express");
const { join } = require("path");
const cors = require("cors");

module.exports = (app, baseURL) => {
  app.use(express.json());
  app.use(cors());
  app.use(
    // baseURL ||
    "/user",
    userRoutes
  );
  app.use(
    // baseURL ||
    "/insurance",
    insRoutes
  );
  app.use(
    // baseURL ||
    "/transaction",
    transactionRoutes
  );
  app.use(errorController.errorHandler);
  app.use("*", errorController.errorHandler404);
};
