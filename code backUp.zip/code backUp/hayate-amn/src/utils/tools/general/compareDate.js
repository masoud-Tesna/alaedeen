const CustomError = require("./customError");

module.exports = (date1, date2, statusCode, message) => {
  if (new Date(date1).getTime() >= new Date(date2).getTime()) {
    return true;
  } else {
    throw new CustomError(statusCode, message);
  }
};
