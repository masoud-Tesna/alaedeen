const Insurance = require("../../../app/model/insurance/insurance");
module.exports = async (insurance) => {
  try {
    const resp = await Insurance.insertInsuranceSql(insurance);
    return resp;
  } catch (error) {
    console.log(error);
    throw error;
  }
};
