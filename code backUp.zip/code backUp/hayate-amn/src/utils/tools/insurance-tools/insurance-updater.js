const Insurance = require("../../../app/model/insurance/insurance");
module.exports = async (transaction) => {
  const insuranceId = transaction.insuranceId;
  try {
    const insurance = await findById(insuranceId);
    insurance.transactionId = transaction.id;
    insurance.orderid = transaction.orderID;
    insurance.registered = new Date().getTime();
    insurance.save();
    return insurance;
  } catch (error) {
    throw error;
  }
};
