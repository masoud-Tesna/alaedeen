const Insurance = require("../../../app/model/insurance/insurance");
const User = require("../../../app/model/user/user");

module.exports = async (user) => {
  try {
    const resp = await User.loadListInventorySql({
      record: user.record,
      pageNumber: 1,
      rowsPage: 1,
    });
    const id = resp[0][0].id;
    return id;
  } catch (error) {
    throw error;
  }
};
