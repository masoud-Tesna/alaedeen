const errorHandler = require("../../app/http/request/error-handler/error-handler");
const controllerOtpCenter = require("../../app/http/controller/otp-center/otp");
const duplicateUserController = require("../../app/http/request/otp-center/duplicate-user-controller");
const duplicateRecordController = require("../../app/http/request/authentication-center/register/duplicate-user");
const loginMobileUserFinder = require("../../app/http/request/authentication-center/login/user-finder");
const requestOtpCenter = require("../../app/http/request/otp-center/otp-verification");
const express = require("express");
const userController = require("../../app/http/controller/user/user");
const sanitize = require("../../app/http/request/sanitization-center/authentication/authentication");

const isAuth = require("../../app/http/request/authentication-center/general/isAuth");
const getUserData = require("../../app/http/request/authentication-center/general/get-user-data");
const checkRole = require("../../app/http/request/authentication-center/general/check-role");

const router = express.Router();
// router.post(
//   "/send-otp",
//   sanitizedAuthentication.sendSMS,
//   errorHandler.errorHandlerExpressValidator,
//   duplicateUserController.uniqueMobileController,
//   controllerOtpCenter.sendSMS
// );

router.post(
  "/check-otp",
  sanitize.checkSMS,
  errorHandler.errorHandlerExpressValidator,
  requestOtpCenter.checkSMS
);

router.post(
  "/register",
  sanitize.signUp,
  errorHandler.errorHandlerExpressValidator,
  duplicateRecordController,
  duplicateUserController.uniqueMobileController,
  userController.signup
);

router.post("/send-otp", userController.sendSMS);

router.post(
  "/login/sms/send",
  sanitize.sendSMS,
  errorHandler.errorHandlerExpressValidator,
  loginMobileUserFinder.userFinder,
  controllerOtpCenter.sendSMS
);

router.post(
  "/login/sms/check",
  sanitize.checkSMS,
  errorHandler.errorHandlerExpressValidator,
  requestOtpCenter.checkSMS,
  userController.smsLoginSecondLevel
);

router.post(
  "/login",
  // TODO sanitize it
  sanitize.login,
  errorHandler.errorHandlerExpressValidator,
  userController.login
);
router.post(
  "/insert-inventory",
  sanitize.updateUser,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  userController.updateUser
);

router.get(
  "/list-user",
  sanitize.loadListInventory,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  checkRole,
  userController.listUser
);
router.get(
  "/load-list-inventory",
  sanitize.loadListInventory,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  checkRole,
  userController.loadListInventory
);

router.post("/refresh-token", userController.refreshToken);

module.exports = router;
