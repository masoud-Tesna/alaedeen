const errorHandler = require("../../app/http/request/error-handler/error-handler");
const transactionController = require("../../app/http/controller/transaction/transaction");
const findTransactionRequest = require("../../app/http/request/transaction/find-transaction");
const findUserRequest = require("../../app/http/request/transaction/find-user");
const getUserData = require("../../app/http/request/authentication-center/general/get-user-data");
const isAuth = require("../../app/http/request/authentication-center/general/isAuth");
const initInsurance = require("../../app/http/request/insurance/init-insurance");
const express = require("express");
//
//
//
//
//
//
const sanitizedTransaction = require("../../app/http/request/sanitization-center/transaction/transaction");
//
//
//
//
//
//
const router = express.Router();
//
//
//
//
//
router.get("/ipgOpen", (req, res) => {
  res.render("ipg", { Token: req.query.token });
});

router.post(
  "/payment",
  isAuth,
  // after is auth email of the user is forwarded
  getUserData,
  // here with the email the user would be found and forwarded! so it can be read in transaction controller
  //   checkCredit,
  // sanitizedTransaction.transaction,
  errorHandler.errorHandlerExpressValidator,
  findUserRequest,
  // initInsurance,
  transactionController.IPGController
);

router.all(
  "/payment/callback",
  // isAuth,
  // checkCredit,
  //errorHandler.errorHandlerExpressValidator,
  findTransactionRequest.transactionFinder,
  transactionController.IPGCallBack
);

module.exports = router;
