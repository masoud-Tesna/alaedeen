const errorHandler = require("../../app/http/request/error-handler/error-handler");
const express = require("express");
const insController = require("../../app/http/controller/insurance/insurance");
const sanitize = require("../../app/http/request/sanitization-center/insurance/insurance");

const isAuth = require("../../app/http/request/authentication-center/general/isAuth");
const getUserData = require("../../app/http/request/authentication-center/general/get-user-data");
const checkRole = require("../../app/http/request/authentication-center/general/check-role");

const router = express.Router();

router.post(
  "/create-insurance",
  sanitize.createInsurance,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  insController.createInsurance
);

router.post(
  "/insert-insurance",

  // errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  insController.insertInsurance
);
router.get(
  "/load-list-insurance",
  sanitize.loadlistInsurance,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  checkRole,
  insController.loadlistInsurance
);

router.get(
  "/load-insurance-user",
  sanitize.loadlistInsurance,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  insController.loadUserInsurances
);

router.get(
  "/load-insurance-available",
  sanitize.loadlistInsurance,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  insController.loadUserAvaialableInsurances
);

router.post(
  "/check-type",
  sanitize.loadlistInsurance,
  errorHandler.errorHandlerExpressValidator,
  isAuth,
  getUserData,
  insController.checkRepetativeInsurance
);

module.exports = router;
