const Insurance = require("../../../model/insurance/insurance");

module.exports = async (req, res, next) => {
  const { amount } = req.body;
  const user = req.user;
  try {
    const insurance = await Insurance.build({
      userId: user._id,
      transactionId,
      record,
      fname,
      lname,
      dname,
      relationship,
      phone: user.phone,
      mobile: user.mobile,
      started,
      stoped,
      number,
      type,
      tax,
      charge,
      health,
      pure,
      cost: amount,
      registered,
      orderid: orderID,
      bill,
      fullnumber,
      issueby,
      WitchPaymentBankOrderid,
      FK_InventoryID,
    }).save();
    req.insurance = insurance;
  } catch (eerror) {
    next(error);
  }
};
