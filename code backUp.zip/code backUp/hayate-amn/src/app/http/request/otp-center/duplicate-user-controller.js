const User = require("../../../model/user/user");
const CustomError = require("../../../../utils/tools/general/customError");

/**
 * Checking if a user with the same mobile number exists or not
 * @param {*} req --> mobile in req.body
 * @param {*} res
 * @param {*} next
 */
exports.uniqueMobileController = async (req, res, next) => {
  const { mobile } = req.body;
  try {
    const user = await User.findOne({ mobile });
    if (user) {
      throw new CustomError(
        422,
        "This Phone Number Has Already Been Taken, Please Enter a new phone number."
      );
    }
    next();
  } catch (err) {
    next(err);
  }
};
