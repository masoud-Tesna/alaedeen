const User = require("../../../model/user/user");
const verifier = require("../../../../utils/notification/verifier");
const tokenSetter = require("../../../../utils/notification/tokenSetter");
const tempUpdater = require("../../../../utils/DB/tempUpdater");
const CustomError = require("../../../../utils/tools/general/customError");
const output = require("../../../../utils/tools/general/output");
const dataConverter = require("../../../../utils/tools/general/dataConverter");

/**
 * Checking SMS
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
exports.checkSMS = async (req, res, next) => {
  let response;
  const key = process.env.KEY;
  const iv = process.env.IV;
  const { inputCode, mobile } = req.body;
  try {
    const { success, data } = await verifier.verify({
      type: "sms",
      mobile: mobile,
      inputCode: inputCode,
    });
    if (!success) throw new CustomError(400, data);
    const encMobile = await dataConverter.encrypt(mobile, key, iv);
    const user = await User.findOne({ mobile: encMobile });
    if (req.url.includes("check-otp")) {
      const resp = await User.createUserSql(user);
      const userInserted = resp[0][0].OK === 1 ? true : false;
      await tempUpdater(mobile);
      response = {
        phoneVerified: true,
        userInserted,
        message: "Your phone number was succesfully verified.",
      };
    }
    if (req.url.includes("login")) {
      req.record = user.record;
      response = await tokenSetter(req);
    }

    output(req, res, 200, response);
  } catch (err) {
    next(err);
  }
};
