const { validationResult } = require("express-validator");
const CustomError = require("../../../../utils/tools/general/customError");
const Log = require("../../../model/log/log");

exports.errorHandlerExpressValidator = (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new CustomError(422, errors.errors[0].msg);
    }
    next();
  } catch (err) {
    next(err);
  }
};

/**
 * Handling each error with making a log out of it
 * @param {*} error
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
exports.errorHandler = async (error, req, res, next) => {
  const status = error.statusCode || 500;
  // The exact time of each error
  const trackId = new Date().getTime();
  // Puting the status of the error in response
  res.status(status).json({
    hasError: true,
    error: error.message + "!",
    trackId,
  });
};
// Handling 404 separately
exports.errorHandler404 = async (req, res, next) => {
  const trackId = await new Date().getTime();
  res.status(404).json({
    hasError: true,
    error: "this url has not been found!",
    trackId,
  });
};
