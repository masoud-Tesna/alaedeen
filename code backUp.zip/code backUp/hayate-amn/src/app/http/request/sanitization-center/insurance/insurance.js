const { check, body } = require("express-validator");
const moment = require("jalali-moment");
moment().locale("fa").format("YYYY/M/D");

exports.createInsurance = [
  check("started")
    .notEmpty()
    .withMessage("started must be provided")
    .custom((val) => {
      const m = new Date(moment.from(val, "fa", "YYYY/MM/DD"));
      var date = Date.parse(m);
      if (isNaN(date)) return false;
      return true;
    })
    .withMessage("started must be in a valid form")
    .trim(),
  check("code")
    .notEmpty()
    .withMessage("code must be provided")
    .isIn([
      190, 290, 390, 490, 1180, 2180, 3180, 4180, 1270, 2270, 3270, 4270, 1360,
      2360, 3360, 4360, 590, 5180, 5270, 5360,
    ])
    .withMessage("code must be in correct form")
    .trim(),
  check("year")
    .notEmpty()
    .withMessage("year must be provided")
    .isLength({ min: 4, max: 4 })
    .withMessage("pageNumber must be a number!")
    .isNumeric()
    .withMessage("pageNumber must be in a valid numeric form!")
    .custom((val) => {
      if (val < 1400) return false;
      return true;
    })
    .withMessage("pageNumber must be in a valid form")
    .trim(),
];
exports.loadlistInsurance = [
  check("record")
    .optional({ nullable: true, checkFalsy: true })
    .isNumeric()
    .withMessage("Record must be in numeric form")
    .isLength({ min: 8, max: 12 })
    .withMessage("Record number should be between 8 to 12 digits")
    .trim(),

  check("FK_InventoryID")
    .optional({ nullable: true, checkFalsy: true })
    .isLength({ min: 1, max: 6 })
    .withMessage("FK_InventoryID must be a number!")
    .isNumeric()
    .withMessage("FK_InventoryID must be in a valid numeric form!")
    .custom((val) => {
      if (val < 0) return false;
      return true;
    })
    .withMessage("FK_InventoryID must be in a valid form")
    .trim(),
  check("startedsDate")
    .optional({ nullable: true, checkFalsy: true })
    .custom((val) => {
      const m = new Date(moment.from(val, "fa", "YYYY/MM/DD"));
      var date = Date.parse(m);
      if (isNaN(date)) return false;
      return true;
    })
    .withMessage("startedsDate must be in a valid form")
    .trim(),
  check("startedeDate")
    .optional({ nullable: true, checkFalsy: true })
    .custom((val) => {
      const m = new Date(moment.from(val, "fa", "YYYY/MM/DD"));
      var date = Date.parse(m);
      if (isNaN(date)) return false;
      return true;
    })
    .withMessage("startedeDate must be in a valid form")
    .trim(),
  check("stopedsDate")
    .optional({ nullable: true, checkFalsy: true })
    .custom((val) => {
      const m = new Date(moment.from(val, "fa", "YYYY/MM/DD"));
      var date = Date.parse(m);
      if (isNaN(date)) return false;
      return true;
    })
    .withMessage("stopedsDate must be in a valid form")
    .trim(),
  check("stopedeDate")
    .optional({ nullable: true, checkFalsy: true })
    .custom((val) => {
      const m = new Date(moment.from(val, "fa", "YYYY/MM/DD"));
      var date = Date.parse(m);
      if (isNaN(date)) return false;
      return true;
    })
    .withMessage("stopedeDate must be in a valid form")
    .trim(),
];
