const { check, body } = require("express-validator");

exports.transaction = [
  body("amount")
    .notEmpty()
    .withMessage("Amount must be provided")
    .isLength({ min: 4, max: 10 })
    .withMessage("Amount must be more than 4 and less than 10 digits!")
    .isNumeric()
    .withMessage("Please enter a valid amount."),
  body("cardNumber")
    .notEmpty()
    .withMessage("Card number must be provided")
    .isCreditCard()
    .withMessage("Card number must be in a valid card number form.")
    .trim(),
];