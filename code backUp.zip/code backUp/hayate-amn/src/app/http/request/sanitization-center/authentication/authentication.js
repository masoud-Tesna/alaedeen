const { check, body } = require("express-validator");

exports.sendSMS = [
  body("mobile")
    .notEmpty()
    .withMessage("Phone number must be provided")
    .isLength({ min: 11, max: 11 })
    .withMessage("Phone number must be 11 digits!")
    .isNumeric()
    .withMessage("Phone number must be in a valid numeric form!"),
];

exports.checkSMS = [
  check("mobile")
    .notEmpty()
    .withMessage("Phone number must be provided")
    .isLength({ min: 11, max: 11 })
    .withMessage("Phone number must be 11 digits!")
    .isNumeric()
    .withMessage("Phone number must be in a valid numeric form!"),
  check("inputCode")
    .notEmpty()
    .withMessage("Code must be provided")
    .isLength({ min: 6, max: 6 })
    .withMessage("Code must be a 6 digit number!")
    .isNumeric()
    .withMessage("Code must be in a valid numeric form!")
    .trim(),
];

exports.signUp = [
  body("record")
    .notEmpty()
    .withMessage("Record must be provided")
    .isNumeric()
    .withMessage("Record must be in numeric form")
    .isLength({ min: 8, max: 12 })
    .withMessage("Record number should be between 8 to 12 digits")
    .trim(),
  body("password")
    .notEmpty()
    .withMessage("Password must be provided")
    .isLength({ min: 8 })
    .withMessage("Password must be more than 8 characters!")
    .isAlphanumeric()
    .withMessage("Password must be a combination of number and alphabet.")
    .trim(),
  body("userName")
    .notEmpty()
    .withMessage("User name must be provided")
    .isString()
    .withMessage("User name must be in a valid form")
    .isLength({ min: 5 })
    .withMessage("Please Enter your user name!")
    .trim(),
  check("mobile")
    .notEmpty()
    .withMessage("Phone number must be provided")
    .isMobilePhone()
    .isLength({ min: 11, max: 11 })
    .withMessage("Phone number must be 11 digits!")
    .isNumeric()
    .withMessage("Phone number must be a valid number!"),
];

exports.updateUser = [
  body("fname")
    .notEmpty()
    .withMessage("First name must be provided")
    .isString()
    .withMessage("First name must be in a valid form")
    .isLength({ min: 3 })
    .withMessage("Please Enter your First name!")
    .trim(),
  body("lname")
    .notEmpty()
    .withMessage("Last name must be provided")
    .isString()
    .withMessage("Last name must be in a valid form")
    .isLength({ min: 3 })
    .withMessage("Please Enter your Last name!")
    .trim(),
  body("dname")
    .notEmpty()
    .withMessage("Father's name must be provided")
    .isString()
    .withMessage("Father's name must be in a valid form")
    .isLength({ min: 3 })
    .withMessage("Please Enter your Father's name!")
    .trim(),
  body("relationship")
    .notEmpty()
    .withMessage("relationship must be provided")
    .isString()
    .withMessage("relationship must be in a valid form")
    .trim(),
  body("head")
    .notEmpty()
    .withMessage("head must be provided")
    .isBoolean()
    .withMessage("relationship must be in a valid form")
    .trim(),
  body("sex")
    .notEmpty()
    .withMessage("Gender must be provided")
    .isString()
    .withMessage("Gender must be in a valid form")
    .isIn(["female", "male"])
    .withMessage("User should be either male or female")
    .trim(),
  check("phone")
    .notEmpty()
    .withMessage("Phone number must be provided")
    .isMobilePhone()
    .isLength({ min: 11, max: 11 })
    .withMessage("Phone number must be 11 digits!")
    .isNumeric()
    .withMessage("Phone number must be a valid number!"),
  body("addr_province")
    .isString()
    .withMessage("Address province must be in a valid form")
    .trim(),
  body("addr_town")
    .isString()
    .withMessage("Address town must be in a valid form")
    .trim(),
  body("addr_city")
    .isString()
    .withMessage("Address city must be in a valid form")
    .trim(),
  body("addr_village")
    .isString()
    .withMessage("Address village must be in a valid form")
    .trim(),
  body("addr_street")
    .isString()
    .withMessage("Address street must be in a valid form")
    .trim(),
  body("addr_description")
    .isString()
    .withMessage("Address description must be in a valid form")
    .trim(),
  body("addr_alley")
    .isString()
    .withMessage("Address alley must be in a valid form")
    .trim(),
  body("addr_no")
    .isString()
    .withMessage("Address number must be in a valid form")
    .trim(),
  body("addr_floor")
    .isString()
    .withMessage("Address floor must be in a valid form")
    .trim(),
  body("addr_unit")
    .isString()
    .withMessage("Address unit must be in a valid form")
    .trim(),
  body("addr_postcode")
    .isString()
    .withMessage("Address postcode must be in a valid form")
    .trim(),
  body("birth_date")
    .notEmpty()
    .withMessage("birth_date must be provided")
    .custom((val) => {
      const m = new Date(moment.from(val, "fa", "YYYY/MM/DD"));
      var date = Date.parse(m);
      if (isNaN(date)) return false;
      return true;
    })
    .withMessage("birth_date must be in a valid form")
    .trim(),
  body("nationality")
    .notEmpty()
    .withMessage("nationality must be provided")
    .isString()
    .withMessage("Nationality must be in a valid form")
    .trim(),
  body("EmploymentStatus")
    .notEmpty()
    .withMessage("EmploymentStatus must be provided")
    .isString()
    .isString()
    .withMessage("EmploymentStatus must be in a valid form")
    .trim(),
];
exports.login = [
  body("record")
    .notEmpty()
    .withMessage("Record must be provided")
    .isNumeric()
    .withMessage("Record must be in numeric form")
    .isLength({ min: 8, max: 12 })
    .withMessage("Record number should be between 8 to 12 digits")
    .trim(),
  body("password")
    .notEmpty()
    .withMessage("Password must be provided")
    .isLength({ min: 8 })
    .withMessage("Password must be more than 8 characters!")
    .isAlphanumeric()
    .withMessage("Password must be a combination of number and alphabet.")
    .trim(),
];
exports.loadListInventory = [
  check("record")
    .optional({ nullable: true, checkFalsy: true })
    .isNumeric()
    .withMessage("Record must be in numeric form")
    .isLength({ min: 8, max: 12 })
    .withMessage("Record number should be between 8 to 12 digits")
    .trim(),
  check("pageNumber")
    .notEmpty()
    .withMessage("pageNumber must be provided")
    .isLength({ min: 1, max: 6 })
    .withMessage("pageNumber must be a number!")
    .isNumeric()
    .withMessage("pageNumber must be in a valid numeric form!")
    .custom((val) => {
      if (val < 0) return false;
      return true;
    })
    .withMessage("pageNumber must be in a valid form")
    .trim(),
  check("rowsPage")
    .notEmpty()
    .withMessage("rowsPage must be provided")
    .isLength({ min: 1, max: 6 })
    .withMessage("rowsPage must be a number!")
    .isNumeric()
    .withMessage("rowsPage must be in a valid numeric form!")
    .custom((val) => {
      if (val < 0) return false;
      return true;
    })
    .withMessage("rowsPage must be in a valid form")
    .trim(),
];
