const Transaction = require("../../../model/transaction/transaction");
const CustomError = require("../../../../utils/tools/general/customError");

exports.transactionFinder = async (req, res, next) => {
  const { ipgToken } = req.body;
  try {
    console.log("xxxxx=>", req.body);
    const findedTransaction = await Transaction.findOne({ IPGToken: ipgToken });

    if (!findedTransaction) {
      throw new CustomError(
        404,
        "The required transaction does not exist in the database, Please try again."
      );
    }
    req.findedtr = findedTransaction;
    next();
  } catch (err) {
    next(err);
  }
};
