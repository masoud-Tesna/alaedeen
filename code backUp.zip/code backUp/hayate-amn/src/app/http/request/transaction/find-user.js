const User = require("../../../model/user/user");
const CustomError = require("../../../../utils/tools/general/customError");

module.exports = async (req, res, next) => {
  const { mobile } = req.body;
  try {
    const existingUser = await User.findOne({ mobile });
    if (!existingUser) {
      throw new CustomError(
        422,
        "The mobile number you entered does not exsit, Please enter a valid one."
      );
    }
    req.findedUser = existingUser;
    next();
  } catch (err) {
    next(err);
  }
};
