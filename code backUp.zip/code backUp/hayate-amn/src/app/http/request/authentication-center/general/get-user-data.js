const Verifier = require("../../../../../utils/notification/verifier");
const CustomError = require("../../../../../utils/tools/general/customError");
const User = require("../../../../model/user/user");
const output = require("../../../../../utils/tools/general/output");

/**
 * Retriving data from access token
 * @param {*} req
 * all the data needed is in the req.currentUserRecord
 * @param {*} res
 * @param {*} next
 * Having reord we find the user by searching in mongo DB
 * store information in req.user
 */

module.exports = async (req, res, next) => {
  const record = req.currentUserRecord;

  try {
    const user = await User.findOne({ record });
    if (!user) throw new CustomError(400, "No user was found");
    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
};
