const bcrypt = require("bcrypt");
const User = require("../../../../model/user/user");
const CustomError = require("../../../../../utils/tools/general/customError");
const dataConverter = require("../../../../../utils/tools/general/dataConverter");

/**
 * Checking if the password and record match
 * @param {*} record
 * @param {*} password
 */

exports.compare = async (record, password) => {
  const key = process.env.KEY;
  const iv = process.env.IV;
  try {
    const encPassword = await dataConverter.encrypt(password, key, iv);
    const user = await User.findOne({ record });
    if (!user) {
      throw new CustomError(422, "Invalid record");
    }
    if (encPassword !== user.password) {
      throw new CustomError(422, "Record and password do not match");
    }
  } catch (err) {
    throw err;
  }
};
