const CustomError = require("../../../../../utils/tools/general/customError");
const User = require("../../../../model/user/user");
const output = require("../../../../../utils/tools/general/output");
/**
 * Checking if the admin is accessing some APIs
 */
module.exports = async (req, res, next) => {
  const user = req.user;
  try {
    if (user.role === "user")
      throw new CustomError(403, "Authorization Error. You are not allowed");
    next();
  } catch (error) {
    next(error);
  }
};
