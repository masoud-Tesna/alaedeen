const Verifier = require("../../../../../utils/notification/verifier");
const CustomError = require("../../../../../utils/tools/general/customError");

/**
 * Checking if the token is valid
 * @param {*} req
 * @param {*} res
 * @param {*} next
 * accessToken is sent by header with Bearer mode then we check the validity of the token
 */
module.exports = async (req, res, next) => {
  try {
    const token = req.header("Authorization").split(" ")[1];
    if (!token) throw new CustomError(401, "Not Authenticated");
    const { success, data } = await Verifier.verify({
      type: "accessToken",
      token: token,
    });
    if (!success) throw new CustomError(401, "Access Token is expired");
    const record = data.to;
    req.currentUserRecord = record;

    next();
  } catch (error) {
    next(error);
  }
};
