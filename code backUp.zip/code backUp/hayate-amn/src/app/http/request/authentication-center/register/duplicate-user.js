const CustomError = require("../../../../../utils/tools/general/customError");
const User = require("../../../../model/user/user");

/**
 * Checking if the record has been submitted before in the mongo
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
module.exports = async (req, res, next) => {
  const { record } = req.body;
  try {
    // const existingUser = await user.mobileCheckerLogin({ mobile });
    const existingUser = await User.findOne({ record });
    if (existingUser) throw new CustomError(422, "The record already exists");
    next();
  } catch (err) {
    next(err);
  }
};
