const CustomError = require("../../../../../utils/tools/general/customError");
const User = require("../../../../model/user/user");
/**
 * Finding the user by the mobile phone
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
exports.userFinder = async (req, res, next) => {
  const { mobile } = req.body;
  try {
    // const existingUser = await user.mobileCheckerLogin({ mobile });
    const existingUser = await User.findOne({ mobile });
    if (!existingUser) {
      throw new CustomError(
        422,
        "The mobile number you entered does not exsit, Please enter a valid one."
      );
    }
    next();
  } catch (err) {
    next(err);
  }
};
