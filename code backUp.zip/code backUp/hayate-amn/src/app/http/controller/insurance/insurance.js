const output = require("../../../../utils/tools/general/output");
const compareDate = require("../../../../utils/tools/general/compareDate");
const CustomError = require("../../../../utils/tools/general/customError");
const Insurance = require("../../../model/insurance/insurance");
const inventoryIdFinder = require("../../../../utils/tools/insurance-tools/Inventory-id-finder");
const costs = require("../../../../misc/costs");
const dataConverter = require("../../../../utils/tools/general/dataConverter");
const moment = require("jalali-moment");
moment().locale("fa").format("YYYY/M/D");

/*
  This Api is creating Insurance but this is the initial step for creating insurance
  inputs in body of request:
    1. started date for beginning of the insurance
    2. code of the desired insurance ---> misc ---> costs
    3. starting year 
  
  For calculating duration and defining cost and type the insurance we use info in ---> misc ---> costs
  Be careful dates should be saved in persian and Shamsi format
  The stopped date for stoping insurance is calculated by duration
  The ID which user is known by in the sql data base, is derived 

*/

exports.createInsurance = async (req, res, next) => {
  try {
    const key = process.env.KEY;
    const iv = process.env.IV;
    // the user who is creating insurance should be identified because the id is essential
    const user = req.user;
    const { started, code, year } = req.body;

    // Duration, cost, type and stop date are important
    const duration = costs[code].duration;
    const cost = costs[code].cost;
    const type = costs[code].type;

    // const starteddate = new Date(started);
    const starteddate = new Date(moment.from(started, "fa", "YYYY/MM/DD"));

    // Checking if start date of the insurance is greater than now
    const validDate = compareDate(
      starteddate,
      new Date(),
      422,
      "StartedDate should be greater than now"
    );

    //Calculation of the stop date
    Date.prototype.addDays = function (days) {
      const date = new Date(this.valueOf());
      date.setDate(date.getDate() + days);
      return date;
    };
    const stoped = new Date(starteddate.addDays(duration));

    // Finding the ID of the user in sql data base
    const FK_InventoryID = await inventoryIdFinder(user);

    // Inserting the initial copy of the insurance to MongoDb
    const insurance = await Insurance.build({
      userId: user._id,
      record: user.record,
      fname: user.fname,
      lname: user.lname,
      dname: user.dname,
      relationship: user.relationship,
      phone: user.phone,
      mobile: user.mobile,
      started: starteddate.toLocaleDateString("fa-IR-u-nu-latn"),
      stoped: stoped.toLocaleDateString("fa-IR-u-nu-latn"),
      type,
      FK_InventoryID,
      year,
      cost,
    }).save();

    // Output
    output(req, res, 201, {
      insuranceInfo: insurance,
      message: "Initial Copy of insurance has been created",
    });
  } catch (error) {
    next(error);
  }
};

/*
This API is called when the tramsaction for buying the insurance is completed.

  1. First we retrive the user and his/her record in order to find the latest insurance for this user

  2. Then the found insurance should be added to the sql DB.
*/
exports.insertInsurance = async (req, res, next) => {
  const user = req.user;

  try {
    // Finding the user's latest submitted insurance
    const record = req.user.record;
    const insurance = await Insurance.find({ record })
      .sort({ $natural: -1 })
      .limit(1);

    //Inserting the insurance to the Sql DB
    const resp = await Insurance.insertInsuranceSql(insurance[0]);
    output(req, res, 201, {
      data: resp,
    });
  } catch (error) {
    next(error);
  }
};

/*
This API is for Admin
Admin should provide the data for filteration and finding the insurances

filters canbe done based on :
  1. record
  2. started date (E and S date mean the duration that the insurance were started)
  3. stopped date (E and S date mean the duration that the insurance were stopped)
  4. type
  5. FK_InventoryID
  6. pageNumber and rowsPage to see the data more efficiently.

  The next step is to decipher the data received from SQL DB.

  Finally showing the results
*/
exports.loadlistInsurance = async (req, res, next) => {
  const keyH = process.env.KEY;
  const iv = process.env.IV;
  const {
    record,
    startedsDate,
    startedeDate,
    stopedsDate,
    stopedeDate,
    pageNumber,
    rowsPage,
    type,
    FK_InventoryID,
  } = req.query;
  try {
    // Calling the SQL datbase for loading the data
    const resp = await Insurance.loadListInsuranceSql({
      record,
      startedsDate,
      startedeDate,
      stopedsDate,
      stopedeDate,
      pageNumber,
      rowsPage,
      type,
      FK_InventoryID,
    });

    // Deciphering the data
    let insurances = resp[0];
    for (let element of insurances) {
      const index = insurances.indexOf(element);

      for (let [key, value] of Object.entries(element)) {
        if (
          // These items do not need to be deciphered
          value !== null &&
          (key === "fname" ||
            key === "lname" ||
            key === "dname" ||
            key === "phone" ||
            key === "mobile")
        ) {
          try {
            const t = await dataConverter.decrypt(value, keyH, iv);
            insurances[index][key] = t;
          } catch (err) {
            console.log(err.reason);
            next(err);
          }
        }
      }
    }
    output(req, res, 201, {
      insurances,
    });
  } catch (error) {
    console.log(error.reason);
    next(error);
  }
};

/*
This API is called when the user wants to see his/her own insurances.
The filteration criteria are:
  1. pageNumber and rowsPage to see the data more efficiently.
  2. started date (E and S date mean the duration that the insurance were started)
  3. stopped date (E and S date mean the duration that the insurance were stopped)
  4. type
  5. FK_InventoryID
 
*/
exports.loadUserInsurances = async (req, res, next) => {
  const keyH = process.env.KEY;
  const iv = process.env.IV;
  const record = req.user.record;
  const type = "";
  const {
    startedsDate,
    startedeDate,
    stopedsDate,
    stopedeDate,
    pageNumber,
    rowsPage,
    FK_InventoryID,
  } = req.query;
  try {
    const resp = await Insurance.loadListInsuranceSql({
      record,
      startedsDate,
      startedeDate,
      stopedsDate,
      stopedeDate,
      pageNumber,
      rowsPage,
      type,
      FK_InventoryID,
    });
    let insurances = resp[0];
    for (let element of insurances) {
      const index = insurances.indexOf(element);

      for (let [key, value] of Object.entries(element)) {
        if (
          value !== null &&
          (key === "fname" ||
            key === "lname" ||
            key === "dname" ||
            key === "phone" ||
            key === "mobile")
        ) {
          try {
            const t = await dataConverter.decrypt(value, keyH, iv);
            insurances[index][key] = t;
          } catch (err) {
            console.log(err.reason);
            next(err);
          }
        }
      }
    }
    output(req, res, 201, {
      insurances,
    });
  } catch (error) {
    console.log(error.reason);
    next(error);
  }
};
/*
This API shows the available and useable insurances.
*/
exports.loadUserAvaialableInsurances = async (req, res, next) => {
  const keyH = process.env.KEY;
  const iv = process.env.IV;
  const record = req.user.record;
  const {
    pageNumber,
    rowsPage,
    FK_InventoryID,
    startedsDate,
    startedeDate,
    type,
  } = req.query;
  const stopedsDate = new Date();
  Date.prototype.addDays = function (days) {
    const date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
  };
  const stopedeDate = new Date(stopedsDate.addDays(1080));
  try {
    const resp = await Insurance.loadListInsuranceSql({
      record,
      startedsDate,
      startedeDate,
      stopedsDate: stopedsDate.toLocaleDateString("fa-IR-u-nu-latn"),
      stopedeDate: stopedeDate.toLocaleDateString("fa-IR-u-nu-latn"),
      pageNumber,
      rowsPage,
      type,
      FK_InventoryID,
    });
    let insurances = resp[0];
    for (let element of insurances) {
      const index = insurances.indexOf(element);
      for (let [key, value] of Object.entries(element)) {
        if (
          value !== null &&
          (key === "fname" ||
            key === "lname" ||
            key === "dname" ||
            key === "phone" ||
            key === "mobile")
        ) {
          try {
            const t = await dataConverter.decrypt(value, keyH, iv);
            insurances[index][key] = t;
          } catch (err) {
            console.log(err.reason);
            next(err);
          }
        }
      }
    }
    output(req, res, 201, {
      insurances,
    });
  } catch (error) {
    console.log(error.reason);
    next(error);
  }
};
/*
Use this API for checking if the insurance which user wants to register is not repititive
Because we should prevent from user from creating multiple active insurances with the same type
*/
exports.checkRepetativeInsurance = async (req, res, next) => {
  // retriving insurance's and user's data like type and stopped date to check the availability of the insurances
  const record = req.user.record;
  const { code } = req.body;
  const type = costs[code].type;
  const stopedsDate = new Date();
  Date.prototype.addDays = function (days) {
    const date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
  };
  const stopedeDate = new Date(stopedsDate.addDays(1080));
  try {
    //Calling the service to find the matched insurances

    const resp = await Insurance.loadListInsuranceSql({
      record,
      startedsDate: null,
      startedeDate: null,
      stopedsDate: stopedsDate.toLocaleDateString("fa-IR-u-nu-latn"),
      stopedeDate: stopedeDate.toLocaleDateString("fa-IR-u-nu-latn"),
      pageNumber: 1,
      rowsPage: 8,
      type,
      FK_InventoryID: null,
    });
    let insurances = resp[0];
    console.log(insurances);
    //check if an insurance matches with the filters, announce it.
    if (insurances[0])
      throw new CustomError(
        422,
        "There is also a registered insurance with this type"
      );
    output(req, res, 200, { validRequest: true });
  } catch (error) {
    next(error);
  }
};
