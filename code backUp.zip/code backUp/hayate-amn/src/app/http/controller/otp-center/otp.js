const notifier = require("../../../../utils/notification/notifier");
const tokenGenerator = require("../../../../utils/notification/jwtFactory");
const CustomError = require("../../../../utils/tools/general/customError");
const Temp = require("../../../model/temp/temp");
const output = require("../../../../utils/tools/general/output");

/**
 * sendSMS
 * @param {*} req In request we will receive mobile from the body of the req
 * @param {*} res 
 * @param {*} next for the proceding steps 
In this service we will send an OTP to the mobile phone provided
if the environment is test based we won't send OTP 
*/

exports.sendSMS = async (req, res, next) => {
  const { mobile } = req.body;

  try {
    const { success, data } = await notifier.send({
      type: "sms",
      to: mobile,
      template: "otp",
    });

    if (!success) {
      throw new CustomError(400, "otp not send!");
    }
    if (req.url.includes("sendOtp")) {
      const temp = await new Temp({ to: mobile });
      temp.save();
    }
    output(
      req,
      res,
      201,
      process.env.NODE_ENV !== "test" ? "OTP sent." : "It is just a test"
    );
  } catch (err) {
    next(err);
  }
};
