const output = require("../../../../utils/tools/general/output");
const compare = require("../../request/authentication-center/login/find&compare");
const User = require("../../../model/user/user");
const CustomError = require("../../../../utils/tools/general/customError");
const tokenSetter = require("../../../../utils/notification/tokenSetter");
const Verifier = require("../../../../utils/notification/verifier");
const Notifier = require("../../../../utils/notification/notifier");
const tokenGenerator = require("../../../../utils/notification/jwtFactory");
const Temp = require("../../../model/temp/temp");
const dataConverter = require("../../../../utils/tools/general/dataConverter");

/**
 * signup
 * @param {*} req in request we need:
 *  1. userName --> unique
 *  2. record --> unique, the code that is given to immigrants for staying in Iran
 *  3. mobile --> unique
 *  4. password
 * @param {*} res
 * @param {*} next
 *
 * With the data of the req.body initial model of user is created in the mongoDB
 * For verifying the mobile phone, OTP will be sent (6 digit code)
 * If we are in test environment sms won't be sent
 * Temp Model will be saved in order to have a record of mobileNumber
 */

exports.signup = async (req, res, next) => {
  const { userName, record, mobile, password } = req.body;
  try {
    // Creating initial copy of the user
    const user = User.build({
      userName,
      record,
      mobile,
      password,
      role: "user",
    });
    await user.save();

    // Sending OTP
    const { success, data } = await Notifier.send({
      type: "sms",
      to: mobile,
      template: "otp",
    });

    if (!success) {
      throw new CustomError(400, "otp not send!");
    }
    const temp = await new Temp({ to: mobile });
    temp.save();

    // Sending the output
    output(req, res, 201, {
      user,
      otp: process.env.NODE_ENV !== "test" ? "OTP sent." : "It is just a test",
    });
  } catch (err) {
    next(err);
  }
};

/**
 *
 * @param {*} req We shoulde receive parameters below in the body:
 *  1. fname --> first name
 *  2. lname --> last name
 *  3. dname --> father's name
 *  4. category
 *  5. gname (not essential)
 *  6. nname (not essential)
 *  7. head --> the status in the family
 *  8. relationship
 *  9. phone
 *  10. addr_province
 *  11. addr_town
 *  12. addr_city
 *  13. addr_village
 *  14. addr_street
 *  15. addr_description
 *  16. addr_alley
 *  17. addr_no
 *  18. addr_floor
 *  19. addr_unit
 *  20. addr_postcode
 *  21. birth_date
 *  22. nationality
 *  23. sex
 *  24. owner
 *  25. EmploymentStatus
 *  26. EducationPlace
 *  27. IsDelete
 * @param {*} res
 * @param {*} next
 *
 * After receiving information from req.body first we find the user in the mongoDB data base
 * Then we cipher the data with the method and the key and the initial vector(iv) provided --> both are in the process.env
 * We update the user's profile in mongo DB with coded data
 * Then we call the SQL and f=give the user's profile inforamtion to be stored
 *
 */
exports.updateUser = async (req, res, next) => {
  // Defining key and iv
  const key = process.env.KEY;
  const iv = process.env.IV;
  // handling the user which should be updated
  const user = req.user;

  //Retriving the data from body of the request
  const {
    category,
    fname,
    lname,
    dname,
    gname,
    nname,
    head,
    relationship,
    phone,
    addr_province,
    addr_town,
    addr_city,
    addr_village,
    addr_street,
    addr_description,
    addr_alley,
    addr_no,
    addr_floor,
    addr_unit,
    addr_postcode,
    birth_date,
    nationality,
    sex,
    owner,
    EmploymentStatus,
    EducationPlace,
    IsDelete,
  } = req.body;
  try {
    // Updating the mongo with the encrypted data
    const foundUser = await User.findById(user.id);
    foundUser.set({
      category: category
        ? await dataConverter.encrypt(category, key, iv)
        : null,
      fname: fname ? await dataConverter.encrypt(fname, key, iv) : null,
      lname: lname ? await dataConverter.encrypt(lname, key, iv) : null,
      dname: dname ? await dataConverter.encrypt(dname, key, iv) : null,
      gname: gname ? await dataConverter.encrypt(gname, key, iv) : null,
      nname: nname ? await dataConverter.encrypt(nname, key, iv) : null,
      head,
      relationship,
      phone: phone ? await dataConverter.encrypt(phone, key, iv) : null,
      addr_province: addr_province
        ? await dataConverter.encrypt(addr_province, key, iv)
        : null,
      addr_town: addr_town
        ? await dataConverter.encrypt(addr_town, key, iv)
        : null,
      addr_city: addr_city
        ? await dataConverter.encrypt(addr_city, key, iv)
        : null,
      addr_village: addr_village
        ? await dataConverter.encrypt(addr_village, key, iv)
        : null,
      addr_street: addr_street
        ? await dataConverter.encrypt(addr_street, key, iv)
        : null,
      addr_description: addr_description
        ? await dataConverter.encrypt(addr_description, key, iv)
        : null,
      addr_alley: addr_alley
        ? await dataConverter.encrypt(addr_alley, key, iv)
        : null,
      addr_no: addr_no ? await dataConverter.encrypt(addr_no, key, iv) : null,
      addr_floor: addr_floor
        ? await dataConverter.encrypt(addr_floor, key, iv)
        : null,
      addr_unit: addr_unit
        ? await dataConverter.encrypt(addr_unit, key, iv)
        : null,
      addr_postcode: addr_postcode
        ? await dataConverter.encrypt(addr_postcode, key, iv)
        : null,
      birth_date: birth_date
        ? await dataConverter.encrypt(birth_date, key, iv)
        : null,
      nationality: nationality
        ? await dataConverter.encrypt(nationality, key, iv)
        : null,
      sex: sex ? await dataConverter.encrypt(sex, key, iv) : null,
      owner: owner ? await dataConverter.encrypt(owner, key, iv) : null,
      EmploymentStatus: EmploymentStatus
        ? await dataConverter.encrypt(EmploymentStatus, key, iv)
        : null,
      EducationPlace: EducationPlace
        ? await dataConverter.encrypt(EducationPlace, key, iv)
        : null,
      IsDelete: IsDelete
        ? await dataConverter.encrypt(IsDelete, key, iv)
        : null,
    });
    await foundUser.save();
    // Sending the user's profile to SQL DB
    const resp = await User.insertInventorySql(foundUser);
    // If the user has been saved correctly, the repond should be 2
    const updatedUser = resp[0][0].OK === 2 ? true : false;
    output(req, res, 201, { updatedUser, userInfo: foundUser });
  } catch (error) {
    next(error);
  }
};

/**
 *
 * @param {*} req
 * parameters in body of the request:
 * 1. pageNumber
 * 2. rowsPage
 * 3. record
 * @param {*} res
 * @param {*} next
 *
 * These filters are used to retrive user data from SQL database
 */
exports.listUser = async (req, res, next) => {
  const { pageNumber, rowsPage, record } = req.query;
  try {
    const resp = await User.listUserSql({
      record,
      pageNumber,
      rowsPage,
    });
    const users = resp[0];
    output(req, res, 200, {
      users,
    });
  } catch (error) {
    next(error);
  }
};

/**
 *
 * @param {*} req
 * parameters in body of the request:
 * 1. pageNumber
 * 2. rowsPage
 * 3. record
 * @param {*} res
 * @param {*} next
 *
 * Fisrt the filtering criteria are sent in the query
 * Then by calling the SQL DB we get to the data which are not decrypted so we decrypt them
 */
exports.loadListInventory = async (req, res, next) => {
  const keyH = process.env.KEY;
  const iv = process.env.IV;
  // Criteria for filteration
  const { pageNumber, rowsPage, record } = req.query;
  try {
    const resp = await User.loadListInventorySql({
      record,
      pageNumber,
      rowsPage,
    });

    // Decrypting
    const inventories = resp[0];
    for (let element of inventories) {
      const index = inventories.indexOf(element);
      console.log(index);
      for (let [key, value] of Object.entries(element)) {
        if (
          (value !== null) &
          (value !== "null") &
          (key === "fname" ||
            key === "category" ||
            key === "lname" ||
            key === "dname" ||
            key === "mobile" ||
            key === "addr_province" ||
            key === "addr_town" ||
            key === "addr_city" ||
            key === "addr_village" ||
            key === "addr_street" ||
            key === "addr_description" ||
            key === "addr_alley" ||
            key === "addr_no" ||
            key === "addr_floor" ||
            key === "addr_unit" ||
            key === "addr_postcode" ||
            key === "birth_date" ||
            key === "nationality" ||
            key === "sex" ||
            key === "owner" ||
            key === "EmploymentStatus" ||
            key === "EducationPlace" ||
            key === "phone")
        ) {
          try {
            const t = await dataConverter.decrypt(value, keyH, iv);
            inventories[index][key] = t;
          } catch (err) {
            throw err;
          }
        }
      }
    }
    output(req, res, 200, {
      inventories,
    });
  } catch (error) {
    next(error);
  }
};

/**
 *
 * @param {*} req
 * in req.body we have :
 * 1. record
 * 2. password
 * @param {*} res
 * @param {*} next
 * @returns accessToken and refreshToken
 *
 * If password and record match with data in mongo, access and refresh tokens are provided
 * It is checked if the user has inserted complimentary information essential for his/her profile
 */
exports.login = async (req, res, next) => {
  const { record, password } = req.body;
  try {
    await compare.compare(record, password);
    req.record = record;
    const token = await tokenSetter(req);
    const user = await User.findOne({ record });
    console.log(user);
    const resp = await User.loadUserSql({ record, password: user.password });
    if (resp[0][0].OK === 3)
      return output(req, res, 200, {
        message: "Please update your account's information",
        token,
      });
    output(req, res, 200, { userInformation: resp[0][0], token });
  } catch (err) {
    next(err);
  }
};

/**
 * Login with SMS verifying the sent OTP
 * @param {*} req
 * @param {*} res
 * @param {*} next
 * after verifying the OTP we should generate access and refresh tokens
 */
exports.smsLoginSecondLevel = async (req, res, next) => {
  const { mobile } = req.body;
  try {
    const token = await tokenSetter(req, "sms");
    output(req, res, 200, token);
    next();
  } catch (err) {
    next(err);
  }
};

/** Access Token Generator
 *
 * @param {*} req
 * @param {*} res
 * @param {*} next
 *
 * By getting refreshToken in the bos=dy of the request, the access Token will be given
 */
exports.refreshToken = async (req, res, next) => {
  const refreshToken = req.body.refreshToken;

  try {
    const record = (
      await Verifier.verify({ type: "refreshToken", token: refreshToken })
    ).data.to;
    if (!record) {
      throw (error = new CustomError(
        401,
        "Refresh Token expired Please login again"
      ));
    }
    const accessToken = await tokenGenerator.tokenGenerator({
      record: record,
      time: "15min",
    });
    output(req, res, 200, {
      accessToken: accessToken,
      refreshToken: refreshToken,
    });
  } catch (err) {
    next(err);
  }
};

/**
 * Sending SMS
 * @param {*} req
 * req.body --> mobile
 * @param {*} res
 * @param {*} next
 */
exports.sendSMS = async (req, res, next) => {
  const { mobile } = req.body;
  // Sending SMS to the mobile
  try {
    const { success, data } = await Notifier.send({
      type: "sms",
      to: mobile,
      template: "otp",
    });
    // Throwing error in case of not sending the SMS
    if (!success) {
      throw new CustomError(400, "otp not send!");
    }
    // Check if the controller is called for signing up
    if (req.url.includes("send-otp")) {
      const temp = await new Temp({ to: mobile });
      temp.save();
    }
    output(
      req,
      res,
      201,
      process.env.NODE_ENV !== "test" ? "OTP sent." : "It is just a test"
    );
  } catch (err) {
    next(err);
  }
};
