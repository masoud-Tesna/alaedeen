const crypto = require("crypto");
const output = require("../../../../utils/tools/general/output");
const ipg = require("../../../../utils/tools/transaction-tools/IPG");
const Transaction = require("../../../model/transaction/transaction");
const Insurance = require("../../../model/insurance/insurance");
const insuranceUpdater = require("../../../../utils/tools/insurance-tools/insurance-updater");
const inserInsuranceSql = require("../../../../utils/tools/insurance-tools/insert-insurance-sql");

/**
 *
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */

exports.IPGController = async (req, res, next) => {
  try {
    // TODO use get user data in request/authentication center and read the user from that.
    // just put isAuth before its rout and it will work
    console.log("this is the finded user: ", req.findedUser);
    const trackId = new Date().getTime();
    const orderID = crypto.randomBytes(10).toString("hex");
    const userId = req.findedUser._id;
    const amount = insurance.cost;
    // TODO ask how to send insurance from create part to here
    const insurance = req.body.insurance;
    const mobile = req.findedUser.mobile;
    const { cardNumber } = req.body;
    const description = "Credit Recharg!";
    // "The credit have been charged by: " + amount + " Rials and following order ID: "+ orderID;

    try {
      const { status, data } = await ipg.merchantLogin({});
      merchantLoginSessionId = data.SessionId;
    } catch (err) {
      next(err);
    }

    try {
      const { status, data } = await ipg.generateTransactionDataToSign({
        merchantLoginSessionId,
        amount,
        mobile,
        userId,
        orderID,
      });
      generateTransactionDataToSignDataToSign = data.DataToSign;
      generateTransactionDataToSignUniqueId = data.UniqueId;
    } catch (err) {
      next(err);
    }

    try {
      const { status, data } = await ipg.generateSignedDataToken({
        merchantLoginSessionId,
        generateTransactionDataToSignUniqueId,
        generateTransactionDataToSignDataToSign,
      });
      generateSignedDataTokentoken = data.Token;
    } catch (err) {
      next(err);
    }

    const transaction = await Transaction.build({
      userId,
      insuranceId: insurance.id,
      terminalID: process.env.PARDAKHT_NOVIN_IPG_TERMINAL_ID,
      description: description,
      IPGToken: generateSignedDataTokentoken,
      IPGsession: merchantLoginSessionId,
      status: false,
      orderID: orderID,
      trackId: trackId,
      amount: amount,
      cardNumber: null,
      transactionType: "deposit",
    }).save();

     const transactioAli = await new Transaction({
      userId,
      insuranceId: insurance.id,
      terminalID: process.env.PARDAKHT_NOVIN_IPG_TERMINAL_ID,
      description: description,
      IPGToken: generateSignedDataTokentoken,
      IPGsession: merchantLoginSessionId,
      status: false,
      orderID: orderID,
      trackId: trackId,
      amount: amount,
      cardNumber: null,
      transactionType: "deposit",
     });
     await transactioAli.save();
    // TODO check if this procedure is right
    insurance.transactionId = transaction.id;
    insurance.save();
    ipgToken = transaction.IPGToken;
    // TODO Where is refNumber
    const resp = await Transaction.InsertTransactionSqls(
      transaction,
      refNumber
    );
    output(req, res, 201, { transaction, insertSql: resp });
    console.log(transaction);
  } catch (err) {
    next(err);
  }
};

exports.IPGCallBack = async (req, res, next) => {
  //TODO here i shold find the transaction and at last if the process was successful update the status to true.
  // status false = withdrawal
  // status true = deposit

  const findedTransaction = req.findedtr;
  try {
    console.log("There was a transaction found!", findedTransaction);
    const merchantLoginSessionId = findedTransaction.IPGsession;
    const generateSignedDataTokentoken = findedTransaction.IPGToken;

    // **********************************************************************
    console.log("Here is the first call back axios========================");

    try {
      console.log("first axios ipg sessin", findedTransaction.IPGsession);
      console.log("first axios ipg token", findedTransaction.IPGToken);

      const { status, data } = await ipg.inquiryMerchantToken({
        merchantLoginSessionId,
        generateSignedDataTokentoken,
      });
      console.log("xxxxxx=>");
      inquiryMerchantTokenSessionId = data.sessionId;
      inquiryMerchantTokenRefNum = data.RefNum;
      console.log(
        "first axios results: ",
        inquiryMerchantTokenSessionId,
        inquiryMerchantTokenRefNum
      );
    } catch (err) {
      next(err);
    }

    // **********************************************************************
    console.log("Here is the second call back axios========================");

    try {
      const { status, data } = await ipg.verifyMerchantTrans({
        inquiryMerchantTokenSessionId,
        generateSignedDataTokentoken,
        inquiryMerchantTokenRefNum,
      });
      findedTransaction.traceCode = data.traceCode;
      findedTransaction.save();
      // findedTransaction.updateOne({ $set: { traceCode: data.traceCode, upsert: true } });
      console.log("verifyMerchantTrans.data========================", data);
    } catch (err) {
      next(err);
    }

    // **********************************************************************
    console.log("Here is the third call back axios========================");

    try {
      const { status, data } = await ipg.merchantLogout({
        inquiryMerchantTokenSessionId,
      });

      console.log("merchantLogout.data========================", data);
      findedTransaction.status = true;
      findedTransaction.save();
      // TODO where are state stateCode refNumber CID MID?
      const respUpdate = await Transaction.updateTransactionSql(
        findedTransaction,
        state,
        stateCode,
        refNumber,
        CID,
        MID
      );
      const insurance = await insuranceUpdater(findedTransaction);
      const resp = await Insurance.insertInsuranceSql(insurance);
    } catch (err) {
      next(err);
    }
  } catch (err) {
    next(err);
  }
};
