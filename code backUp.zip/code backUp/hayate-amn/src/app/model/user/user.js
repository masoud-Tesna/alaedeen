const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const Schema = mongoose.Schema;
const CustomError = require("../../../utils/tools/general/customError");
const DbConnector = require("../../../utils/DB/dbConnection");
const dataConverter = require("../../../utils/tools/general/dataConverter");
const { updateIfCurrentPlugin } = require("mongoose-update-if-current");

const userSchema = new Schema(
  {
    userName: {
      type: "string",
      required: true,
      unique: true,
    },
    password: {
      type: "string",
      required: true,
    },
    record: {
      type: "string",
      required: true,
      unique: true,
    },

    category: {
      type: "string",
      default: null,
    },
    fname: {
      type: "string",
      default: null,
    },
    lname: {
      type: "string",
      default: null,
    },
    gname: {
      type: "string",
      default: null,
    },
    dname: {
      type: "string",
      default: null,
    },
    nname: {
      type: "string",
      default: null,
    },
    head: {
      type: "string",
      default: null,
    },
    relationship: {
      type: "string",
      default: null,
    },
    phone: {
      type: "string",
      default: null,
    },
    mobile: {
      type: "string",
      default: null,
    },
    addr_province: {
      type: "string",
      default: null,
    },
    addr_town: {
      type: "string",
      default: null,
    },
    addr_city: {
      type: "string",
      default: null,
    },
    addr_village: {
      type: "string",
      default: null,
    },
    addr_street: {
      type: "string",
      default: null,
    },
    addr_alley: {
      type: "string",
      default: null,
    },
    addr_floor: {
      type: "string",
      default: null,
    },
    addr_no: {
      type: "string",
      default: null,
    },
    addr_postcode: {
      type: "string",
      default: null,
    },
    addr_description: {
      type: "string",
      default: null,
    },
    addr_unit: {
      type: "string",
      default: null,
    },
    birth_date: {
      type: "string",
      default: null,
    },
    nationality: {
      type: "string",
      default: null,
    },
    sex: {
      type: "string",
      default: null,
    },
    owner: {
      type: "string",
      default: null,
    },
    EmploymentStatus: {
      type: "string",
      default: null,
    },
    EducationPlace: {
      type: "string",
      default: null,
    },
    IsDelete: {
      type: Boolean,
      default: false,
    },
    role: {
      type: "string",
      default: "user",
      enum: ["admin", "user"],
    },
  },
  {
    //for trackId
    timestamps: true,
    toJSON: {
      transform: (doc, ret) => {
        // ret.id = ret._id;
        delete ret.password;
        delete ret.IsDelete;
        delete ret.role;
      },
    },
    toObject: {
      transform: (doc, ret) => {
        // ret.id = ret._id;
        delete ret.password;
        delete ret.IsDelete;
        delete ret.role;
      },
    },
  }
);
userSchema.plugin(updateIfCurrentPlugin);
userSchema.statics.build = (args) => {
  const user = new User(args);
  return user;
};
userSchema.statics.createUserSql = async (user) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `exec sp_Insert_UsersSatpay
      @record='${user.record}',
      @password='${user.password}' `
    );
    return resp;
  } catch (error) {
    console.log(error);
    return { success: false, data: error.message };
  }
};

userSchema.statics.listUserSql = async (args) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `exec sp_List_UsersSatpay
      @record=${args.record ? `${args.record}` : null},
      @PageNumber='${args.pageNumber}',
      @RowspPage='${args.rowsPage}' `
    );
    return resp;
  } catch (error) {
    console.log(error);
    return { success: false, data: error.message };
  }
};

userSchema.statics.loadUserSql = async (args) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `exec sp_Load_UsersSatpay
      @record='${args.record}',
      @password='${args.password}'`
    );
    return resp;
  } catch (error) {
    console.log(error);
    return { success: false, data: error.message };
  }
};
userSchema.statics.loadListInventorySql = async (args) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `exec sp_LoadList_InventorySatpay
      @record=${args.record ? `${args.record}` : null},
      @PageNumber='${args.pageNumber}',
      @RowspPage='${args.rowsPage}' `
    );
    return resp;
  } catch (error) {
    console.log(error);
    return { success: false, data: error.message };
  }
};

userSchema.statics.insertInventorySql = async (user) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `exec sp_Insert_InventorySatpay
      @category=${user.category ? `'${user.category}'` : null},
      @record='${user.record}',
      @fname='${user.fname}',
      @lname='${user.lname}',
      @dname='${user.dname}',
      @gname=${user.gname ? `'${user.gname}'` : null},
      @nname=${user.nname ? `'${user.nname}'` : null},
      @head='${user.head}',
      @relationship='${user.relationship}',
      @phone='${user.phone}',
      @mobile='${user.mobile}',
      @addr_province=${user.addr_province ? `'${user.addr_province}'` : null},
      @addr_town=${user.addr_town ? `'${user.addr_town}'` : null},
      @addr_city=${user.addr_city ? `'${user.addr_city}'` : null},
      @addr_village=${user.addr_village ? `'${user.addr_village}'` : null},
      @addr_street=${user.addr_street ? `'${user.addr_street}'` : null},
      @addr_description=${
        user.addr_description ? `'${user.addr_description}'` : null
      },
      @addr_alley=${user.addr_alley ? `'${user.addr_alley}'` : null},
      @addr_no=${user.addr_no ? `'${user.addr_no}` : null}',
      @addr_floor=${user.addr_floor ? `'${user.addr_floor}'` : null},
      @addr_unit=${user.addr_unit ? `'${user.addr_unit}'` : null},
      @addr_postcode=${user.addr_postcode ? `${user.addr_postcode}` : null},
      @birth_date='${user.birth_date}',
      @nationality='${user.nationality}',
      @sex='${user.sex}',
      @owner=${user.owner ? `${user.owner}` : null},
      @EmploymentStatus='${user.EmploymentStatus}',
      @EducationPlace=${
        user.EducationPlace ? `'${user.EducationPlace}'` : null
      },
      @IsDelete=false`
    );
    return resp;
  } catch (error) {
    console.log("XXX", error.message);
    return { success: false, data: error.message };
  }
};
usereSchema.pree("save", async function (next) {
  const key = process.env.KEY;
  const iv = process.env.IV;
  console.log(Object.keys(this._doc), key, iv);
  if (this.isModified("pasesword")) {
    this.password = await dataConverter.encrypt(this.password, key, iv);
  }
  if (this.isModified("mobile")) {
    this.mobile = await dataConverter.encrypt(this.mobile, key, iv);
  }
  next();
});

const User = mongoose.model("User", userSchema);

module.exports = mongoose.model("User", userSchema);
