const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const CustomError = require("../../../utils/tools/general/customError");

const tempSchema = new Schema(
  {
    to: {
      type: "string",
      required: true,
    },
    otp: {
      type: "string",
      default: false,
    },
    otpVerified: {
      type: "boolean",
      default: false,
    },
  },
  {
    //for trackId
    timestamps: true,
  }
);
tempSchema.statics.build = (args) => {
  const temp = new Temp(args);
  return temp;
};
tempSchema.statics.tempExists = async (to) => {
  try {
    const temp = await Temp.findOne({ to: mobile, otpVerified: true });
    if (!temp)
      throw new CustomError(400, "OTP has not been verified correctly");
  } catch (error) {
    throw error;
  }
  return true;
};

const Temp = mongoose.model("Temp", tempSchema);
module.exports = mongoose.model("Temp", tempSchema);
