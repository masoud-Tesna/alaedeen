const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const User = require("../user/user");
const CustomError = require("../../../utils/tools/general/customError");
const DbConnector = require("../../../utils/DB/dbConnection");

const insuranceSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      // required: true,
      ref: "User",
    },
    transactionId: {
      type: Schema.Types.ObjectId,
      // required: true,
      ref: "Transaction",
    },
    cost: {
      type: Number,
      required: false,
    },
    record: {
      type: "string",
      required: false,
      ref: "User",
    },
    fname: {
      type: "string",
      default: null,
    },
    lname: {
      type: "string",
      default: null,
    },
    dname: {
      type: "string",
      default: null,
    },
    relationship: {
      type: "string",
      default: null,
    },
    phone: {
      type: "string",
      default: null,
    },
    mobile: {
      type: "string",
      default: null,
    },
    started: {
      type: "string",
      default: null,
    },
    stoped: {
      type: "string",
      default: null,
    },
    number: {
      type: "string",
      default: null,
    },
    type: {
      type: "number",
      default: null,
    },
    tax: {
      type: "string",
      default: null,
    },
    charge: {
      type: "string",
      default: null,
    },
    health: {
      type: "string",
      default: null,
    },
    pure: {
      type: "string",
      default: null,
    },
    registered: {
      type: "string",
      default: null,
    },
    orderid: {
      type: "string",
      default: null,
    },
    bill: {
      type: "string",
      default: null,
    },
    fullnumber: {
      type: "string",
      default: null,
    },
    issueby: {
      type: "string",
      default: null,
    },
    WitchPaymentBankOrderid: {
      type: "string",
      default: null,
    },
    FK_InventoryID: {
      type: "string",
      default: null,
    },
    year: {
      type: "string",
      default: null,
    },
  },
  {
    //for trackId
    timestamps: true,
  }
);

insuranceSchema.statics.build = (args) => {
  const insurance = new Insurance(args);
  return insurance;
};
insuranceSchema.statics.insertInsuranceSql = async (insurance) => {
  try {
    const database = DbConnector.instance;
    console.log(insurance.fname);
    const resp = await database.query(
      `exec sp_Insert_InsuranceSatpay 
      @record='${insurance.record}',
      @fname='${insurance.fname}',
      @lname='${insurance.lname}' ,
      @dname='${insurance.dname}' ,
      @relationship='${insurance.relationship}' ,
      @phone='${insurance.phone}' ,
      @mobile='${insurance.mobile}' ,
      @started='${insurance.started}' ,
      @stoped='${insurance.stoped}' ,
      @type=${insurance.type},
      @tax='' ,
      @charge='' ,
      @health='' ,
      @pure='' ,
      @cost='${insurance.cost}' ,
      @registered=${insurance.registered ? `'${insurance.registered}'` : null},
      @orderid=${insurance.orderid ? `'${insurance.orderid}'` : null},
      @issueby='' ,
      @WitchPaymentBankOrderid=${
        insurance.WitchPaymentBankOrderid
          ? `'${insurance.WitchPaymentBankOrderid}'`
          : null
      } ,
      @bill='' ,
      @Years='${insurance.year}' ,
      @MaxNumOut='',
      @FK_InventoryID=${
        insurance.FK_InventoryID ? `'${insurance.FK_InventoryID}'` : null
      } ;`
    );
    return resp;
  } catch (error) {
    return { success: false, data: error.message };
  }
};
insuranceSchema.statics.loadListInsuranceSql = async (args) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `sp_LoadList_InsuranceSatpay 
      @record=${args.record ? `${args.record}` : null} ,
      @startedsDate=${args.startedsDate ? `'${args.startedsDate}'` : null} ,
      @startedeDate=${args.startedeDate ? `'${args.startedeDate}'` : null} ,
      @stopedsDate=${args.stopedsDate ? `'${args.stopedsDate}'` : null} ,
      @stopedeDate=${args.stopedeDate ? `'${args.stopedeDate}'` : null} ,
      @PageNumber='${args.pageNumber}' ,
      @RowspPage='${args.rowsPage}' ,
      @type=${args.type ? `${args.type}` : null} ,
      @FK_InventoryID=${
        args.FK_InventoryID ? `${args.FK_InventoryID}` : null
      } ;`
    );
    return resp;
  } catch (error) {
    return { success: false, data: error.message };
  }
};
const Insurance = mongoose.model("Insurance", insuranceSchema);
module.exports = Insurance;
