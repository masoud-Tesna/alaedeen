const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const transactionSchema = new Schema(
  {
    insuranceId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "Insurance",
    },
    userId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
    amount: {
      type: Number,
      required: true,
    },
    cardNumber: {
      type: Number,
      required: false,
    },
    status: {
      type: Boolean,
      required: true,
    },
    description: {
      type: "string",
      required: false,
    },
    IPGToken: {
      type: "string",
      required: false,
    },
    IPGsession: {
      type: "string",
      required: false,
    },
    traceCode: {
      type: "string",
      required: false,
    },
    orderID: {
      type: "string",
      required: true,
    },
    trackId: {
      type: "string",
      required: true,
    },
    terminalID: {
      type: "string",
      required: true,
    },
    transactionType: {
      type: "string",
      enum: ["withdrawal", "deposit"],
      default: "withdrawal",
    },
    trackId: {
      type: "string",
      required: true,
    },
  },
  {
    //for trackId
    timestamps: true,
  }
);

transactionSchema.statices.build = (args) => {
  const transaction = new Transaction(args);
  return transaction;
};

transactionSchema.statics.createTraensactionSql = async (
  transaction,
  MobileNo,
  refNumber,
  ResNumber
) => {
  try {
    const resp = await database.query(
      `sp_Insert_TransactionWithToken @SelectType=3 , @TerminalID='${
        transaction.terminalID
      }' ,@UserID=2,@TransactionDate='${new Date().toLocaleString()}' ,@RefNumber='${refNumber}' ,@PaymentType=1,@Description='${
        transaction.description
      }',@CardNumber='${transaction.cardNumber}',@SalePrice=${
        transaction.amount
      },sp_Insert_TransactionWithToken @SelectType=3 , @TerminalID='${
        transaction.terminalID
      }' ,@UserID=2,@TransactionDate='${new Date().toLocaleString()}' ,@RefNumber='${refNumber}' ,@PaymentType=@PaymentPriceForCard=${
        transaction.amount
      },@TashimPazirandeh=0 ,@TashimIQ=0 ,@TashimPartner=0 ,@TashimOther=0 ,@Status=1 ,@Stan='${ResNumber}',@RRN='${
        transaction.traceCode
      }', @ResponseCode='', @TransToken='${
        transaction.IPGToken
      }'  , @SessionID='${transaction.IPGsession}', @Mobile='${MobileNo}'  ;`
    );
    return resp;

    // TODO mobile and cardnumber should be added .IPG token and sessionId should be asked
  } catch (error) {
    return { success: false, data: error.message };
  }
};
// TODO modify meli and mellat order transaction
transactionSchema.statics.insertMeliOrderSql = async (
  transaction,
  timestamps,
  refid,
  requestKey,
  localdate,
  localtime,
  salerefId,
  AppStatus,
  record
) => {
  try {
    const resp = await database.query(
      `sp_Insert_MeliOrdersSatpay 
      @orderid='${transaction.orderID}' ,
      @amount='${transaction.amount}' ,
      @FP='${FP}' ,
      @TimeStamp='${timestamps}' ,
      @requestKey='${requestKey}' ,
      @localdate='${localdate}' ,
      @localtime='${localtime}' ,
      @status='${transaction.status}' ,
      @refid='${refid}' ,
      @salerefId='${salerefId}' ,
      @AppStatus='${AppStatus}' ,
      @record='${record}'  ;`
    );
    return resp;

    // TODO mobile and cardnumber should be added .IPG token and sessionId should be asked
  } catch (error) {
    return { success: false, data: error.message };
  }
};
transactionSchema.statics.insertMellatOrderSql = async (
  transaction,
  timestamps,
  refid,
  requestKey,
  localdate,
  localtime,
  salerefId,
  AppStatus,
  record
) => {
  try {
    const resp = await database.query(
      `sp_Insert_MellatOrdersSatpay 
      @orderid='${transaction.orderID}' ,
      @amount='${transaction.amount}' ,
      @FP='${FP}' ,
      @TimeStamp='${timestamps}' ,
      @requestKey='${requestKey}' ,
      @localdate='${localdate}' ,
      @localtime='${localtime}' ,
      @status='${transaction.status}' ,
      @refid='${refid}' ,
      @salerefId='${salerefId}' ,
      @AppStatus='${AppStatus}' ,
      @record='${record}'  ;`
    );
    return resp;

    // TODO mobile and cardnumber should be added .IPG token and sessionId should be asked
  } catch (error) {
    return { success: false, data: error.message };
  }
};
transactionSchema.statics.createTransactionSql = async (
  transaction,
  MobileNo,
  refNumber,
  ResNumber
) => {
  try {
    const resp = await database.query(
      `sp_Insert_MeliOrdersSatpay  
      @TerminalID='${transaction.terminalID}' ,
      @UserID=2,@TransactionDate='${new Date().toLocaleString()}' ,
      @RefNumber='${refNumber}' ,
      @PaymentType=1,
      @Description='${transaction.description}',
      @CardNumber='${transaction.cardNumber}',
      @SalePrice=${transaction.amount},
      sp_Insert_TransactionWithToken @SelectType=3 , 
      @TerminalID='${transaction.terminalID}' ,
      @UserID=2,
      @TransactionDate='${new Date().toLocaleString()}' ,
      @RefNumber='${refNumber}' ,
      @PaymentType=@PaymentPriceForCard=${transaction.amount},
      @TashimPazirandeh=0 ,
      @TashimIQ=0 ,
      @TashimPartner=0 ,
      @TashimOther=0 ,
      @Status=1 
      ,@Stan='${ResNumber}',
      @RRN='${transaction.traceCode}', 
      @ResponseCode='', 
      @TransToken='${transaction.IPGToken}'  , 
      @SessionID='${transaction.IPGsession}', 
      @Mobile='${MobileNo}'  ;`
    );
    return resp;

    // TODO mobile and cardnumber should be added .IPG token and sessionId should be asked
  } catch (error) {
    return { success: false, data: error.message };
  }
};

transactionSchema.statics.InsertTransactionSqls = async (
  transaction,
  refNumber
) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `sp_Insert_TransactionWithToken 
      @SelectType=3,
      @TerminalID='${transaction.terminalID}' ,
      @UserID='${transaction.userId}' ,
      @TransactionDate='${new Date().toLocaleString()}' ,
      @RefNumber='${refNumber}' ,
      @PaymentType='${transaction.amount}' ,
      @Description='${transaction.description}' ,
      @CardNumber='${transaction.cardNumber}' ,
      @SalePrice='${transaction.amount}' ,
      @TransToken='${transaction.IPGToken}' ,
      @SessionID='${transaction.IPGsession}' ;`
    );
    return resp;
  } catch (error) {
    return { success: false, data: error.message };
  }
};
transactionSchema.statics.updateTransactionSql = async (
  transaction,
  state,
  stateCode,
  refNumber,
  CID,
  MID
) => {
  try {
    const database = DbConnector.instance;
    const resp = await database.query(
      `sp_update_Transaction 
      @TransactionID='${transaction.id}' ,
      @TerminalID='${transaction.terminalID}' ,
      @State='${state}' ,
      @StateCode='${stateCode}' ,
      @TraceNo='${transaction.traceCode}',
      @RefNumber='${refNumber}'  ,
      @CID='${CID}' ,
      @MID='${MID}' ,
      @CardNumber='${transaction.cardNumber}' ,
      @Status='${transaction.status}' ,
      @TransToken='${transaction.IPGToken}' ;`
    );
    return resp;
  } catch (error) {
    return { success: false, data: error.message };
  }
};
ee.pre("save", async function (next) {
  if (this.transactionType === "withdrawal") {
    this.amount = -parseFloat(this.amount);
  }
  next();
});

const Transaction = mongoose.model("Transaction", transactionSchema);
module.exports = Transaction;
