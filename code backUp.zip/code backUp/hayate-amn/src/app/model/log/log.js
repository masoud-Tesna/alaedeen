const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const logSchema = new Schema(
  {
    url: {
      type: "string",
      required: true,
    },
    input: {
      type: "string",
      required: true,
    },
    output: {
      type: "string",
      required: true,
    },
    trackId: {
      type: Number,
      required: true,
    },
    statusCode: {
      type: Number,
      required: true,
    },
    header: {
      type: "string",
      required: false,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Log", logSchema);
