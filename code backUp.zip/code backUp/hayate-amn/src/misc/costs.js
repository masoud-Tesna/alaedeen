const costs = {
  190: {
    type: 1,
    code: 190,
    duration: 90,
    cost: 19200,
  },
  290: {
    type: 2,
    code: 290,
    duration: 90,
    cost: 38400,
  },
  390: {
    type: 3,
    code: 390,
    duration: 90,
    cost: 74700,
  },
  490: {
    type: 4,
    code: 490,
    duration: 90,
    cost: 148400,
  },
  1180: {
    type: 1,
    code: 1180,
    duration: 180,
    cost: 33400,
  },
  2180: {
    type: 2,
    code: 2180,
    duration: 180,
    cost: 66700,
  },
  3180: {
    type: 3,
    code: 3180,
    duration: 180,
    cost: 130200,
  },
  4180: {
    type: 4,
    code: 4180,
    duration: 180,
    cost: 260400,
  },
  1270: {
    type: 1,
    code: 1270,
    duration: 270,
    cost: 40400,
  },
  2270: {
    type: 2,
    code: 2270,
    duration: 270,
    cost: 79800,
  },
  3270: {
    type: 3,
    code: 3270,
    duration: 270,
    cost: 158500,
  },
  4270: {
    type: 4,
    code: 4270,
    duration: 270,
    cost: 316000,
  },
  1360: {
    type: 1,
    code: 1360,
    duration: 360,
    cost: 46870,
  },

  2360: {
    type: 2,
    code: 2360,
    duration: 360,
    cost: 93740,
  },
  3360: {
    type: 3,
    code: 3360,
    duration: 360,
    cost: 185300,
  },
  4360: {
    type: 4,
    code: 4360,
    duration: 360,
    cost: 370600,
  },
  590: {
    type: 5,
    code: 590,
    duration: 90,
    cost: 230000,
  },
  5180: {
    type: 5,
    code: 5180,
    duration: 180,
    cost: 400000,
  },
  5270: {
    type: 5,
    code: 5270,
    duration: 270,
    cost: 480000,
  },
  5360: {
    type: 5,
    code: 5360,
    duration: 360,
    cost: 556000,
  },
};
module.exports = costs;
