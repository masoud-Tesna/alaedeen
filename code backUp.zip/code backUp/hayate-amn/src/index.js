const app = require("./app");
const { join } = require("path");
const DbConnector = require("./utils/DB/dbConnection");
const notifier = require("./utils/notification/notifier");
const cache = require("./utils/DB/cache");

app.listen(process.env.PORT, async () => {
  try {
    console.log("server is on");
    await DbConnector.init();
    await notifier.init();
    await cache.init();
  } catch (error) {}
});
