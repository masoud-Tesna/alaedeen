const mongoose = require('mongoose');


const MONGO_URL = process.env.MONGO_CONNECTION_URL;
const mongoConnector = async()=>{
    try{
        mongoose.connect(MONGO_URL)
        console.log("mongo connected");
    }catch(err){
        console.log(`mongo not connected because : ${err}`);
    }
}


module.exports = mongoConnector;