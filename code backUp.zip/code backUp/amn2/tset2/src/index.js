const app = require('./app');
const mongoConnector = require('./utils/DB/mongoConnector');

const PORT = process.env.PORT;

const startApp =async () =>{
    try{
        await mongoConnector();

        app.listen(PORT, ()=>{
            console.log(`app on port : ${PORT}`);
        })
    }catch(err){
        console.log(`ERROR !!! : ${err}`);
    }
}

startApp();