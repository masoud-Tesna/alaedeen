const {join} = require('path');

const dotenv = require('dotenv');
const CORS = require('cors');
const helmet = require('helmet');
const express = require('express');
const app = express();

app.use(CORS);
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({extended : false}))


dotenv.config({path: join( __dirname, "./env/product.env")});

app.get("/hello", (req, res)=>{
    console.log("kjsndjkn");
    res.send("lkaskd").end();
})

app.listen(5005, ()=>{
    console.log(`app on port :`);
})
// module.exports = app;