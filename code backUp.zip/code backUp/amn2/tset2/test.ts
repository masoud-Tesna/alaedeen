
  //   public Encrypt(MyStr: string, strEncrKey: string): string {
  //     let byKey: number[];
      
  //     let IV: number[];
  //     18;
  //     52;
  //     86;
  //     120;
  //     144;
  //     10;
  //     B;
  //     205;
  //     239;
      
  //     byKey = System.Text.Encoding.UTF8.GetBytes(Strings.Left(strEncrKey, 8));
  //     let des: DESCryptoServiceProvider = new DESCryptoServiceProvider();
  //     let inputByteArray: number[] = Encoding.UTF8.GetBytes(MyStr);
  //     let ms: MemoryStream = new MemoryStream();
  //     let cs: CryptoStream = new CryptoStream(ms, des.CreateEncryptor(byKey, IV), CryptoStreamMode.Write);
  //     cs.Write(inputByteArray, 0, inputByteArray.Length);
  //     cs.FlushFinalBlock();
  //     return Convert.ToBase64String(ms.ToArray());
  // }

//   ==============================================


//   public Decrypt(MyStr: string, sDecrKey: string): string {
//     let byKey: number[];
    
//     let IV: number[];
//     18;
//     52;
//     86;
//     120;
//     144;
//     10;
//     B;
//     205;
//     239;
    
//     let inputByteArray: number[] = new Array((MyStr.Length + 1));
//     byKey = System.Text.Encoding.UTF8.GetBytes(Strings.Left(sDecrKey, 8));
//     let des: DESCryptoServiceProvider = new DESCryptoServiceProvider();
//     inputByteArray = Convert.FromBase64String(MyStr);
//     let ms: MemoryStream = new MemoryStream();
//     let cs: CryptoStream = new CryptoStream(ms, des.CreateDecryptor(byKey, IV), CryptoStreamMode.Write);
//     cs.Write(inputByteArray, 0, inputByteArray.Length);
//     cs.FlushFinalBlock();
//     let encoding: System.Text.Encoding = System.Text.Encoding.UTF8;
//     return encoding.GetString(ms.ToArray());
// }