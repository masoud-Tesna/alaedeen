import request from "supertest";
import app from "../../../app";

declare const global: NodeJS.Global;
it("has a handler listening on /api/open-banking/v1/ic-start/etc for post requests", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .send();

  expect(response.status).not.toEqual(404);
});

it("responds with 401 status if no apikey set in header", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if no appname set in header", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );
  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if apikey dont have openBanking scope", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(401);
});
it("responds with 403 status if ip is not authorized", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["192.168.1.106"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(403);
});

it("responds with 422 status if no 'realPersonNationalCode' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ mobileNumber: "09102972665", legalPersonNationalCode: "" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'realPersonNationalCode' is not 10 characters", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      realPersonNationalCode: "12546",
      mobileNumber: "09102972665",
      legalPersonNationalCode: "",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'legalPersonNationalCode' is not digits", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      realPersonNationalCode: "1234567890",
      mobileNumber: "09102972665",
      legalPersonNationalCode: "1234567890s",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'legalPersonNationalCode' is not 11 characters", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      realPersonNationalCode: "1234567890",
      mobileNumber: "09102972665",
      legalPersonNationalCode: "12345678",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if no 'mobileNumber' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      realPersonNationalCode: "1234567890",
      legalPersonNationalCode: "12345678907",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'mobileNumber' is not digits", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      realPersonNationalCode: "1234567890",
      mobileNumber: "0910297255s",
      legalPersonNationalCode: "12345678",
    });

  expect(response.status).toEqual(422);
});

it("responds with 200 status if all stuff is correct", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);
  const response = await request(app)
    .post("/api/open-banking/v1/ic-start/etc")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      realPersonNationalCode: "0023237341",
      mobileNumber: "09102972559",
      legalPersonNationalCode: "",
    });
  console.log("xxxx=>", response.body);
  expect(response.status).toEqual(200);
});
