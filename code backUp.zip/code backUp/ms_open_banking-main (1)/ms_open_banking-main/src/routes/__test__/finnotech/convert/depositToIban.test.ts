import request from "supertest";
import app from "../../../../app";

declare const global: NodeJS.Global;
it("has a handler listening on /api/open-banking/v1/deposit-iban/convert for post requests", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .send();

  expect(response.status).not.toEqual(404);
});

it("responds with 401 status if no apikey set in header", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if no appname set in header", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );
  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if apikey dont have openBanking scope", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(401);
});
it("responds with 403 status if ip is not authorized", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["192.168.1.106"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(403);
});

it("responds with 402 status if balance is not enough", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(402);
});

it("responds with 422 status if no 'sourceAccount' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ bank: "AYN" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'sourceAccount' not digits", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ sourceAccount: "ad213das", bank: "213" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if no 'bank' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ sourceAccount: "12312321" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'bank' is not 3 characters", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ sourceAccount: "12312321", bank: "2312" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'bank' is not digits", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ sourceAccount: "12312321", bank: "sas" });

  expect(response.status).toEqual(422);
});

it("responds with 200 status if all stuff is correct", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);
  const response = await request(app)
    .post("/api/open-banking/v1/deposit-iban/convert")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ sourceAccount: "0100627732002", bank: "AYN" });

  expect(response.status).toEqual(200);
});
