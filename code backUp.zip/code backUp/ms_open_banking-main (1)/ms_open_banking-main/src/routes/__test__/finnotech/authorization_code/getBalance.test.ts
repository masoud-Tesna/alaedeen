import request from "supertest";
import app from "../../../../app";

declare const global: NodeJS.Global;
it("has a handler listening on /api/open-banking/v1/get-balance/auth-code for post requests", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .send();

  expect(response.status).not.toEqual(404);
});

it("responds with 401 status if no apikey set in header", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if no appname set in header", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );
  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if apikey dont have openBanking scope", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(401);
});
it("responds with 403 status if ip is not authorized", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["192.168.1.106"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(403);
});

it("responds with 402 status if balance is not enough", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(402);
});

it("responds with 422 status if no 'deposit' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ bank: "062", token: "test", refreshToken: "test test" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'deposit' not digits", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      deposit: "ad213das",
      bank: "213",
      token: "test",
      refreshToken: "test test",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if no 'bank' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ deposit: "12312321", token: "test", refreshToken: "test test" });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'bank' is not 3 characters", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      deposit: "12312321",
      bank: "2312",
      token: "test",
      refreshToken: "test test",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if 'bank' is not digits", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({
      deposit: "12312321",
      bank: "sas",
      token: "test",
      refreshToken: "test test",
    });

  expect(response.status).toEqual(422);
});

it("responds with 422 status if no 'token' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ deposit: "12312321", bank: "062", refreshToken: "test test" });

  expect(response.status).toEqual(422);
});
it("responds with 422 status if no 'refreshToken' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(20000);

  const response = await request(app)
    .post("/api/open-banking/v1/get-balance/auth-code")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ deposit: "12312321", bank: "062", token: "test test" });

  expect(response.status).toEqual(422);
});
