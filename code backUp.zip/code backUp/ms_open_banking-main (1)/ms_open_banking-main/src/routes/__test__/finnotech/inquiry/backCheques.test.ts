import request from "supertest";
import app from "../../../../app";

declare const global: NodeJS.Global;
it("has a handler listening on /api/open-banking/v1/back-cheques/inquiry for post requests", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .send();

  expect(response.status).not.toEqual(404);
});

it("responds with 401 status if no apikey set in header", async () => {
  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if no appname set in header", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );
  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .send();

  expect(response.status).toEqual(401);
});

it("responds with 401 status if apikey dont have openBanking scope", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["GOV"],
    "startup",
    "client_credentials",
    ["1.1.1.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(401);
});
it("responds with 403 status if ip is not authorized", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["192.168.1.106"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(403);
});

it("responds with 402 status if balance is not enough", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(402);
});

it("responds with 422 status if no 'nationalID' provided", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(200000);

  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send();

  expect(response.status).toEqual(422);
});

it("responds with 422 status if no 'nationalID' is invalid", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(200000);

  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ nationalID: "12312" });

  expect(response.status).toEqual(422);
});

it("responds with 200 status if all stuff is correct", async () => {
  const { APIkey } = await global.signAPIkey!(
    "5d",
    ["openBanking"],
    "startup",
    "client_credentials",
    ["::ffff:127.0.0.1"],
    "test",
    false
  );

  await global.balance!(200000);
  const response = await request(app)
    .post("/api/open-banking/v1/back-cheques/inquiry")
    .set("apikey", APIkey)
    .set("x-forwarded-for", "::ffff:127.0.0.1")
    .set("appname", "test")
    .send({ nationalID: "0383790931" });

  expect(response.status).toEqual(200);
});
