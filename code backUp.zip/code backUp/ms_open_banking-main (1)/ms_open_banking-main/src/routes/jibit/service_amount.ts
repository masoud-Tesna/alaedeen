export default {
  shahkarInquiry: {
    startup: 12000,
    sm_business: 11000,
    md_business: 11000,
    lg_business: 11000,
    buyPrice: 2500,
  },
  inquiryCardNumberWithName: {
    startup: 12000,
    sm_business: 11000,
    md_business: 11000,
    lg_business: 11000,
    buyPrice: 2500,
  },
  inquiryCardNumberIdentity: {
    startup: 12000,
    sm_business: 11000,
    md_business: 11000,
    lg_business: 11000,
    buyPrice: 250,
  },

  inquiryCard: {
    startup: 15000,
    sm_business: 11000,
    md_business: 11000,
    lg_business: 11000,
    buyPrice: 250,
  },
  cardToIban: {
    startup: 6500,
    sm_business: 4000,
    md_business: 4000,
    lg_business: 3000,
    buyPrice: 2000,
  },
  cardToDeposit: {
    startup: 6500,
    sm_business: 4000,
    md_business: 4000,
    lg_business: 3000,
    buyPrice: 2000,
  },
};
