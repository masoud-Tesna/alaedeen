import { Router } from "express";
import controller from "../../app/http/controllers/jibit/main";
import { shahkarInquiryValidationChain } from "../../app/http/requests/jibit/inquiry/shahkar";
import { cardIdentitiyInquiryValidationChain } from "../../app/http/requests/jibit/inquiry/cardIdentitiy";
import { cardInquiryValidationChain } from "../../app/http/requests/jibit/inquiry/cardInquiry";
import { cardToDepositValidationChain } from "../../app/http/requests/jibit/convert/cardToDeposit";
import { cardNumberWithNameValidationChain } from "../../app/http/requests/jibit/inquiry/cardNumberWithName";

import {
  cardToIbanValidationChain,
  cardToIbanArrayValidationChain,
} from "../../app/http/requests/finnotech/convert/cardToIban";

import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/shahkar/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.shahkarInquiry),
  shahkarInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.inquiryShahkar
);

router.post(
  "/open-banking/v1/card-identitiy/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.inquiryCardNumberIdentity),
  cardIdentitiyInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.inquiryCardNumberIdentity
);

router.post(
  "/open-banking/v1/card-info/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.inquiryCard),
  cardInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.inquiryCard
);

router.post(
  "/open-banking/v1/card-iban/convert",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.cardToIban),
  cardToIbanValidationChain,
  mspack.express_validator_resault_mw,
  controller.cardToIban
);

router.post(
  "/open-banking/v1/card-iban-array/convert",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_multi_mw(
    service_amount.cardToIban,
    service_amount.cardToIban,
    "cards",
    "length" as any
  ),
  cardToIbanArrayValidationChain,
  mspack.express_validator_resault_mw,
  controller.cardToIbanArray
);

router.post(
  "/open-banking/v1/card-deposit/convert",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.cardToDeposit),
  cardToDepositValidationChain,
  mspack.express_validator_resault_mw,
  controller.cardToDeposit
);

router.post(
  "/open-banking/v1/card-name-identity/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.inquiryCardNumberWithName),
  cardNumberWithNameValidationChain,
  mspack.express_validator_resault_mw,
  controller.inquiryCardNumberWithName
);

export default router;
