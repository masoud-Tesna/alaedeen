import { Router } from "express";
import controller from "../../app/http/controllers/tejarat/main";
import { cardInquiryValidationChain } from "../../app/http/requests/tejarat/inquiry/card";
import { panIdentifierInquiryValidationChain } from "../../app/http/requests/tejarat/inquiry/panIdentifier";
import { panMobileIdentifierInquiryValidationChain } from "../../app/http/requests/tejarat/inquiry/panMobileIdentifier";
import { accountMobileIdentifierInquiryValidationChain } from "../../app/http/requests/tejarat/inquiry/accountMobileIdentifier";
import { shahkarInquiryValidationChain } from "../../app/http/requests/tejarat/inquiry/shahkar";
import { accountIdentifierInquiryValidationChain } from "../../app/http/requests/tejarat/inquiry/accountIdentifier";
import { cardToIbanValidationChain } from "../../app/http/requests/tejarat/convert/cardToIban";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/tejarat/card/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.cardInquiry),
  cardInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.cardInquiry
);

router.post(
  "/open-banking/v1/tejarat/pan-identifier/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.panIdentifierInquiry),
  panIdentifierInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.panIdentifierInquiry
);

router.post(
  "/open-banking/v1/tejarat/pan-mobile-identifier/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.panMobileIdentifier),
  panMobileIdentifierInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.panMobileIdentifier
);

router.post(
  "/open-banking/v1/tejarat/account-mobile-identifier/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.accountMobileIdentifier),
  accountMobileIdentifierInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.accountMobileIdentifier
);

router.post(
  "/open-banking/v1/tejarat/shahkar/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.shahkarInquiry),
  shahkarInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.shahkarInquiry
);

router.post(
  "/open-banking/v1/tejarat/account-identifier/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.accountIdentifier),
  accountIdentifierInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.accountIdentifier
);

router.post(
  "/open-banking/v1/tejarat/card-iban/convert",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.cardInfo),
  cardToIbanValidationChain,
  mspack.express_validator_resault_mw,
  controller.cardToIban
);

export default router;
