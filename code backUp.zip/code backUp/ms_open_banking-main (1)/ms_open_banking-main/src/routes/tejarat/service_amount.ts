export default {
  cardInquiry: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },
  panIdentifierInquiry: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },

  panMobileIdentifier: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },
  accountMobileIdentifier: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },
  shahkarInquiry: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },
  accountIdentifier: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },
  cardInfo: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 0,
  },
};
