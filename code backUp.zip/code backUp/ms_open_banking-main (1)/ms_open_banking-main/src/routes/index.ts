import faraboom_direct_debit from "./faraboom/direct_debit";
import faraboom_other from "./faraboom/other";
import finnotech_inquiry from "./finnotech/inquiry";
import finnotech_convert from "./finnotech/convert";
import finnotech_base from "./finnotech/base";
import finnotech_authorization_code from "./finnotech/authorization_code";
import iran_credit_main from "./iran_credit/main";
import sepandaar_main from "./sepandaar/main";
import central_iran_bank_main from "./central_iran_bank/main";
import shahin_inquiry from "./shahin/inquiry";
import shahin_register from "./shahin/register";
import shahin_convert from "./shahin/convert";
import pardakhtyari from "./pardakhtyari/main";
import tejarat from "./tejarat/main";
import saman from "./saman/main";
import jibit from "./jibit/main";

export default {
  faraboom_direct_debit,
  faraboom_other,
  finnotech_inquiry,
  finnotech_convert,
  finnotech_base,
  finnotech_authorization_code,
  iran_credit_main,
  sepandaar_main,
  central_iran_bank_main,
  shahin_inquiry,
  shahin_convert,
  shahin_register,
  pardakhtyari,
  tejarat,
  saman,
  jibit,
};
