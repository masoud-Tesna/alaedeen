export default "openBanking";
