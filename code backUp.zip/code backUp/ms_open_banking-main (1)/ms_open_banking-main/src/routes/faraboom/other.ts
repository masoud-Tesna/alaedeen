import { Router } from "express";
import controller from "../../app/http/controllers/faraboom/other/main";
import { tollDebtValidationChain } from "../../app/http/requests/faraboom/other/tollDebts";
import { cardsHolderValidationChain } from "../../app/http/requests/faraboom/other/cardsHolder";
import { balanceValidationChain } from "../../app/http/requests/faraboom/other/balance";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/toll-debts/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.tollDebts),
  tollDebtValidationChain,
  mspack.express_validator_resault_mw,
  controller.tollDebts
);

// router.post(
//   "/open-banking/v1/card-holder/inquiry",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.cardsHolder),
//   cardsHolderValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.cardsHolder
// );

router.post(
  "/open-banking/v1/balance/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.balance),
  balanceValidationChain,
  mspack.express_validator_resault_mw,
  controller.balance
);

export default router;
