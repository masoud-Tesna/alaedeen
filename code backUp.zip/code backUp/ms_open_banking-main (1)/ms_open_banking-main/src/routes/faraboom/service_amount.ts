export default {
  startPay: {
    startup: 10000,
    sm_business: 10000,
    md_business: 10000,
    lg_business: 10000,
    buyPrice: 9000,
  },
  startPayBill: {
    startup: 10000,
    sm_business: 10000,
    md_business: 10000,
    lg_business: 10000,
    buyPrice: 9000,
  },
  tollDebts: {
    startup: 10000,
    sm_business: 10000,
    md_business: 10000,
    lg_business: 10000,
    buyPrice: 9000,
  },
  cardsHolder: {
    startup: 10000,
    sm_business: 10000,
    md_business: 10000,
    lg_business: 10000,
    buyPrice: 9000,
  },

  balance: {
    startup: 10000,
    sm_business: 10000,
    md_business: 10000,
    lg_business: 10000,
    buyPrice: 9000,
  },
};
