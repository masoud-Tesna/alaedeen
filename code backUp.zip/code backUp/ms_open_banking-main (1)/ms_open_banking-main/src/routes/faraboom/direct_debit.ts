import { Router } from "express";
import controller from "../../app/http/controllers/faraboom/direct_debit/main";
import { createCovenantValidationChain } from "../../app/http/requests/faraboom/direct_debit/create_covenant";
import { getCovenantValidationChain } from "../../app/http/requests/faraboom/direct_debit/get_covenant";

import {
  startPayValidationChain,
  checkRequestAmount,
  startPayBillValidationChain,
} from "../../app/http/requests/faraboom/direct_debit/start_pay";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.get(
  "/open-banking/v1/direct-debit/permissions",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  controller.permissions
);

router.post(
  "/open-banking/v1/direct-debit/create-covenant",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  createCovenantValidationChain,
  mspack.express_validator_resault_mw,
  controller.create_covenant
);

router.get("/open-banking/direct-debit/back", controller.peyman_back);

router.post(
  "/open-banking/v1/direct-debit/start-pay",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.startPay),
  startPayValidationChain,
  checkRequestAmount,
  mspack.express_validator_resault_mw,
  controller.start_pay
);

router.post(
  "/open-banking/v1/direct-debit/start-pay-bill",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.startPayBill),
  startPayBillValidationChain,
  checkRequestAmount,
  mspack.express_validator_resault_mw,
  controller.start_bill_pay
);

router.get(
  "/open-banking/v1/direct-debit",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  getCovenantValidationChain,
  mspack.express_validator_resault_mw,
  controller.covenantInfo
);

export default router;
