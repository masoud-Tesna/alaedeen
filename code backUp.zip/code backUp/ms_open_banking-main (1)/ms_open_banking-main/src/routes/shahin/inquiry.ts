import { Router } from "express";
import controller from "../../app/http/controllers/shahin/inquiry/main";
import { nationalCodeIdentityValidationChain } from "../../app/http/requests/shahin/inquiry/nationalCodeIdentity";
import { ibanIdentityInquiryValidationChain } from "../../app/http/requests/shahin/inquiry/ibanIdentityInquiry";
import { phoneValidityInquiryValidationChain } from "../../app/http/requests/shahin/inquiry/phoneValidityInquiry";
import { accountInfoInquiryValidationChain } from "../../app/http/requests/shahin/inquiry/accountInfoInquiry";
import { sayyadChequeInquiryValidationChain } from "../../app/http/requests/shahin/inquiry/sayyadChequeInquiry";
import { ibanInquiryValidationChain } from "../../app/http/requests/shahin/inquiry/ibanInquiry";
import { cardInquiryValidationChain } from "../../app/http/requests/shahin/inquiry/cradInquiry";

import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/national-code/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.nationalIdentityInquiry),
  nationalCodeIdentityValidationChain,
  mspack.express_validator_resault_mw,
  controller.nationalIdentityInquiry
);

router.post(
  "/open-banking/v1/iban-identity/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.ibanIdentityInquiry),
  ibanIdentityInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.ibanIdentityInquiry
);

router.post(
  "/open-banking/v1/iban/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.ibanInquiry),
  ibanInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.ibanInquiry
);

// router.post(
//   "/open-banking/v1/card-info/inquiry",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.cardInquiry),
//   cardInquiryValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.cardInquiry
// );

router.post(
  "/open-banking/v1/phone-validity/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.phoneValidityInquiry),
  phoneValidityInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.phoneValidityInquiry
);

router.post(
  "/open-banking/v1/account/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.accountInfoInquiry),
  accountInfoInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.accountInfoInquiry
);

router.post(
  "/open-banking/v1/sayad-cheque/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.sayyadChequeInquiry),
  sayyadChequeInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.sayyadChequeInquiry
);

export default router;
