import { Router } from "express";
import controller from "../../app/http/controllers/shahin/register/main";
import { sayyadChequeRegisterValidationChain } from "../../app/http/requests/shahin/register/sayyadChequeRegister";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/sayad-cheque/register",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.sayyadChequeRegister),
  sayyadChequeRegisterValidationChain,
  mspack.express_validator_resault_mw,
  controller.sayyadChequeRegister
);

export default router;
