export default {
  nationalIdentityInquiry: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 3500,
  },
  ibanIdentityInquiry: {
    startup: 20000,
    sm_business: 15000,
    md_business: 15000,
    lg_business: 9000,
    buyPrice: 3500,
  },
  ibanInquiry: {
    startup: 6500,
    sm_business: 5000,
    md_business: 5000,
    lg_business: 4500,
    buyPrice: 3500,
  },

  cardInquiry: {
    startup: 6500,
    sm_business: 5000,
    md_business: 5000,
    lg_business: 4500,
    buyPrice: 3500,
  },

  depositToIban: {
    startup: 6500,
    sm_business: 5000,
    md_business: 5000,
    lg_business: 4500,
    buyPrice: 3500,
  },
  phoneValidityInquiry: {
    startup: 12000,
    sm_business: 11000,
    md_business: 11000,
    lg_business: 11000,
    buyPrice: 3000,
  },

  accountInfoInquiry: {
    startup: 6000,
    sm_business: 5000,
    md_business: 5000,
    lg_business: 3500,
    buyPrice: 2000,
  },
  sayyadChequeInquiry: {
    startup: 6000,
    sm_business: 5000,
    md_business: 5000,
    lg_business: 3500,
    buyPrice: 2000,
  },
  sayyadChequeRegister: {
    startup: 6000,
    sm_business: 5000,
    md_business: 5000,
    lg_business: 3500,
    buyPrice: 2000,
  },
};
