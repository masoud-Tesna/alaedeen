import { Router } from "express";
import controller from "../../app/http/controllers/shahin/convert/main";
import { deposiToIbanValidationChain } from "../../app/http/requests/shahin/convert/depositToIban";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/deposit-iban/convert",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.depositToIban),
  deposiToIbanValidationChain,
  mspack.express_validator_resault_mw,
  controller.depositToIban
);

export default router;
