export default {
  billInquiry: {
    startup: 3000,
    sm_business: 3000,
    md_business: 3000,
    lg_business: 3000,
    buyPrice: 10,
  },
};
