import { Router } from "express";
import controller from "../../app/http/controllers/saman/main";
import {
  payaValidationChain,
  payaReportValidationChain,
  getUserData,
} from "../../app/http/requests/saman/paya";
import {
  satnaValidationChain,
  getUserData as getUserDataSatnaReport,
  satnaReportValidationChain,
} from "../../app/http/requests/saman/satna";
import { normalValidationChain } from "../../app/http/requests/saman/normal";

import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/paya/pay",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  payaValidationChain,
  mspack.express_validator_resault_mw,
  mspack.require_credit_mw(null),
  controller.payaPayment
);

router.post(
  "/open-banking/v1/satna/pay",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  satnaValidationChain,
  mspack.express_validator_resault_mw,
  mspack.require_credit_mw(null),
  controller.satnaPayment
);

router.post(
  "/open-banking/v1/internal-saman/pay",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  normalValidationChain,
  mspack.express_validator_resault_mw,
  mspack.require_credit_mw(null),
  controller.normalPayment
);
//TODO add ip checker just for us
router.get(
  "/open-banking/v1/paya/report",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  // mspack.require_credit_mw(service_amount.satna),
  payaReportValidationChain,
  mspack.express_validator_resault_mw,
  getUserData,
  controller.payaPaymentReport
);
//TODO add ip checker just for us
router.get(
  "/open-banking/v1/satna/report",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  // mspack.require_credit_mw(service_amount.satna),
  satnaReportValidationChain,
  mspack.express_validator_resault_mw,
  getUserDataSatnaReport,
  controller.satnaPaymentReport
);

export default router;
