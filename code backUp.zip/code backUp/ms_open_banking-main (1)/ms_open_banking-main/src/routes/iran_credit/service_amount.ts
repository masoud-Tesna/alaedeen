export default {
  reportJSON: {
    startup: 100000,
    sm_business: 100000,
    md_business: 100000,
    lg_business: 90000,
    buyPrice: 80000,
  },
  reportJSONLegal: {
    startup: 140000,
    sm_business: 140000,
    md_business: 140000,
    lg_business: 130000,
    buyPrice: 120000,
  },
};
