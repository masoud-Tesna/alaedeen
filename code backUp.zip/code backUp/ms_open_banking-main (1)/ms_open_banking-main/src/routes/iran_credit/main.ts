import { Router } from "express";
import controller from "../../app/http/controllers/iran_credit/main";
import { startRequestValidationChain } from "../../app/http/requests/iran_credit/startRequest";

import { validateValidationChain } from "../../app/http/requests/iran_credit/validate";
import {
  reportJSONValidationChain,
  checkICSToken,
} from "../../app/http/requests/iran_credit/reportJSON";
import { reportLinkValidationChain } from "../../app/http/requests/iran_credit/reportLink";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.post(
  "/open-banking/v1/ic-start/etc",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  startRequestValidationChain,
  mspack.express_validator_resault_mw,
  controller.startRequest
);

router.post(
  "/open-banking/v1/ic-validate/etc",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  validateValidationChain,
  mspack.express_validator_resault_mw,
  controller.validate
);

router.get(
  "/open-banking/v1/ic-report-json/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_multi_mw(
    service_amount.reportJSON,
    service_amount.reportJSONLegal,
    "identity",
    "exist" as any
  ),
  reportJSONValidationChain,
  mspack.express_validator_resault_mw,
  checkICSToken,
  controller.reportJSON
);

router.get(
  "/open-banking/v1/ic-report-link/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,

  mspack.require_credit_multi_mw(
    service_amount.reportJSON,
    service_amount.reportJSONLegal,
    "identity",
    "exist" as any
  ),
  reportLinkValidationChain,
  mspack.express_validator_resault_mw,
  controller.reportLink
);

export default router;
