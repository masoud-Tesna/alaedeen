import { Router } from "express";
import controller from "../../app/http/controllers/finnotech/inquiry/main";
import { ibanInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/iban";
import { shahkarInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/shahkar";
import { facilityInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/facility";
import { backChequesInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/backCheques";
import { drivingOffenseInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/drivingOffense";
import { cardInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/card";
import { billingInquiryValidationChain } from "../../app/http/requests/finnotech/inquiry/billing";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

// router.post(
//   "/open-banking/v1/iban/inquiry",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.ibanInquiry),
//   ibanInquiryValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.ibanInquiry
// );

// router.post(
//   "/open-banking/v1/shahkar/inquiry",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.shahkarInquiry),
//   shahkarInquiryValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.shahkarInquiry
// );

router.post(
  "/open-banking/v1/facility/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.facilityInquiry),
  facilityInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.facilityInquiry
);

router.post(
  "/open-banking/v1/back-cheques/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.backChequesInquiry),
  backChequesInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.backChequesInquiry
);

router.post(
  "/open-banking/v1/driving-offense/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.drivingOffenseInquiry),
  drivingOffenseInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.drivingOffenseInquiry
);

router.post(
  "/open-banking/v1/billing/inquiry",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.drivingOffenseInquiry),
  billingInquiryValidationChain,
  mspack.express_validator_resault_mw,
  controller.billingInquiry
);

// router.post(
//   "/open-banking/v1/cards/inquiry",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.cardInquiry),
//   cardInquiryValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.inquiryCard
// );

export default router;
