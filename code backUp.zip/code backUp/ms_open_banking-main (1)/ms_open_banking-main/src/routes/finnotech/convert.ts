import { Router } from "express";
import controller from "../../app/http/controllers/finnotech/convert/main";
import {
  cardToIbanValidationChain,
  cardToIbanArrayValidationChain,
} from "../../app/http/requests/finnotech/convert/cardToIban";
import { cardToDepositValidationChain } from "../../app/http/requests/finnotech/convert/cardToDeposit";
import { depositToIbanValidationChain } from "../../app/http/requests/finnotech/convert/depositToIban";
import { depositOwnerVerificationsValidationChain } from "../../app/http/requests/finnotech/convert/depositOwnerVerifications";
import service_amount from "./service_amount";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

// router.post(
//   "/open-banking/v1/card-iban/convert",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.cardToIban),
//   cardToIbanValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.cardToIban
// );

// router.post(
//   "/open-banking/v1/card-iban-array/convert",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_multi_mw(
//     service_amount.cardToIban,
//     service_amount.cardToIban,
//     "cards",
//     "length" as any
//   ),
//   cardToIbanArrayValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.cardToIbanArray
// );

// router.post(
//   "/open-banking/v1/card-deposit/convert",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.cardToDeposit),
//   cardToDepositValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.cardToDeposit
// );

router.post(
  "/open-banking/v1/deposit-owner-verifications/convert",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_APIkey_limit_count_mw,
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  mspack.require_credit_mw(service_amount.depositOwnerVerifications),
  depositOwnerVerificationsValidationChain,
  mspack.express_validator_resault_mw,
  controller.depositOwnerVerifications
);

// router.post(
//   "/open-banking/v1/deposit-iban/convert",
//   mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
//   mspack.check_scopes_mw.default<IUserDoc>(scope, User),
//   mspack.check_APIkey_limit_count_mw,
//   mspack.check_IP_mw,
//   mspack.require_credit_mw(service_amount.depositToIban),
//   depositToIbanValidationChain,
//   mspack.express_validator_resault_mw,
//   controller.depositToIban
// );
export default router;
