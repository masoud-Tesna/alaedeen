import { Router } from "express";
import controller from "../../app/http/controllers/finnotech/authorization_code/main";
import { authPageValidationChain } from "../../app/http/requests/finnotech/authorization_code/authPage";
import { getBalanceValidationChain } from "../../app/http/requests/finnotech/authorization_code/getBalance";
import { getStatementValidationChain } from "../../app/http/requests/finnotech/authorization_code/getStatement";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";
import service_amount from "./service_amount";

const router = Router();

router.post(
  "/open-banking/v1/authorize/auth-code",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_IP_mw,
  authPageValidationChain,
  mspack.express_validator_resault_mw,
  controller.getAuthPage
);

router.get("/finnotech/authorize/back", controller.callBack);

router.post(
  "/open-banking/v1/get-balance/auth-code",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_IP_mw,
  mspack.require_credit_mw(service_amount.getBalance),
  getBalanceValidationChain,
  mspack.express_validator_resault_mw,
  controller.getBalance
);
router.post(
  "/open-banking/v1/get-statement/auth-code",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_IP_mw,
  mspack.require_credit_mw(service_amount.getStatement),
  getStatementValidationChain,
  mspack.express_validator_resault_mw,
  controller.getStatement
);
export default router;
