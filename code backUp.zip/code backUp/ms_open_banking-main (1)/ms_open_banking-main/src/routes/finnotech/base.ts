import { Router } from "express";
import controller from "../../app/http/controllers/finnotech/base/main";
import scope from "./scope";
import mspack from "mspack";
import User, { IUserDoc } from "../../app/models/user";

const router = Router();

router.get(
  "/open-banking/v1/bank-info/base",
  mspack.check_apiKeyAuth_mw.default<IUserDoc>(User),
  mspack.check_scopes_mw.default<IUserDoc>(scope, User),
  mspack.check_IP_mw,
  mspack.rate_limiter_mw(),
  controller.bankInfo
);

export default router;
