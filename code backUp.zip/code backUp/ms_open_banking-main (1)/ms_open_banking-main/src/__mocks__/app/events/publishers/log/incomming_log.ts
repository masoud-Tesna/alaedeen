export default function (data: any): Promise<any> {
  return new Promise((resolve, reject) => {
    resolve("its mock");
  });
}
