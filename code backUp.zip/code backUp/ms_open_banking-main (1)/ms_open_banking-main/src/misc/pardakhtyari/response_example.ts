export default {
  inquirySIAH: {
    result: 0,
    requestRejectionReasons: null,
    sayahInquiryDto: {
      identifierType: "REAL_LOCAL_RESIDENT",
      iban: "IR180170000000351016641004",
      identifier: "0451684486",
    },
    sayahInquiryResponse: {
      returnValue: true,
      hasError: false,
      errors: [],
    },
    sayahIsExistResponse: null,
  },
};
