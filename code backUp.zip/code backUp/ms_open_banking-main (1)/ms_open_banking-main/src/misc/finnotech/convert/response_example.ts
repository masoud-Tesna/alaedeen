export default {
  cardToIban: {
    result: {
      IBAN: "IR320160000000000147234273",
      bankName: "بانک کشاورزی",
      deposit: "147234273",
      card: "6037701533058290",
      depositStatus: "02",
      depositDescription: "حساب فعال است",
      depositOwners: [
        {
          firstName: "test",
          lastName: "test",
        },
      ],
    },
    status: "DONE",
  },
  cardToDeposit: {
    result: {
      destCard: "6037-70xx-xxxx-8072",
      name: "test test",
      result: "0",
      description: "موفق",
      doTime: "1400/06/13 11:05:48",
      deposit: "147234273",
    },
    status: "DONE",
  },
  depositToIban: {
    result: {
      deposit: "0100627732002",
      accountStatus: "02",
      bankName: "بانک آينده",
      iban: "IR390620000000100627732002",
      depositOwners: "شرکت  با مسئولیت  محدود معمار ان  فناوری   هوشمند / فعال",
    },
    status: "DONE",
  },
};
