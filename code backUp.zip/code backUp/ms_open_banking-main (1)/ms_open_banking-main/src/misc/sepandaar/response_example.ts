export default {
  billInquiry: {
    followCode: "2098129275",
    statusId: "1",
    errorMessage: "",
    errorStatus: 0,
  },
};
