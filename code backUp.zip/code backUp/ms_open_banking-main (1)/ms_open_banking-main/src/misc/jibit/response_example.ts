export default {
  cardToIban: {
    result: {
      IBAN: "IR320160000000000147234782",
      bankName: "KESHAVARZI",
      deposit: "147234782",
      card: "6037701533058290",
      depositStatus: "02",
      depositDescription: "حساب فعال است",
      depositOwners: [
        {
          firstName: "سامان",
          lastName: "افسري",
        },
      ],
    },
    status: "DONE",
  },

  shahkarInquiry: {
    result: {
      isValid: true,
    },
    status: "DONE",
  },
  inquiryCard: {
    cardInfo: {
      bank: "TEJARAT",
      type: "DEBIT",
      ownerName: "اقاعليزاده كلخوران آيلر",
      depositNumber: "0003609572956",
      providerCode: "SADERAT",
    },
  },
  inquiryCardNumberIdentity: {
    matched: true,
  },

  cardToDeposit: {
    result: {
      destCard: "6037-70xx-xxxx-8072",
      name: "test test",
      result: "0",
      description: "موفق",
      doTime: "1400/06/13 11:05:48",
      deposit: "147234273",
    },
    status: "DONE",
  },
  inquiryCardNumberWithName: {
    matched: true,
  },
};
