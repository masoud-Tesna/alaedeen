export default {
  payaPayment: {
    referenceId: "14010124056201061111",
    ownerName: "test",
    currency: "IRR",
    transferStatus: "READY_TO_TRANSFER",
    amount: 10000,
    ibanNumber: "IR000550015270104184012345",
    description: "paya payment request",
    transactionStatus: "ACCEPTED",
    sourceIbanNumber: "IR000060081404003014012345",
    factorNumber: "1649837332111",
    transferDescription: "paya payment request",
  },

  normalPayment: {
    referenceNumber: "00001649847223673490",
  },
};
