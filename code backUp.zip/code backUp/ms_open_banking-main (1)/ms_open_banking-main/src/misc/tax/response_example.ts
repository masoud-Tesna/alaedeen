export default {
  inquiryTax: {
    followCode: "2098129275",
    statusId: "1",
    errorMessage: "",
    errorStatus: 0,
  },
  registerTax: {
    followCode: "2121110111",
    shahkarValid: false,
    tprID: "85b4a204-c552-435f-a5bd-b15f8000fe02",
    errorStatus: 0,
    errorMessage: "",
  },
};
