export default {
  nationalIdentityInquiry: {
    transactionState: "SUCCESS",
    transactionTime: 1633944353086,
    uuid: "93eb426b-6cf1-4b7b-800c-1a66674ec95a",
    respObject: {
      nationalCode: "23347315",
      firstName: "test",
      lastName: "test",
      fatherName: "test",
      birthDate: "13270310",
      alive: true,
    },
  },
  ibanInquiry: {
    transactionState: "SUCCESS",
    transactionTime: 1635930194918,
    uuid: "66dc0e6f-b1db-4a5c-8978-805af1c53a91",
    respObject: {
      bank: "BKV",
      accountNumber: "147231111",
      ibanNumber: "IR852160000000000147111111",
      firstName: "test",
      lastName: "test",
      accountStatus: "Active",
      nationalCode: "",
    },
  },

  cardInquiry: {
    transactionState: "SUCCESS",
    transactionTime: 0,
    uuid: "65d47214-60d4-47bc-abe0-d0bfe2b8d21a",
    respObject: {
      ownerName: "test test",
      accountNumber: "611828005171011111",
      bank: "SAM",
      iban: null,
    },
  },
  ibanIdentityInquiry: {
    transactionState: "SUCCESS",
    transactionTime: 1634109155628,
    uuid: "aa0b75c1-9333-4f0d-b413-e763e83dde24",
    respObject: "MOST_PROBABLY",
  },

  depositToIban: {
    transactionState: "SUCCESS",
    transactionTime: 1653213994234,
    uuid: "51efc367-ec56-496e-82ae-3b290599310a",
    respObject: {
      accountNumber: "0003917971111",
      ibanNumber: "IR480160000000003917971111",
    },
  },
};
