import express, { Request, Response } from "express";
import mspack from "mspack";
import { join } from "path";
import { json } from "body-parser";
import routes from "./routes/index";
import helmet from "helmet";
import cookieSession from "cookie-session";
import cors from "cors";
import events from "./util/events";
import { responseHandler } from "express-intercept";
const app = express();

mspack.startQueueEvents(events, mspack.redis.default.client);
app.use(json());
app.use(cors());
app.use(helmet());
app.use(
  responseHandler().getResponse((res: Response) => events.emit("res:end", {}))
);
//this setting for that we are using nginx web proxy
app.set("trust proxy", true);

//cookies
app.use(
  cookieSession({
    name: "ms",
    secure: process.env.NODE_ENV !== "test",
    signed: false,
  })
);

app.use(mspack.request_queue_handler_mw(mspack.redis.default.client));

//routes
for (let routesItem of Object.values(routes)) {
  app.use("/api", routesItem);
}

app.get("/api/open-banking/mock-route", (req: Request, res: Response) => {
  res.status(200).json({});
});
//err handler
app.use(mspack.error_handler_mw(join(__dirname, "./logs")));
app.use("*", (req: Request, res: Response) => {
  res.status(404).json({
    status: "failed",
    description: {
      statusCode: 404,
      message: "URL not found!",
      details: [],
      trackID: "",
      timeStamp: new Date().getTime(),
    },
  });
});

//res:end event must be emitted for remiving a job from queue
export default app;
