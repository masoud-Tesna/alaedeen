const banks = {
  BMI: "017", // meli
  PAS: "057", // pasragad
  BSP: "015", // sepah
  BSI: "019", // saderat
  MEL: "012", // melat
  SAM: "056", // saman
  BKV: "016", //keshvarzi
  TEJ: "018", //tejarat
  SAD: "020", //saderat
  ENB: "055", //eghtesad novin
  REF: "013", //refah
  BMK: "014", //maskan
  AYN: "062", //ayandeh
  DEY: "066", //dey
  SIN: "059", //sina
  PAR: "054", //parsian
  BKA: "053", //karafarin
  RES: "070", //resalat
  ANS: "063", //ansar
  IRZ: "069", //iranzamin
  BSM: "011", //sanat & madan
  SAR: "058", //sarmaye
  BTS: "020", //tosee sadearat
  SHR: "061", //shahr
  HEK: "065", //hekmat,
  KHMI: "078", //khavarminane ,
  BTT: "022", //tosee taavon
  PST: "021", //post
  MEH: "060", //mehr ,
  KSAC: "073", //kosar ,
  GHA: "052", //ghavamin ,
  NOR: "080", //noor
}; //finnotech

const banksTejarat = {
  BMI: "17", // meli
  PAS: "57", // pasragad
  BSP: "15", // sepah
  BSI: "19", // saderat
  MEL: "12", // melat
  SAM: "56", // saman
  BKV: "16", //keshvarzi
  TEJ: "18", //tejarat
  SAD: "20", //saderat
  ENB: "55", //eghtesad novin
  REF: "13", //refah
  BMK: "14", //maskan
  AYN: "62", //ayandeh
  DEY: "66", //dey
  SIN: "59", //sina
  PAR: "54", //parsian
  BKA: "53", //karafarin
  RES: "70", //resalat
  ANS: "63", //ansar
  IRZ: "69", //iranzamin
  BSM: "11", //sanat & madan
  SAR: "58", //sarmaye
  BTS: "20", //tosee sadearat
  SHR: "61", //shahr
  HEK: "65", //hekmat,
  KHMI: "78", //khavarminane ,
  BTT: "22", //tosee taavon
  PST: "21", //post
  MEH: "60", //mehr ,
  KSAC: "73", //kosar ,
  GHA: "52", //ghavamin ,
  NOR: "80", //noor
};

const banksFaraboom = {
  BMI: "MELIIR", // meli
  PAS: "BKBPIR", // pasragad
  BSP: "SEPBIR", // sepah
  MEL: "BKMTIR", // melat
  SAM: "SABCIR", // saman
  BKV: "KESHIR", //keshvarzi
  TEJ: "BTEJIR", //tejarat
  ENB: "BEGNIR", //eghtesad novin

  BMK: "BKMNIR", //maskan
  AYN: "AYBKIR", //ayandeh
  DEY: "DAYBIR", //dey
  SIN: "SINAIR", //sina
  PAR: "BKPAIR", //parsian
  ANS: "ANSBIR", //ansar
  IRZ: "IRZAIR", //iranzamin
  BSM: "BOIMIR", //sanat & madan
  SAR: "SRMBIR", //sarmaye
  // BTS: "BTOSIR", //tosee sadearat
  SHR: "CIYBIR", //shahr
  HEK: "HEKMIR", //hekmat,
  KHMI: "KHMIIR", //khavarminane ,
  // BTT: "022", //tosee taavon
  // PST: "021", //post
  MEH: "MEHRIR", //mehr ,
  // KSAC: "073", //kosar ,
  // GHA: "052", //ghavamin ,
  // NOR: "080", //noor
};
const checkBankNameValidity = (param: string): boolean => {
  return Object.keys(banks).includes(param);
};

export { checkBankNameValidity };

export default function (bank: any, provider?: string) {
  if (provider === "faraboom")
    //@ts-ignore
    return banksFaraboom[bank];
  if (provider === "tejarat")
    //@ts-ignore
    return banksTejarat[bank];
  //@ts-ignore
  return banks[bank];
}
