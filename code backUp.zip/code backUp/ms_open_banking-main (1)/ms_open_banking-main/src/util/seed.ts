import User from "../app/models/user";
import mongoose from "mongoose";

export default async function (): Promise<any> {
  try {
    const user = await User.build({
      _id: mongoose.Types.ObjectId(),
      email: "test@gmail.com",
      password: "12344321",
      username: "test",
      mobile: "09102972559",
      firstName: "saman",
      lastName: "afsari",
      country: "IR",
      timezone: "UTC +4:30",
      organizationName: "",
    });

    await user.save();
  } catch (error) {
    throw error;
  }
}
