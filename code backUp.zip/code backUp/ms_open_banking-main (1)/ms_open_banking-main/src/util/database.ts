import mspack from "mspack";
declare const global: NodeJS.Global;

export default async function (): Promise<void> {
  const mongo = new mspack.mongodb_connection(
    process.env.MONGO_CONNECTION_STRING_OPEN_BANKING!
  );
  await mongo.start();
  global.mongoClient = mongo.client;
}
