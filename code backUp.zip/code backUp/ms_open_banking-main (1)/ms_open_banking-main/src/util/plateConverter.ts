export default (plateNumber: string) => {
  const plateNumberStringify = plateNumber.toString();
  let response;

  if (plateNumberStringify.includes("ا"))
    response = plateNumberStringify.replace("ا", "01");
  if (plateNumberStringify.includes("ت"))
    response = plateNumberStringify.replace("ت", "04");
  if (plateNumberStringify.includes("د"))
    response = plateNumberStringify.replace("د", "10");
  if (plateNumberStringify.includes("ش"))
    response = plateNumberStringify.replace("ش", "16");
  if (plateNumberStringify.includes("ع"))
    response = plateNumberStringify.replace("ع", "21");
  if (plateNumberStringify.includes("ک"))
    response = plateNumberStringify.replace("ک", "25");
  if (plateNumberStringify.includes("م"))
    response = plateNumberStringify.replace("م", "28");
  if (plateNumberStringify.includes("ه"))
    response = plateNumberStringify.replace("ه", "31");
  if (plateNumberStringify.includes("ب"))
    response = plateNumberStringify.replace("ب", "02");
  if (plateNumberStringify.includes("ث"))
    response = plateNumberStringify.replace("ث", "05");
  if (plateNumberStringify.includes("ز"))
    response = plateNumberStringify.replace("ز", "13");
  if (plateNumberStringify.includes("ص"))
    response = plateNumberStringify.replace("ص", "17");
  if (plateNumberStringify.includes("ف"))
    response = plateNumberStringify.replace("ف", "23");
  if (plateNumberStringify.includes("گ"))
    response = plateNumberStringify.replace("گ", "26");
  if (plateNumberStringify.includes("ن"))
    response = plateNumberStringify.replace("ن", "29");
  if (plateNumberStringify.includes("ی"))
    response = plateNumberStringify.replace("ی", "32");
  if (plateNumberStringify.includes("پ"))
    response = plateNumberStringify.replace("پ", "03");
  if (plateNumberStringify.includes("ج"))
    response = plateNumberStringify.replace("ج", "06");
  if (plateNumberStringify.includes("س"))
    response = plateNumberStringify.replace("س", "15");
  if (plateNumberStringify.includes("ط"))
    response = plateNumberStringify.replace("ط", "19");
  if (plateNumberStringify.includes("ق"))
    response = plateNumberStringify.replace("ق", "24");
  if (plateNumberStringify.includes("ل"))
    response = plateNumberStringify.replace("ل", "27");
  if (plateNumberStringify.includes("و"))
    response = plateNumberStringify.replace("و", "30");

  return response;
};
