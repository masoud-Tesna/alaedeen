import { Request, Response, NextFunction } from "express";
import mongoose from "mongoose";

import _ from "lodash";
import { Stan } from "node-nats-streaming";

function publish(data: any, client: Stan): Promise<any> {
  return new Promise((resolve, reject) => {
    client.publish("APIkey:updated", JSON.stringify(data), (err, aGuid) => {
      if (err) reject(err);
      else resolve(aGuid);
    });
  });
}

interface IAccomplisher {
  email: string;
  lastName: string;
  firstName: string;
  OAuthAPIkey?: any[];
}

export default async <T extends IAccomplisher>(
  userModel: mongoose.Model<T>,
  req: Request & any,
  nats: Stan
): Promise<T | undefined> => {
  try {
    const APIkey = req.headers.apikey as string;
    const AppName = req.headers.appname as string;

    const user = await userModel.findById(req.APIkeyPayload.userId);

    for (let i of user?.OAuthAPIkey!) {
      if (i.appName === AppName && i.APIkey === APIkey) {
        i!.usageCount!++;
      }
    }

    await publish(
      {
        id: user?.id,
        email: user!.email,
        firstName: user!.firstName,
        lastName: user!.lastName,
        OAuthAPIkey: user!.OAuthAPIkey!,
      },
      nats
    );

    // setTimeout(async () => {
    //     await publish(
    //       {
    //         id: user?.id,
    //         email: user!.email,
    //         firstName: user!.firstName,
    //         lastName: user!.lastName,
    //         OAuthAPIkey: user!.OAuthAPIkey!,
    //       },
    //       nats
    //     );
    //   }, 2000);

    return user!;
    //await user!.save();
  } catch (error) {
    throw new Error(error.message);
  }
};
