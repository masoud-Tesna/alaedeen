interface IReturn {
  replacement: boolean;
  response: any;
  provider: string;
}

export default async function (
  inputs: any,
  replacementService: any,
  functionName: string,
  provider: string,
  status: number
): Promise<IReturn> {
  try {
    if (status === 500 || status === 424) {
      try {
        const response = await replacementService[functionName](inputs);

        response.provider = provider;
        return { response, provider, replacement: true };
      } catch (error: any) {
        // throw error;
        console.log(error);
        return { response: null, provider, replacement: false };
      }
    } else {
      return { response: null, provider, replacement: false };
    }
  } catch (error) {
    throw error;
  }
}
