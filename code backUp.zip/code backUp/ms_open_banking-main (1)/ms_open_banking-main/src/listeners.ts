import user_registered_listeners from "./app/events/listeners/user/user_registered";
import user_transaction_listeners from "./app/events/listeners/user/user_transaction";
import user_updated_listeners from "./app/events/listeners/user/user_updated";
import user_logined_listeners from "./app/events/listeners/user/user_logined";
import user_banned_listeners from "./app/events/listeners/user/user_banned";
import user_resetPassword_listeners from "./app/events/listeners/user/user_resetPassword";
import user_unBanned_listeners from "./app/events/listeners/user/user_unBanned";
import user_changeRole_listeners from "./app/events/listeners/user/user_changeRole";
import user_verfiyedEmail_listeners from "./app/events/listeners/user/user_verfiyedEmail";
import APIkey_created_listeners from "./app/events/listeners/APIkey/APIkey_created";
import APIkey_updated_listeners from "./app/events/listeners/APIkey/APIkey_updated";
import APIKey_refreshed_listeners from "./app/events/listeners/APIkey/APIKey_refreshed";

export default () => {
  user_registered_listeners();
  user_verfiyedEmail_listeners();
  user_updated_listeners();
  user_logined_listeners();
  user_resetPassword_listeners();
  user_banned_listeners();
  user_unBanned_listeners();
  user_changeRole_listeners();
  user_transaction_listeners();
  APIkey_created_listeners();
  APIkey_updated_listeners();
  APIKey_refreshed_listeners();
};
