import { MongoMemoryServer } from "mongodb-memory-server";
import User from "../app/models/user";
import mspack from "mspack";
import mongoose from "mongoose";
import seedDb from "../util/seed";
import request from "supertest";
import app from "../app";
declare const global: NodeJS.Global;

let MMS: MongoMemoryServer;

jest.mock("../app/events/publishers/user/transaction.ts");
jest.mock("../app/events/publishers/log/incomming_log.ts");

process.env.FINNOTECH_CLIENT_ID = "satpay";
process.env.FINNOTECH_PASSWORD = "f9d3049d92628c88ad43";
process.env.FINNOTECH_NID = "0383790931";
process.env.IRANCREDIT_CLIENT_ID = "satpayusr";
process.env.IRANCREDIT_PASSWORD = "SR1nNI4V";
process.env.SHAHIN_CLIENT_ID = "StK0TYgH5C";
process.env.SHAHIN_PASSWORD = "tQ0A8jvio6";

beforeAll(async () => {
  process.env.JWT_SECRET = "test_secret";
  process.env.JWT_REFRESH_SECRET = "test_secret";
  process.env.APIKEY_JWT_SECRET = "APIkey_test_secret";
  process.env.APIKEY_JWT_REFRESH_SECRET = "APIkey_test_secret";

  MMS = await MongoMemoryServer.create();
  const connectionString = MMS.getUri();
  await mongoose.connect(connectionString, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  });

  await seedDb();
});

beforeEach(async () => {
  jest.clearAllMocks();
  const collections = await mongoose.connection.db.collections();

  for (let collection of collections) {
    await collection.deleteMany({});
  }
  await seedDb();
});

afterAll(async () => {
  await mongoose.connection.close();
  await MMS.stop();
});

global.getUserID = async (email: string) => {
  const user = await User.findOne({ email });
  return user!.id;
};

global.signAPIkey = async (
  expiresIn: string,
  scope: string[],
  level: any,
  grantType: any,
  IP: string[],
  appName: string,
  isSandBox?: boolean
): Promise<{ refreshKey: string; APIkey: string }> => {
  const findedUser = await User.findOne({ email: "test@gmail.com" });

  const token = mspack.APIkey_jwt_helper.default.signToken(
    {
      userId: findedUser?.id,
      userName: "test",
      IP: ["1.1.1.1"],
      email: "test@gmail.com",
      role: "developer" as any,
      appName: "test",
    },
    expiresIn,
    "9000d"
  );

  await findedUser?.APIkey({
    APIkey: token.APIkey,
    refreshAPIkey: token.refreshKey,
    scopes: scope,
    level: level,
    grantType: grantType,
    IP,
    appName,
    lifeTime: 432000000, //5d milliseconds,
    isSandBox: isSandBox!,
  });

  await findedUser?.save();

  return { refreshKey: token.refreshKey, APIkey: token.APIkey };
};

global.balance = async (balance: number): Promise<any> => {
  const findedUser = await User.findOne({ email: "test@gmail.com" });
  if (findedUser) {
    findedUser.balance = balance;
  }
  await findedUser?.save();
};
