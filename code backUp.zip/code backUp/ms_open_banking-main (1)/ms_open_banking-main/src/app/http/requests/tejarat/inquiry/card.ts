import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const cardInquiryValidationChain = [
  check("cardNumber", "Invalid cardNumber")
    .notEmpty()
    .withMessage("CardNumber must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("CardNumber must be string")
    .bail()
    .isLength({ min: 16, max: 16 })
    .withMessage("CardNumber must be 16 char"),
  // .bail()
  // .isIn(["BSI"])
  // .withMessage("Bank is invalid")
  // .bail(),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { cardInquiryValidationChain, getUserData };
