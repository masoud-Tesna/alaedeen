import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";
import ICSTokenModel from "../../../models/ICSToken";

const reportJSONValidationChain = [
  check("token", "Invalid token")
    .notEmpty()
    .withMessage("Token must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Token must be string"),

  check("identity", "Invalid identity")
    .notEmpty()
    .withMessage("Identity must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Identity must be string")
    .bail()
    .isDecimal()
    .withMessage("Identity must be digits")
    .bail()
    .isLength({ min: 10, max: 11 })
    .withMessage("Identity must be at least 10 and at maximum 11 char"),
];

const checkICSToken = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const identity = req.query.identity as string;
    const ics = await ICSTokenModel.findOne({
      token: req.query.token as string,
    });
    if (
      ics &&
      (ics.legalPersonNationalCode === identity ||
        ics.realPersonNationalCode === identity)
    ) {
      if (ics.result) {
        req.report = ics.result;
      } else {
        req.ics = ics;
      }

      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Invalid token or identity!", 400);
    }
  } catch (error) {
    return next(error);
  }
};

export { reportJSONValidationChain, checkICSToken };
