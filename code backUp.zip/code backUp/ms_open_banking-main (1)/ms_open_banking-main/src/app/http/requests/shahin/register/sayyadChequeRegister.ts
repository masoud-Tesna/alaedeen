import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

// serialNo,
// seriesNo,
// accountOwners,
// name,
// shahabId,
// idCode,
// idType,
// receivers,
// signers,
// bank,
// branchCode,
// chequeType,
// reason,
// toIban,
const sayyadChequeRegisterValidationChain = [
  check("chequeSerial", "Invalid chequeSerial")
    .notEmpty()
    .withMessage("ChequeSerial must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("ChequeSerial must be string")
    .bail()
    .isLength({ min: 16, max: 16 })
    .withMessage("ChequeSerial must be 16 characters")
    .bail(),

  check("nationalCode", "Invalid nationalCode")
    .notEmpty()
    .withMessage("NationalCode must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("NationalCode must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("NationalCode must be 10 characters")
    .bail()
    .isDecimal()
    .withMessage("NationalCode must be digits"),

  check("sourceAccount", "Invalid sourceAccount")
    .notEmpty()
    .withMessage("SourceAccount must be provided")
    .bail()
    .isString()
    .withMessage("SourceAccount must be string")
    .bail()
    .isLength({ min: 26, max: 26 })
    .withMessage("SourceAccount must be 26 characters")
    .bail()
    .isDecimal()
    .withMessage("SourceAccount must be digits"),

  check("amount", "Invalid amount")
    .notEmpty()
    .withMessage("Amount must be provided")
    .bail()
    .isNumeric()
    .withMessage("Amount must be number"),

  check("chequeMedia", "Invalid amount")
    .notEmpty()
    .withMessage("ChequeMedia must be provided")
    .bail()
    .isIn(["paperCheck", "digitalCheck"])
    .withMessage("Invalid chequeMedia"),

  check("currency", "Invalid currency")
    .notEmpty()
    .withMessage("Currency must be provided")
    .bail()
    .isIn(["paperCheck", "digitalCheck"])
    .withMessage("Invalid chequeMedia"),

  check("description", "Invalid description")
    .notEmpty()
    .withMessage("Description must be provided")
    .bail()
    .isString()
    .withMessage("Description must be string"),

  check("dueDate", "Invalid dueDate")
    .notEmpty()
    .withMessage("DueDate must be provided")
    .trim()
    .isString()
    .withMessage("DueDate must be string")
    .bail()
    .isLength({ max: 8, min: 8 })
    .withMessage("DueDate must 8 characters")
    .bail()
    .custom((value) => {
      if (isNaN(value.charAt(0))) {
        return false;
      }
      if (isNaN(value.charAt(1))) {
        return false;
      }
      if (isNaN(value.charAt(2))) {
        return false;
      }
      if (isNaN(value.charAt(3))) {
        return false;
      }
      if (isNaN(value.charAt(4))) {
        return false;
      }
      if (isNaN(value.charAt(5))) {
        return false;
      }
      if (isNaN(value.charAt(6))) {
        return false;
      }
      if (isNaN(value.charAt(7))) {
        return false;
      }
      return true;
    })
    .withMessage("DueDate format is invalid (yyyymmdd)"),

  check("sayadId", "Invalid sayadId")
    .notEmpty()
    .withMessage("SayadId must be provided")
    .bail()
    .isString()
    .withMessage("SayadId must be string")
    .bail()
    .isLength({ max: 16 })
    .withMessage("SayadId must not be greater than 16 characters")
    .bail()
    .isDecimal()
    .withMessage("SayadId must be digits"),

  check("serialNo", "Invalid serialNo")
    .notEmpty()
    .withMessage("SerialNo must be provided")
    .bail()
    .isString()
    .withMessage("SerialNo must be string")
    .bail()
    .isLength({ max: 16 })
    .withMessage("SerialNo must not be greater than 16 characters")
    .bail()
    .isDecimal()
    .withMessage("SerialNo must be digits"),
];

export { sayyadChequeRegisterValidationChain };
