import { check } from "express-validator";

const cardsHolderValidationChain = [
  check("pan", "Invalid pan")
    .notEmpty()
    .withMessage("Pan must be provided")
    .bail()
    .isDecimal()
    .withMessage("Pan must be digits")
    .bail()
    .isLength({ max: 16, min: 16 })
    .withMessage("Pan must be 16 char"),

  check("pin", "Invalid pin")
    .notEmpty()
    .withMessage("pin must be provided")
    .bail()
    .isDecimal()
    .withMessage("pin must be digits"),
];

export { cardsHolderValidationChain };
