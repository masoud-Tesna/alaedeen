import { check } from "express-validator";
import { Request, Response, NextFunction } from "express";
import mspack from "mspack";
import DirectDebit from "../../../../models/directDebit";

const getCovenantValidationChain = [
  check("traceNumber", "Invalid traceNumber")
    .notEmpty()
    .withMessage("TraceNumber must be provided")
    .bail()
    .isUUID()
    .withMessage("TraceNumber must be sent as RFC4122 UUIDs format")
    .bail()
    .custom(async (val, { req }): Promise<boolean> => {
      const directDebit = await DirectDebit.findOne({ traceNumber: val });
      if (directDebit) {
        req.report = directDebit;
        return Promise.resolve(true);
      }
      return Promise.resolve(false);
    })
    .withMessage("Dublicate traceNumber"),
];

export { getCovenantValidationChain };
