import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const SIAHInquiryValidationChain = [
  check("identifierType", "Invalid plateNumber")
    .notEmpty()
    .withMessage("IdentifierType must be provided")
    .bail()
    .isNumeric()
    .withMessage("IdentifierType must be number")
    .bail()
    .isIn([0, 1])
    .withMessage("Invalid identifierType"),

  check("nationalID", "Invalid nationalID")
    .notEmpty()
    .withMessage("NationalID must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("NationalID must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("NationalID must be 10 characters")
    .bail()
    .isDecimal()
    .withMessage("NationalID must be digits"),

  check("iban", "Invalid iban")
    .notEmpty()
    .withMessage("Iban must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Iban must be string")
    .bail()
    .isLength({ min: 26, max: 26 })
    .withMessage("Iban must be 26 characters")
    .bail()
    .custom((val: string) => {
      if (val.charAt(0) !== "I" || val.charAt(1) !== "R") return false;
      else return true;
    })
    .withMessage("Iban must be starts with IR characters"),
];

export { SIAHInquiryValidationChain };
