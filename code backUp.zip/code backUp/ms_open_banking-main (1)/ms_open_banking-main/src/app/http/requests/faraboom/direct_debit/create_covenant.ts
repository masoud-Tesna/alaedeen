import { check } from "express-validator";
import moment from "moment";
import DirectDebit from "../../../../models/directDebit";
const createCovenantValidationChain = [
  check("mobile", "Invalid mobile")
    .notEmpty()
    .withMessage("Mobile must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Mobile must be string")
    .bail()
    .isLength({ min: 11, max: 11 })
    .withMessage("Mobile must be at least 9 and maximum 12 characters")
    .bail(),

  check("traceNumber", "Invalid traceNumber")
    .notEmpty()
    .withMessage("TraceNumber must be provided")
    .bail()
    .isUUID()
    .withMessage("TraceNumber must be sent as RFC4122 UUIDs format")
    .bail()
    .custom(async (val): Promise<boolean> => {
      const directDebit = await DirectDebit.findOne({ traceNumber: val });

      if (directDebit) return Promise.reject(false);
      return Promise.resolve(true);
    })
    .withMessage("Dublicate traceNumber"),

  check("nationalID", "Invalid nationalID")
    .notEmpty()
    .withMessage("NationalID must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("NationalID must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("NationalID must be 10 characters")
    .bail(),
  check("covenant.bank_code", "Invalid covenant.bank_code")
    .trim()
    .isString()
    .withMessage("Bank_code must be string")
    .bail()
    .notEmpty()
    .withMessage("Bank_code must be provided")
    .bail(),
  check("covenant.user_id", "Invalid covenant.user_id")
    .trim()
    .isString()
    .withMessage("User_id must be string")
    .bail()
    .notEmpty()
    .withMessage("User_id must be provided")
    .bail(),
  check("covenant.permission_ids", "Invalid covenant.permission_ids")
    .isArray()
    .withMessage("Permission_ids must be array")
    .bail()
    .notEmpty()
    .withMessage("Permission_ids must be provided")
    .bail()
    .custom((value, { req }) => {
      let error = true;
      value.map((item: any) => {
        if (typeof item !== "number") {
          error = false;
        }
      });
      return error;
    })
    .withMessage("Permission_ids items must be number"),

  check(
    "covenant.contract.expiration_date",
    "Invalid covenant.contract.expiration_date"
  )
    .trim()
    .isString()
    .withMessage("Expiration_date must be string")
    .bail()
    .notEmpty()
    .withMessage("Expiration_date must be provided")
    .bail()
    .custom((val) => {
      return moment(val, "YYYY-MM-DDTHH:mm:ss", true).isValid();
    })
    .withMessage("Expiration_date must be ISO string date")
    .custom((val, { req }) => {
      return !(new Date(val) < new Date());
    })
    .withMessage("Expiration_date must be greater than current date")
    .custom((val, { req }) => {
      return !(new Date(val) < new Date(req.body.covenant.contract.start_date));
    })
    .withMessage("Expiration_date must be greater than start_date"),
  check(
    "covenant.contract.max_daily_transaction_count",
    "Invalid covenant.contract.max_daily_transaction_count"
  )
    .trim()
    .isNumeric()
    .withMessage("Max_daily_transaction_count must be number")
    .bail()
    .notEmpty()
    .withMessage("Max_daily_transaction_count must be provided")
    .bail(),
  check(
    "covenant.contract.max_monthly_transaction_count",
    "Invalid covenant.contract.max_monthly_transaction_count"
  )
    .trim()
    .isNumeric()
    .withMessage("Max_monthly_transaction_count must be number")
    .bail()
    .notEmpty()
    .withMessage("Max_monthly_transaction_count must be provided")
    .bail(),

  check(
    "covenant.contract.max_transaction_amount",
    "Invalid covenant.contract.max_transaction_amount"
  )
    .trim()
    .isNumeric()
    .withMessage("Max_transaction_amount must be number")
    .bail()
    .notEmpty()
    .withMessage("Max_transaction_amount must be provided")
    .bail(),
  check("covenant.contract.start_date", "Invalid covenant.contract.start_date")
    .trim()
    .isString()
    .withMessage("Start_date must be isString")
    .bail()
    .notEmpty()
    .withMessage("Start_date must be provided")
    .bail()
    .custom((val) => {
      return moment(val, "YYYY-MM-DDTHH:mm:ss", true).isValid();
    })
    .withMessage("Start_date must be ISO string date")
    .custom((val) => {
      return !(new Date(val) < new Date());
    })
    .withMessage("Start_date must be greater than current date"),
  check("redirectURL", "Invalid redirectURL")
    .trim()
    .isURL()
    .withMessage("RedirectURL must be valid url")
    .bail()
    .notEmpty()
    .withMessage("RedirectURL must be provided")
    .bail(),
];

export { createCovenantValidationChain };
