import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const backChequesInquiryValidationChain = [
  check("nationalID", "Invalid nationalID")
    .notEmpty()
    .withMessage("NationalID must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("NationalID must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("NationalID must be 10 characters")
    .bail()
    .isDecimal()
    .withMessage("NationalID must be digits"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { backChequesInquiryValidationChain, getUserData };
