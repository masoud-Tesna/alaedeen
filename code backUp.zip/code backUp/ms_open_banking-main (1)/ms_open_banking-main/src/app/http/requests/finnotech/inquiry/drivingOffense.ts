import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const drivingOffenseInquiryValidationChain = [
  check("serial", "Invalid serial")
    .notEmpty()
    .withMessage("Serial must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Serial must be string")
    .bail()
    .isLength({ min: 8, max: 8 })
    .withMessage("Serial must be 8 characters")
    .bail(),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { drivingOffenseInquiryValidationChain, getUserData };
