import { check } from "express-validator";
import { Request, Response, NextFunction } from "express";
import mspack from "mspack";
import DirectDebit from "../../../../models/directDebit";

const startPayValidationChain = [
  check("payman_id", "Invalid payman_id")
    .notEmpty()
    .withMessage("Payman_id must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Payman_id must be string"),

  check("amount", "Invalid amount")
    .notEmpty()
    .withMessage("Amount must be provided")
    .bail()
    .isNumeric()
    .withMessage("Amount must be number"),

  check("description", "Invalid description")
    .optional({ checkFalsy: true })
    .bail()
    .trim()
    .isString()
    .withMessage("Description must be number"),
];

const startPayBillValidationChain = [
  check("payman_id", "Invalid payman_id")
    .notEmpty()
    .withMessage("Payman_id must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Payman_id must be string"),

  check("bill_id", "Invalid bill_id")
    .notEmpty()
    .withMessage("Bill_id must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Bill_id must be string"),
  check("pay_id", "Invalid pay_id")
    .notEmpty()
    .withMessage("Pay_id must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Pay_id must be string"),
];

const checkRequestAmount = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const directDebit = await DirectDebit.findOne({
      peymanID: req.body.payman_id,
    });
    if (!directDebit)
      throw new mspack.custom_error(`Payman_id not found,`, 404);

    if (
      directDebit.covenant.contract.max_transaction_amount >= req.body.amount
    ) {
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error(
        `Amount field must be lower than ${directDebit.covenant.contract.max_transaction_amount} for this covenant`,
        400
      );
    }
  } catch (error) {
    return next(error);
  }
};

export {
  startPayValidationChain,
  startPayBillValidationChain,
  checkRequestAmount,
};
