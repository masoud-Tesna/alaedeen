import { check } from "express-validator";

const balanceValidationChain = [
  check("depositNumber", "Invalid depositNumber")
    .notEmpty()
    .withMessage("DepositNumber must be provided")
    .bail()
    .isDecimal()
    .withMessage("DepositNumber must be digits")
    .bail()
    .isLength({ min: 6 })
    .withMessage("DepositNumber must be at least 6 char"),

  check("pan", "Invalid pan")
    .notEmpty()
    .withMessage("Pan must be provided")
    .bail()
    .isDecimal()
    .withMessage("Pan must be digits")
    .bail()
    .isLength({ max: 16, min: 16 })
    .withMessage("Pan must be 16 char"),

  check("pin", "Invalid pin")
    .notEmpty()
    .withMessage("Pin must be provided")
    .bail()
    .isDecimal()
    .withMessage("Pin must be digits"),

  check("cvv2", "Invalid cvv2")
    .notEmpty()
    .withMessage("Cvv2 must be provided")
    .bail()
    .isString()
    .withMessage("Cvv2 must be string"),

  check("exp_date", "Invalid exp_date")
    .notEmpty()
    .withMessage("Exp_date must be provided")
    .bail()
    .isDecimal()
    .withMessage("Exp_date must be digits"),

  check("bankId", "Invalid bankId")
    .notEmpty()
    .withMessage("BankId must be provided")
    .bail()
    .isIn([
      "BMI",
      "PAS",
      "BSP",
      "MEL",
      "SAM",
      "BKV",
      "TEJ",
      "ENB",
      "BMK",
      "AYN",
      "DEY",
      "SIN",
      "PAR",
      "ANS",
      "IRZ",
      "BSM",
      "SAR",
      "SHR",
      "HEK",
      "KHMI",
      "MEH",
    ])
    .withMessage("BankId is invalid"),
];

export { balanceValidationChain };
