import { check } from "express-validator";

const cardNumberWithNameValidationChain = [
  check("cardNumber", "Invalid cardNumber")
    .notEmpty()
    .withMessage("CardNumber must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("CardNumber must be string")
    .bail()
    .isLength({ min: 16, max: 16 })
    .withMessage("CardNumber must be 16 characters")
    .bail()
    .isDecimal()
    .withMessage("CardNumber must be digits"),
  check("name", "Invalid name")
    .notEmpty()
    .withMessage("Name must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Name must be string")
    .bail()
    .isLength({ min: 2 })
    .withMessage("Card must be at least 2 characters"),
];

export { cardNumberWithNameValidationChain };
