import { check } from "express-validator";

const tollDebtValidationChain = [
  check("license", "Invalid license")
    .notEmpty()
    .withMessage("License must be provided")
    .bail()
    .isString()
    .withMessage("License must be string"),

  check("token", "Invalid amount")
    .notEmpty()
    .withMessage("Token must be provided")
    .bail()
    .isString()
    .withMessage("Token must be string"),
];

export { tollDebtValidationChain };
