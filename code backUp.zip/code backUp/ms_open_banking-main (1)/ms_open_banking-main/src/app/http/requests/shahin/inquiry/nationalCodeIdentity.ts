import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const nationalCodeIdentityValidationChain = [
  check("birthDate", "Invalid birthDate")
    .notEmpty()
    .withMessage("birthDate must be provided")
    .trim()
    .isString()
    .withMessage("birthDate must be string")
    .bail()
    .isLength({ max: 8, min: 8 })
    .withMessage("birthDate must 8 characters")
    .bail()
    .custom((value) => {
      if (isNaN(value.charAt(0))) {
        return false;
      }
      if (isNaN(value.charAt(1))) {
        return false;
      }
      if (isNaN(value.charAt(2))) {
        return false;
      }
      if (isNaN(value.charAt(3))) {
        return false;
      }
      if (isNaN(value.charAt(4))) {
        return false;
      }
      if (isNaN(value.charAt(5))) {
        return false;
      }
      if (isNaN(value.charAt(6))) {
        return false;
      }
      if (isNaN(value.charAt(7))) {
        return false;
      }
      return true;
    })
    .withMessage("birthDate format is invalid"),
  check("nationalID", "Invalid nationalID")
    .notEmpty()
    .withMessage("NationalID must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("NationalID must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("NationalID must be 10 characters")
    .bail()
    .isDecimal()
    .withMessage("NationalID must be digits"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { nationalCodeIdentityValidationChain, getUserData };
