import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";
import moment from "moment";
const satnaValidationChain = [
  check("price", "Invalid price")
    .notEmpty()
    .withMessage("Price must be provided")
    .bail()
    .isNumeric()
    .withMessage("Price must be number")
    .bail()
    .custom((val: number) => {
      if (val < 500000000) return false;
      else return true;
    })
    .withMessage("Amount must be greater or equal than 500000000 rial"),

  check("description", "Invalid description")
    .optional({ checkFalsy: true })
    .bail()
    .isString()
    .withMessage("Description must be string")
    .bail(),

  check("receiverName", "Invalid receiverName")
    .notEmpty()
    .withMessage("ReceiverName must be provided")
    .bail()
    .isString()
    .withMessage("ReceiverName must be string")
    .bail(),

  check("receiverFamily", "Invalid receiverFamily")
    .notEmpty()
    .withMessage("ReceiverFamily must be provided")
    .bail()
    .isString()
    .withMessage("ReceiverFamily must be string")
    .bail(),

  check("receiverTelephoneNumber", "Invalid receiverTelephoneNumber")
    .notEmpty()
    .withMessage("ReceiverTelephoneNumber must be provided")
    .bail()
    .isString()
    .withMessage("ReceiverTelephoneNumber must be string")
    .isLength({ min: 10, max: 11 })
    .withMessage(
      "ReceiverTelephoneNumber must be at least 10 and maximum 11 characters"
    ),

  check("ibanNumber", "Invalid iban")
    .notEmpty()
    .withMessage("IbanNumber must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("IbanNumber must be string")
    .bail()
    .isLength({ min: 26, max: 26 })
    .withMessage("IbanNumber must be 26 characters")
    .bail()
    .custom((val: string) => {
      if (val.charAt(0) !== "I" || val.charAt(1) !== "R") return false;
      else return true;
    })
    .withMessage("IbanNumber must be starts with IR characters"),
];

const satnaReportValidationChain = [
  check("fromDate", "Invalid fromDate")
    .trim()
    .isString()
    .withMessage("FromDate must be string")
    .bail()
    .optional({ checkFalsy: true })

    .custom((val) => {
      return moment(val, "YYYY-MM-DD", true).isValid();
    })
    .withMessage("FromDate must be date"),
  check("toDate", "Invalid toDate")
    .trim()
    .isString()
    .withMessage("ToDate must be ToDate")
    .bail()
    .optional({ checkFalsy: true })
    .custom((val) => {
      return moment(val, "YYYY-MM-DD", true).isValid();
    })
    .withMessage("ToDate must be date")
    .custom((val, { req }) => {
      return !(new Date(val) < new Date(req.query!.SDate as string));
    })
    .withMessage("ToDate must be greater than FromDate"),
  check("description", "Invalid description")
    .optional({ checkFalsy: true })

    .isString()
    .withMessage("Description must be string")
    .bail(),

  check("englishDescription", "Invalid englishDescription")
    .optional({ checkFalsy: true })
    .isString()
    .withMessage("EnglishDescription must be string")
    .bail(),

  check("order", "Invalid order")
    .optional({ checkFalsy: true })
    .isString()
    .withMessage("Order must be string")
    .bail()
    .isIn(["ASC", "DESC"])
    .withMessage("Order is invalid"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { satnaValidationChain, satnaReportValidationChain, getUserData };
