import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";
import { checkBankNameValidity } from "../../../../../util/convert_bank_names";

const depositOwnerVerificationsValidationChain = [
  check("nationalCode", "Invalid nationalCode")
    .notEmpty()
    .withMessage("NationalCode must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("NationalCode must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("NationalCode must be 10 characters")
    .bail()
    .isDecimal()
    .withMessage("Card must be digits"),
  check("bank", "Invalid bank")
    .notEmpty()
    .withMessage("Bank must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Bank must be string")
    .bail()
    .isLength({ min: 3, max: 4 })
    .withMessage("Bank must be 3 characters")
    .bail()
    .custom((val) => {
      return checkBankNameValidity(val);
    })
    .withMessage("Invalid bank"),
  check("deposit", "Invalid deposit")
    .notEmpty()
    .withMessage("Deposit must be provided")
    .bail()
    .trim()
    .isDecimal()
    .withMessage("Deposit must be digits")
    .bail(),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { depositOwnerVerificationsValidationChain, getUserData };
