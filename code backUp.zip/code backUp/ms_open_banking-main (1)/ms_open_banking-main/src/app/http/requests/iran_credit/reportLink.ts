import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";
import ICSTokenModel from "../../../models/ICSToken";

const reportLinkValidationChain = [
  check("token", "Invalid token")
    .notEmpty()
    .withMessage("Token must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Token must be string"),

  check("identity", "Invalid identity")
    .notEmpty()
    .withMessage("Identity must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Identity must be string")
    .bail()
    .isDecimal()
    .withMessage("Identity must be digits")
    .bail()
    .isLength({ min: 10, max: 11 })
    .withMessage("Identity must be at least 10 and at maximum 11 char"),
];



export { reportLinkValidationChain };
