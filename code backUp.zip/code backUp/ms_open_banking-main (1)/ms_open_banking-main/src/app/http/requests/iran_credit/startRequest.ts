import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const startRequestValidationChain = [
  check("realPersonNationalCode", "Invalid realPersonNationalCode")
    .notEmpty()
    .withMessage("RealPersonNationalCode must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("RealPersonNationalCode must be string")
    .bail()
    .isLength({ min: 10, max: 10 })
    .withMessage("RealPersonNationalCode must be 10 characters")
    .bail()
    .isDecimal()
    .withMessage("RealPersonNationalCode must be digits"),
  check("mobileNumber", "Invalid mobileNumber")
    .notEmpty()
    .withMessage("MobileNumber must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("MobileNumber must be string")
    .bail()
    .isLength({ min: 10, max: 11 })
    .withMessage("MobileNumber must be at least 10 and maximum 11 characters")
    .bail()
    .isDecimal()
    .withMessage("MobileNumber must be digits"),
  check("legalPersonNationalCode", "Invalid legalPersonNationalCode")
    .trim()
    .isString()
    .withMessage("LegalPersonNationalCode must be string")
    .bail()
    .isLength({ min: 11, max: 11 })
    .withMessage("LegalPersonNationalCode must be 11 characters")
    .bail()
    .isDecimal()
    .withMessage("LegalPersonNationalCode must be digits")
    .optional({ checkFalsy: true }),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { startRequestValidationChain, getUserData };
