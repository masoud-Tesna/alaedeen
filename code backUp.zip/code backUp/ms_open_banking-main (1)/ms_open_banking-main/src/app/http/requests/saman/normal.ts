import { check } from "express-validator";

const normalValidationChain = [
  check("price", "Invalid price")
    .notEmpty()
    .withMessage("Price must be provided")
    .bail()
    .isNumeric()
    .withMessage("Price must be number")
    .bail(),

  check("destinationComment", "Invalid destinationComment")
    .optional({ checkFalsy: true })
    .isString()
    .withMessage("DestinationComment must be string"),
  check("additionalDocumentDesc", "Invalid additionalDocumentDesc")
    .optional({ checkFalsy: true })
    .isString()
    .withMessage("AdditionalDocumentDesc must be string"),
  check("sourceComment", "Invalid sourceComment")
    .optional({ checkFalsy: true })
    .isString()
    .withMessage("SourceComment must be string"),
  check("destinationDeposit", "Invalid destinationDeposit")
    .notEmpty()
    .withMessage("DestinationDeposit must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("DestinationDeposit must be string")
    .bail()
    .custom((val: string) => {
      if (val.includes("-")) return true;
      else return false;
    })
    .withMessage(
      "DestinationDeposit must be match to this format : d{3,4}-\\d{2,4}-\\d{1,8}-\\d{1,3}"
    ),
];

export { normalValidationChain };
