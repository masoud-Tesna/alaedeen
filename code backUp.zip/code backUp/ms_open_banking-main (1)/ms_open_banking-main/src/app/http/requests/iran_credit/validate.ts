import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const validateValidationChain = [
  check("code", "Invalid code")
    .notEmpty()
    .withMessage("Code must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Code must be string")
    .bail()
    .isLength({ min: 5, max: 5 })
    .withMessage("Code must be 5 characters")
    .bail()
    .isDecimal()
    .withMessage("Code must be digits"),
  check("token", "Invalid token")
    .notEmpty()
    .withMessage("Token must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Token must be string"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { validateValidationChain, getUserData };
