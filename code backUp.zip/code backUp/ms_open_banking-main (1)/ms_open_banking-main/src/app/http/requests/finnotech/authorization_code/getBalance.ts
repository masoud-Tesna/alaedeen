import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const getBalanceValidationChain = [
  check("token", "Invalid token")
    .notEmpty()
    .withMessage("Token must be provided")
    .bail()
    .isString()
    .withMessage("Token must be array"),
  check("deposit", "Invalid deposit")
    .notEmpty()
    .withMessage("Deposit must be provided")
    .bail()
    .trim()
    .isDecimal()
    .withMessage("Deposit must be digits"),
  check("refreshToken", "Invalid refreshToken")
    .notEmpty()
    .withMessage("RefreshToken must be provided")
    .bail()
    .isString()
    .withMessage("RefreshToken must be array"),
  check("bank", "Invalid bank")
    .notEmpty()
    .withMessage("Bank must be provided")
    .bail()
    .trim()
    .isDecimal()
    .withMessage("Bank must be digits")
    .bail()
    .isLength({ min: 3, max: 3 })
    .withMessage("Bank must be 3 characters"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { getBalanceValidationChain, getUserData };
