import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const deposiToIbanValidationChain = [
  check("sourceAccount", "Invalid sourceAccount")
    .notEmpty()
    .withMessage("SourceAccount must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("SourceAccount must be string")
    .bail()
    .isLength({ min: 7 })
    .withMessage("SourceAccount must be at least 7 characters")
    .bail(),

  check("bank", "Invalid bank")
    .notEmpty()
    .withMessage("Bank must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Bank must be string")
    .bail()
    .isIn([
      "ENB",
      "AYN",
      "PAS",
      "TEJ",
      "BTS",
      "DEY",
      "SAM",
      "BSP",
      "SAR",
      "SIN",
      "SAD",
      "BSM",
      "BKA",
      "BKV",
      "BMK",
      "BMI",
      "NOR",
      "MEL",
      "RES",
      "ANS",
      "IRZ",
      "BTT",
    ])
    .withMessage("Bank is invalid")
    .bail(),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { deposiToIbanValidationChain, getUserData };
