import { check } from "express-validator";
import User from "../../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const ibanInquiryValidationChain = [
  check("iban", "Invalid iban")
    .notEmpty()
    .withMessage("Iban must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("Iban must be string")
    .bail()
    .isLength({ min: 26, max: 26 })
    .withMessage("Iban must be 26 characters")
    .bail()
    .custom((val: string) => {
      if (val.charAt(0) !== "I" || val.charAt(1) !== "R") return false;
      else return true;
    })
    .withMessage("Iban must be starts with IR characters"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { ibanInquiryValidationChain, getUserData };
