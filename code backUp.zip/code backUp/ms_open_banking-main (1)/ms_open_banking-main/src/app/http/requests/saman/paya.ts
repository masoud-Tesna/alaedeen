import { check } from "express-validator";
import User from "../../../models/user";
import mspack from "mspack";
import { Request, Response, NextFunction } from "express";

const payaValidationChain = [
  check("price", "Invalid price")
    .notEmpty()
    .withMessage("Price must be provided")
    .bail()
    .isNumeric()
    .withMessage("Price must be number")
    .bail()
    .custom((val: number) => {
      if (val > 500000000) return false;
      else return true;
    })
    .withMessage("Amount must be lesser or equal than 500000000 rial"),

  check("description", "Invalid description")
    .optional({ checkFalsy: true })
    .bail()
    .isString()
    .withMessage("Description must be string")
    .bail(),

  check("ibanNumber", "Invalid iban")
    .notEmpty()
    .withMessage("IbanNumber must be provided")
    .bail()
    .trim()
    .isString()
    .withMessage("IbanNumber must be string")
    .bail()
    .isLength({ min: 26, max: 26 })
    .withMessage("IbanNumber must be 26 characters")
    .bail()
    .custom((val: string) => {
      if (val.charAt(0) !== "I" || val.charAt(1) !== "R") return false;
      else return true;
    })
    .withMessage("IbanNumber must be starts with IR characters"),
];

const payaReportValidationChain = [
  check("length", "Invalid length")
    .notEmpty()
    .withMessage("Length must be provided")
    .bail()
    .isNumeric()
    .withMessage("Length must be number")
    .bail()
    .custom((val: any) => {
      if (val < 0) {
        return false;
      }
      return true;
    })
    .withMessage("Length cant be negative or 0"),

  check("offset", "Invalid offset")
    .notEmpty()
    .withMessage("Offset must be provided")
    .bail()
    .isNumeric()
    .withMessage("Offset must be number")
    .bail()
    .custom((val: any) => {
      if (val <= 0) {
        return false;
      }
      return true;
    })
    .withMessage("Offset cant be negative or 0"),
];

const getUserData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await User.findById(req.APIkeyPayload.userId);
    if (user) {
      req.user = user;
      return next();
    } else {
      //99.9% unreachable code
      throw new mspack.custom_error("Authentication error!", 401);
    }
  } catch (error) {
    return next(error);
  }
};

export { payaValidationChain, getUserData, payaReportValidationChain };
