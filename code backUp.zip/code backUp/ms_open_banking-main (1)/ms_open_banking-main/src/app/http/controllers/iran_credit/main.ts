import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import ICSTokenModel, { IICSDoc } from "../../../models/ICSToken";
import User, { IUserDoc } from "../../../models/user";
import Transaction from "../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  startRequest: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { realPersonNationalCode, mobileNumber, legalPersonNationalCode } =
      req.body;
    try {
      const trackID = v4();
      const startRequest = await request.startRequest({
        realPersonNationalCode,
        mobileNumber,
        legalPersonNationalCode,
        multipart: true,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (process.env.NODE_ENV !== "test" && !req.isSandBox) {
        const ics = await ICSTokenModel.build({
          legalPersonNationalCode,
          realPersonNationalCode,
          token: startRequest.data,
        });
        await ics.save();
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;

        const endTime = performance.now();

        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...startRequest, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount || 0,
          req.serviceBuyAmount || 0,
          "iranCredit",
          "سرویس اول اعتبار سنجی افراد",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(startRequest) ? { startRequest } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount || 0,
        req.serviceBuyAmount || 0,
        "iranCredit",
        "سرویس اول اعتبار سنجی افراد",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  validate: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { code, token } = req.body;
    try {
      const trackID = v4();
      const validate = await request.validate({
        code,
        token,
        multipart: true,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (process.env.NODE_ENV !== "test" && !req.isSandBox) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;

        const endTime = performance.now();

        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...validate, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount || 0,
          req.serviceBuyAmount || 0,
          "iranCredit",
          "سرویس دوم اعتبار سنجی افراد",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(validate) ? { validate } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount || 0,
        req.serviceBuyAmount || 0,
        "iranCredit",
        "سرویس دوم اعتبار سنجی افراد",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  reportJSON: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { token } = req.query;
    try {
      const trackID = v4();
      const reportJSON =
        req.report ||
        (await request.reportJSON({
          token: token as string,
          multipart: true,
          trackID,
          isSandBox: req.isSandBox!,
        }));

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox &&
        !reportJSON.hasError
      ) {
        if (!req.report) {
          const user =
            (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
              User,
              req,
              mspack.nats_connection.default.client,
              "openBanking"
            )) as unknown as IUserDoc;
          const transaction = await Transaction.build({
            userId: user.id,
            amount: -req.serviceAmount!,
            paymentDesc: `کسر از اعتبار جهت استعلام اعتبار سنجی فرد`,
            paymentProvider: "none" as any,
            terminalNumber: "API usage",
            paymentToken: "API usage",
            paymentSessionID: "API usage",
            status: true,
            orderID: new Date().getTime(),
            traceCode: trackID,
            cardNumber: "API usage",
          });
          const endTime = performance.now();
          await transaction.save();
          await transaction.fireTransactionCompletedEvent();
          await user.fireIncameLogEvent(
            JSON.stringify(req.body),
            JSON.stringify({ ...reportJSON, trackID }),
            JSON.stringify(req.headers),
            200,
            "success",
            endTime - startTime,
            req.url.split("?")[0],
            req.serviceAmount!,
            req.serviceBuyAmount!,
            "iranCredit",
            "سرویس نهایی اعتبار سنجی افراد",
            req.appLogo,
            req.headers["appname"] as unknown as string
          );
          const ics = req.ics as IICSDoc;
          ics.result = reportJSON;
          await ics.save();
        }
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(reportJSON) ? { reportJSON } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url.split("?")[0],
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "iranCredit",
        "سرویس نهایی اعتبار سنجی افراد",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  reportLink: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { token } = req.query;
    try {
      const trackID = v4();
      const reportLink = await request.reportLink({
        token: token as string,
        multipart: true,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox &&
        reportLink.reportLink
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام اعتبار سنجی فرد به صورت لینک`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...reportLink, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url.split("?")[0],
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "iranCredit",
          "سرویس نهایی اعتبار سنجی افراد به صورت لینک",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(reportLink) ? { reportLink } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url.split("?")[0],
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "iranCredit",
        "سرویس نهایی اعتبار سنجی افراد به صورت لینک",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
