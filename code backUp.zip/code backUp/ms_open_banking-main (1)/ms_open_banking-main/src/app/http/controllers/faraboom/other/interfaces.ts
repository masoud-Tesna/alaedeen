export interface ITollDebts {
  license: string;
  token: string;
  trackID: string;
}

export interface ICardsHolder {
  pan: string;
  pin: string;
  trackID: string;
}

export interface IBalance {
  deposit_number?: string;
  pan: string;
  track2?: string;
  pin: string;
  pin_type: string;
  cvv2: string;
  exp_date: string;
  trackID: string;
  bankId: string;
}
