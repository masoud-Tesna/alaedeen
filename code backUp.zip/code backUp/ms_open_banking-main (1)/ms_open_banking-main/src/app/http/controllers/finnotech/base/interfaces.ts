export interface IBankInfo {
  trackID: string;
  isSandBox: boolean;
}
