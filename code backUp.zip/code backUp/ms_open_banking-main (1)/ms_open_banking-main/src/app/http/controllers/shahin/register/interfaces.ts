enum Reason {
  "POSA",
  "IOSP",
  "HIPA",
  "ISAP",
  "FXAP",
  "DRPA",
  "RTAP",
  "MPTP",
  "IMPT",
  "LMAP",
  "CDAP",
  "TCAP",
  "GEAC",
  "LRPA",
  "CCPA",
  "GPAC",
  "CPAC",
  "GPPC",
  "SPAC",
}

enum ChequeType {
  normal_cheque = 1,
  interbank_cheque = 2,
  password_protected_cheque = 3,
}
interface ISigner {
  name: string;
  shahabId: string;
  idCode: string;
  idType: string;
}

interface ISignGrantor {
  name: string;
  shahabId: string;
  idCode: string;
  idType: string;
}

interface ISigners {
  signer: ISigner;
  signGrantor: ISignGrantor;
  legalStamp: boolean;
}

interface IAccountOwners {
  name: string;
  shahabId: string;
  idCode: string;
  idType: string;
}

interface IReceivers {
  name: string;
  shahabId: string;
  idCode: string;
  idType: string;
}

export interface INationalIdentityInquiry {
  nationalCode: string;
  birthDate: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IIbanIdentityInquiry {
  iban: string;
  nationalCode: string;
  birthDate: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IPhoneValidityInquiry {
  mobileNumber: string;
  nationalCode: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IAccountInfoInquiry {
  sourceAccount: string;
  bank: string;
  nationalCode: string;
  trackID: string;
  isSandBox: boolean;
}

export interface ISayyadChequeInquiry {
  chequeSerial: string;
  nationalCode: string;
  trackID: string;
  isSandBox: boolean;
}

export interface ISayyadChequeRegister {
  chequeSerial: string;
  nationalCode: string;
  sourceAccount: string;
  amount: string;
  chequeMedia: string;
  currency: string;
  description: string;
  dueDate: string;
  sayadId: string;
  serialNo: string;
  seriesNo: string;
  accountOwners: IAccountOwners[];
  name: string;
  shahabId: string;
  idCode: string;
  idType: string;
  receivers: IReceivers[];
  signers: ISigners[];
  bank: string;
  branchCode: string;
  chequeType: ChequeType;
  reason: Reason;
  toIban: string;
  trackID: string;
  isSandBox: boolean;
}
