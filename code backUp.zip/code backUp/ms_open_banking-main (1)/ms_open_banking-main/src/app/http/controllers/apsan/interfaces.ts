export interface IGetPayToken {
  amount: string;
  redirectUri: string;
  terminalID: string;
  trackID: string;
  isSandBox: boolean;
}
