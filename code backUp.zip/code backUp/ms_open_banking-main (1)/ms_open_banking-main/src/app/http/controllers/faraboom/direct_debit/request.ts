import mspack from "mspack";
import axios from "axios";
import qs from "qs";
import * as interfaces from "./interfaces";

class Fetch {
  private _clientID: string = process.env.FARABOOM_CLIENT_ID!;
  private _clientSecret: string = process.env.FARABOOM_CLIENT_SECRET!;
  private _appKey: string = process.env.FARABOOM_APP_KEY!;

  private _token: any;

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._appKey || !this._clientSecret) {
        throw new mspack.custom_error(
          "FARABOOM_CLIENT_ID or FARABOOM_CLIENT_SECRET or FARABOOM_APP_KEY not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: "https://payman2.sandbox.faraboom.co/oauth/token",
        method: "post",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        data: qs.stringify({
          client_id: this._clientID,
          client_secret: this._clientSecret,
          grant_type: "client_credentials",
        }),
      });
      this._token = data.access_token;
      return data;
    } catch (error) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async permissions(): Promise<string | undefined> {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: "https://payman2.sandbox.faraboom.co/v1/payman/creditor/permissions",
        method: "get",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.permissions();
        } catch (error_2) {
          throw new mspack.custom_error(
            error.response.data ? error.response.data.error : error.message,
            error.response.status || 400
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.error : error.message,
          error.response.status || 400
        );
      }
    }
  }

  public async create_covenant(
    params: interfaces.IDirectDebitCreate
  ): Promise<string | undefined> {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { headers } = await axios({
        url: "https://payman2.sandbox.faraboom.co/v1/payman/create",
        method: "post",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "mobile-no": params.mobile,
          "national-code": params.nationalID,
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
        data: params,
        maxRedirects: 0,
        validateStatus: function (status: number): boolean {
          if (status >= 200 && status < 400) return true;
          return false;
        },
      });

      return headers.location;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.create_covenant(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async getPeymanID(
    params: interfaces.IGetPeymanID
  ): Promise<{ payman_id: string; status: string } | undefined> {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `https://payman2.sandbox.faraboom.co/v1/payman/getId?payman_code=${params.payman_code}`,
        method: "get",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "mobile-no": "",
          "national-code": "",
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
      });

      return data;
    } catch (error) {
      console.log(error.response.data);
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.getPeymanID(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trace_id
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trace_id
        );
      }
    }
  }

  public async getTracePeymanID(
    params: interfaces.ITracePeymanID
  ): Promise<string | undefined> {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `https://payman2.sandbox.faraboom.co/v1/payman/create/trace?trace-id=${params.trace_id}`,
        method: "get",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "mobile-no": "",
          "national-code": "",
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.getTracePeymanID(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trace_id
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trace_id
        );
      }
    }
  }

  public async startPay(params: interfaces.IStartPay): Promise<
    | {
        reference_id: string;
        trace_id: string;
        transaction_amount: number;
        transaction_time: number;
        batch_id: number;
        commission_amount: number;
        status: string;
      }
    | undefined
  > {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `https://payman2.sandbox.faraboom.co/v1/payman/pay`,
        method: "post",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "mobile-no": "",
          "national-code": "",
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
        data: params,
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.getTracePeymanID(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async startBillPay(params: interfaces.IStartPayBill): Promise<
    | {
        bill_id: string;
        pay_id: string;
        trace_id: string;
        amount: number;
        currency: string;
        referral_number: number;
        date: number;
        bill_title: string;
        bill_type: string;
        payman_url: string;
        payment_system: string;
        payment_tool: string;
      }
    | undefined
  > {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `https://payman.sandbox.faraboom.co/v1/payman/pay/bill`,
        method: "post",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "mobile-no": "",
          "national-code": "",
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
        data: params,
      });

      return data;
    } catch (error) {
      throw new mspack.custom_error_with_detail(
        error.response.data,
        error.response.status || 400,
        [],
        params.trackID
      );
      // if (error.response.data.code === "2069") {
      //   this._token = undefined;
      //   try {
      //     await this.getTracePeymanID(params);
      //   } catch (error_2) {
      //     const detail: { message: any; param: string }[] = [];
      //     error.response.data.errors.map((i: any) => {
      //       detail.push({ message: i.error || i.message, param: "" });
      //     });
      //     throw new mspack.custom_error_with_detail(
      //       error.response.data.error
      //         ? error.response.data.error
      //         : error.response.data.message
      //         ? error.response.data.message
      //         : error.message,
      //       error.response.status || 400,
      //       detail,
      //       params.trackID
      //     );
      //   }
      // } else {
      //   const detail: { message: any; param: string }[] = [];
      //   error.response.data.errors.map((i: any) => {
      //     detail.push({ message: i.error || i.message, param: "" });
      //   });
      //   throw new mspack.custom_error_with_detail(
      //     error.response.data.error
      //       ? error.response.data.error
      //       : error.response.data.message
      //       ? error.response.data.message
      //       : error.message,
      //     error.response.status || 400,
      //     detail,
      //     params.trackID
      //   );
      // }
    }
  }

  public async tavanamFactor(
    params: interfaces.IDirectDebitCreate
  ): Promise<string | undefined> {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: "https://api.sandbox.faraboom.co/v1/tavanam/reports/advanced",
        method: "post",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "mobile-no": params.mobile,
          "national-code": params.nationalID,
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
        data: params,
        maxRedirects: 0,
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.create_covenant(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trace_id
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trace_id
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
