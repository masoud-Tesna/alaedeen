export interface IBillInquiry {
  plateNumber: string;
  plateChar: string;
  trackID: string;
  isSandBox: boolean;
}
