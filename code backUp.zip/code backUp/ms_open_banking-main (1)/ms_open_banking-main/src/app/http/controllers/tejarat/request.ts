import mspack from "mspack";
import axios from "axios";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/iran_credit/response_example";

class Fetch {
  private _clientID: string = process.env.TEJARAT_CLIENT_ID!;
  private _clientSecret: string = process.env.TEJARAT_CLIENT_SECRET!;
  private _clientCookie: string = process.env.TEJARAT_CLIENT_COOKIE!;
  private _token: any;
  private _baseURL: string = "https://openbanking.tejaratbank.ir";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret || !this._clientCookie) {
        throw new mspack.custom_error(
          "TEJARAT_CLIENT_ID or TEJARAT_CLIENT_SECRET or TEJARAT_CLIENT_COOKIE not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/auth/token`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
          Cookie: `cookiesession1=${this._clientCookie}`,
        },
        data: {
          client_id: this._clientID,
          client_secret: this._clientSecret,
          grant_type: "client_credentials",
          scope: "",
        },
      });

      this._token = data.result.access_token;
      return data;
    } catch (error) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async cardInquiry(params: interfaces.ICardInquiry): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/cards/${params.card}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.cardInquiry(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }

  public async panIdentifierInquiry(
    params: interfaces.IPanIdentifierInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/matches/pan-identifier`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.panIdentifierInquiry(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }

  public async panMobileIdentifier(
    params: interfaces.IPanMobileIdentifier
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/matches/pan-mobile-identifier`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.panIdentifierInquiry(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }

  public async accountMobileIdentifier(
    params: interfaces.IAccountMobileIdentifier
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/matches/account-mobile-identifier`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.accountMobileIdentifier(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }

  public async shahkarInquiry(
    params: interfaces.IShahkarInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/matches/mobile-identifier`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.shahkarInquiry(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }
  public async accountIdentifier(
    params: interfaces.IAccountIdentifier
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/matches/account-identifier`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.accountIdentifier(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }

  public async cardToIban(params: interfaces.cardToIban): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/api/v1/utility/inquiry/cards/${params.cardNumber}/iban`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.cardToIban(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.response.data
              ? error_2.response.data.title
              : error_2.message,
            error_2.response.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.title : error.message,
          error.response.status || 400,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
