export interface INationalIdentityInquiry {
  nationalCode: string;
  birthDate: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IIbanIdentityInquiry {
  iban: string;
  nationalCode: string;
  birthDate: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IPhoneValidityInquiry {
  mobileNumber: string;
  nationalCode: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IAccountInfoInquiry {
  sourceAccount: string;
  bank: string;
  nationalCode: string;
  trackID: string;
  isSandBox: boolean;
}

export interface ISayyadChequeInquiry {
  chequeSerial: string;
  nationalCode: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IIbanInquiry {
  nationalCode: string;
  bank: string;
  iban: string;
  trackID: string;
  isSandBox: boolean;
}

export interface ICardInquiry {
  nationalCode: string;
  bank: string;
  cardNumber: string;
  sourceAccount: string;
  trackID: string;
  isSandBox: boolean;
}
