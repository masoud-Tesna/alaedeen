export interface IInquiryShahkar {
  nationalCode: string;
  mobileNumber: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IInquiryCardNumberIdentity {
  nationalCode: string;
  cardNumber: string;
  birthDate: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IInquiryCard {
  cardNumber: string;

  trackID: string;
  isSandBox: boolean;
}

export interface ICardToIbanConvert {
  cardNumber: string;

  trackID: string;
  isSandBox: boolean;
}

export interface ICardToDeposit {
  cardNumber: string;

  trackID: string;
  isSandBox: boolean;
}

export interface IInquiryCardNumberWithName {
  cardNumber: string;
  name: string;
  trackID: string;
  isSandBox: boolean;
}
