// import { Request, Response, NextFunction } from "express";
// import request from "./request";
// import mspack from "mspack";
// import _ from "lodash";
// import User, { IUserDoc } from "../../../models/user";
// import { v4 } from "uuid";
// import { performance } from "perf_hooks";

// export default {
//   addressByPostcode: async (
//     req: Request,
//     res: Response,
//     next: NextFunction
//   ) => {
//     const startTime = performance.now();
//     const { postCode } = req.body;
//     try {
//       const trackID = v4();
//       const addressByPostcode = await request.addressByPostcode({
//         postCode,
//         trackID,
//         isSandBox: req.isSandBox!,
//       });

//       // const findedUser = req.user as IUserDoc;

//       if (
//         process.env.NODE_ENV !== "test" &&
//         addressByPostcode?.ResCode === 0 &&
//         !req.isSandBox
//       ) {
//         const user =
//           (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
//             User,
//             req,
//             mspack.nats_connection.default.client
//           )) as unknown as IUserDoc;
//         const updateTransaction = await user!.completeTranscation({
//           amount: -req.serviceAmount!,
//           paymentDesc: `decharge for ${req.url}`,
//           paymentProvider: "none" as any,
//           terminalNumber: "API usage",
//           paymentToken: "API usage",
//           paymentSessionID: "API usage",
//           status: true,
//           orderID: new Date().getTime(),
//           traceCode: trackID,
//           cardNumber: "API usage",
//         });
//         const endTime = performance.now();
//         await updateTransaction.save();
//         await updateTransaction.fireTransactionCompletedEvent();
//         await updateTransaction.fireIncameLogEvent(
//           JSON.stringify(req.body),
//           JSON.stringify({ ...addressByPostcode, trackID }),
//           JSON.stringify(req.headers),
//           200,
//           "success",
//           endTime - startTime,
//           req.url,
//           req.serviceAmount!,
//           req.serviceBuyAmount!,
//           "apsan",
//           req.appLogo,
//           req.headers["appname"] as unknown as string
//         );
//       }

//       mspack.response_normlizer_sender(
//         true,
//         res,
//         _.isObject(addressByPostcode) ? { addressByPostcode } : {},
//         200,
//         trackID
//       );
//     } catch (error) {
//       const endTime = performance.now();
//       await User.fireIncameLogEventStatic(
//         req.APIkeyPayload!.userId,
//         JSON.stringify(req.body),
//         JSON.stringify({ ...error, message: error.message }),
//         JSON.stringify(req.headers),
//         error.status,
//         "error",
//         endTime - startTime,
//         req.url,
//         req.serviceAmount!,
//         req.serviceBuyAmount!,
//         "apsan",
//         req.appLogo,
//         req.headers["appname"] as unknown as string
//       );
//       next(error);
//     }
//   },
// };
