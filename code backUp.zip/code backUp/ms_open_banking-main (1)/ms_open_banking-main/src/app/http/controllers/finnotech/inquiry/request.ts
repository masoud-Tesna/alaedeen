import mspack from "mspack";
import axios from "axios";
import scopes from "../scopes";
import * as interfaces from "./interfaces";
import response_example from "../../../../../misc/finnotech/inquiry/response_example";

class Fetch {
  private _clientID: string = process.env.FINNOTECH_CLIENT_ID!;
  private _clientSecret: string = process.env.FINNOTECH_PASSWORD!;
  private _clientNID: string = process.env.FINNOTECH_NID!;
  private _token: any;
  private _refreshToken: any;

  private _baseURL: string = "https://apibeta.finnotech.ir";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret || !this._clientNID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID or FINNOTECH_PASSWORD or FINNOTECH_NID not set in env variables!",
          400
        );
      }
      const Token = Buffer.from(
        `${this._clientID}:${this._clientSecret}`
      ).toString("base64");
      const { data } = await axios({
        url: `${this._baseURL}/dev/v2/oauth2/token`,
        method: "post",
        headers: {
          authorization: `Basic ${Token}`,
          "Content-Type": "application/json",
        },
        data: {
          grant_type: "client_credentials",
          nid: this._clientNID,
          scopes,
        },
      });

      this._token = data.result.value;
      this._refreshToken = data.result.refreshToken;

      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async ibanInquiry(params: interfaces.IIbanInquiry): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/oak/v2/clients/${this._clientID}/ibanInquiry?trackId=${params.trackID}&iban=${params.iban}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.ibanInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async shahkarInquiry(
    params: interfaces.IShahkarInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.shahkarInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/mpg/v2/clients/${this._clientID}/shahkar/verify?trackId=${params.trackID}&mobile=${params.mobile}&nationalCode=${params.nationalID}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.shahkarInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async facilityInquiry(
    params: interfaces.IFacilityInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.facilityInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/credit/v2/clients/${this._clientID}/users/${params.nationalID}/facilityInquiry?trackId=${params.trackID}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.facilityInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async backChequesInquiry(
    params: interfaces.IBackChequesInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.backChequesInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/credit/v2/clients/${this._clientID}/users/${params.nationalID}/backCheques?trackId=${params.trackID}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.backChequesInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
  public async drivingOffenseInquiry(
    params: interfaces.IDrivingOffenseInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.drivingOffenseInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/billing/v2/clients/${this._clientID}/drivingOffense?trackId=${params.trackID}&parameter=${params.serial}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.drivingOffenseInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async billingInquiry(
    params: interfaces.IBillingInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.billingInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/billing/v2/clients/${this._clientID}/billingInquiry?trackId=${params.trackID}&parameter=${params.billID}&type=${params.type}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.billingInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async inquiryCard(params: interfaces.IInquiryCard): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.billingInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/mpg/v2/clients/${this._clientID}/cards?trackId=${params.trackID}&mobile=${params.mobile}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.inquiryCard(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
