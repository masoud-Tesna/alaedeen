import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../../models/user";
import * as interfaces from "./interface";
import { v4 } from "uuid";
import events from "../../../../../util/events";
export default {
  cardHolderInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const {
      sourcePAN,
      destinationPAN,
      amount,
      referenceNumber,
      sourceAddress,
      localization,
      acceptorCode,
      terminalNumber,
      terminalType,
    } = req.body;
    try {
      const trackID = v4();
      const cardHolderInquiry = await request.cardHolderInquiry({
        sourcePAN,
        destinationPAN,
        amount,
        referenceNumber,
        sourceAddress,
        localization,
        acceptorCode,
        terminalNumber,
        terminalType,
        trackID,
        isSandBox: req.isSandBox!,
      });
      await mspack.increase_APIkey_usage_count.default<IUserDoc>(
        User,
        req,
        mspack.nats_connection.default.client,
        "openBanking"
      );

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(cardHolderInquiry) ? cardHolderInquiry : {},
        200
      );
    } catch (error) {
      next(error);
    }
  },
};
