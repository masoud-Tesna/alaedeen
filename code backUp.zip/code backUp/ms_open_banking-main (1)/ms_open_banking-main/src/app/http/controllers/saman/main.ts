import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../models/user";
import Transaction from "../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  payaPayment: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();

    const { price, description, ibanNumber } = req.body;
    try {
      const trackID = v4();

      const payaPayment = await request.payaPayment({
        amount: price,
        description: description || "paya payment request",
        factorNumber: new Date().getTime(),
        ownerName: "test",
        ibanNumber,
        transferDescription: description || "paya payment request",
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (process.env.NODE_ENV !== "test" && !req.isSandBox && payaPayment) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت درخواست انتقال وجه پایا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...payaPayment, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "saman",
          "درخواست انتقال وجه پایا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(payaPayment) ? { payaPayment } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "saman",
        "درخواست انتقال وجه پایا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  satnaPayment: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();

    const {
      receiverName,
      receiverFamily,
      receiverTelephoneNumber,
      ibanNumber,
      price,
      description,
    } = req.body;
    try {
      const trackID = v4();

      const satnaPayment = await request.satnaPayment({
        amount: price,
        description: description || "satna payment request",
        receiverName,
        receiverFamily,
        destinationIbanNumber: ibanNumber,
        factorNumber: new Date().getTime(),
        receiverTelephoneNumber,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (process.env.NODE_ENV !== "test" && !req.isSandBox && satnaPayment) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت درخواست انتقال وجه ساتنا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...satnaPayment, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "saman",
          "درخواست انتقال وجه ساتنا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(satnaPayment) ? { satnaPayment } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "saman",
        "درخواست انتقال وجه ساتنا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  normalPayment: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();

    const {
      additionalDocumentDesc,
      sourceComment,
      destinationDeposit,
      price,
      destinationComment,
    } = req.body;
    try {
      const trackID = v4();

      const normalPayment = await request.normalPayment({
        additionalDocumentDesc: additionalDocumentDesc || "",
        sourceComment: sourceComment || "",
        destinationDeposit,
        amount: price,
        destinationComment: destinationComment || "normal payment request",
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (process.env.NODE_ENV !== "test" && !req.isSandBox && normalPayment) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت درخواست انتقال وجه درون بانکی سامان`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...normalPayment, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "saman",
          "درخواست انتقال وجه درون بانکی سامان",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(normalPayment) ? { normalPayment } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "saman",
        "درخواست انتقال وجه درون بانکی سامان",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  payaPaymentReport: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();

    const { offset, length } = req.query;
    try {
      const trackID = v4();

      const payaPaymentReport = await request.payaPaymentReport({
        offset: offset as any,
        length: length as any,
        trackID,
        isSandBox: req.isSandBox!,
      });

      const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox &&
        payaPaymentReport
      ) {
        // const user =
        //   (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
        //     User,
        //     req,
        //     mspack.nats_connection.default.client,
        //     "openBanking"
        //   )) as unknown as IUserDoc;
        // const transaction = await Transaction.build({
        //   userId: user.id,
        //   amount: -req.serviceAmount!,
        //   paymentDesc: `کسر از اعتبار جهت درخواست انتقال وجه پایا`,
        //   paymentProvider: "none" as any,
        //   terminalNumber: "API usage",
        //   paymentToken: "API usage",
        //   paymentSessionID: "API usage",
        //   status: true,
        //   orderID: new Date().getTime(),
        //   traceCode: trackID,
        //   cardNumber: "API usage",
        // });
        const endTime = performance.now();
        // await transaction.save();
        // await transaction.fireTransactionCompletedEvent();
        await findedUser.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...payaPaymentReport, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "saman",
          "پیگیری درخواست های پرداخت پایا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(payaPaymentReport) ? { payaPaymentReport } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "saman",
        "پیگیری درخواست های پرداخت پایا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  satnaPaymentReport: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();

    const { fromDate, toDate, englishDescription, description, order } =
      req.query;
    try {
      const trackID = v4();

      const satnaPaymentReport = await request.satnaPaymentReport({
        fromDate: new Date(fromDate as string),
        toDate: new Date(toDate as string),
        englishDescription: englishDescription
          ? (englishDescription as string)
          : undefined,
        description: description ? (description as string) : undefined,
        order: order ? (order as any) : undefined,
        trackID,
        isSandBox: req.isSandBox!,
      });

      const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox &&
        satnaPaymentReport
      ) {
        // const user =
        //   (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
        //     User,
        //     req,
        //     mspack.nats_connection.default.client,
        //     "openBanking"
        //   )) as unknown as IUserDoc;
        // const transaction = await Transaction.build({
        //   userId: user.id,
        //   amount: -req.serviceAmount!,
        //   paymentDesc: `کسر از اعتبار جهت درخواست انتقال وجه پایا`,
        //   paymentProvider: "none" as any,
        //   terminalNumber: "API usage",
        //   paymentToken: "API usage",
        //   paymentSessionID: "API usage",
        //   status: true,
        //   orderID: new Date().getTime(),
        //   traceCode: trackID,
        //   cardNumber: "API usage",
        // });
        const endTime = performance.now();
        // await transaction.save();
        // await transaction.fireTransactionCompletedEvent();
        await findedUser.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...satnaPaymentReport, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "saman",
          "پیگیری درخواست های پرداخت ساتنا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(satnaPaymentReport) ? { satnaPaymentReport } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "saman",
        "پیگیری درخواست های پرداخت ساتنا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
