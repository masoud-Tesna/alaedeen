import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../models/user";
import Transaction from "../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  cardInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const { cardNumber } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const cardInquiry = await request.cardInquiry({
        card: cardNumber,
        isSandBox: req.isSandBox!,
        trackID,
      });

      if (process.env.NODE_ENV !== "test" && cardInquiry && !req.isSandBox) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: "کسر از اعتبار جهت استعلام شماره کارت سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();

        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...cardInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          "استعلام شماره کارت سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(cardInquiry) ? cardInquiry : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "استعلام شماره کارت سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  panIdentifierInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const { cardNumber, mobile, nationalID } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const panIdentifierInquiry = await request.panIdentifierInquiry({
        cardNumber,
        mobileNumber: mobile,
        identifier: nationalID,
        isSandBox: req.isSandBox!,
        trackID,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        panIdentifierInquiry &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc:
            "کسر از اعتبار جهت استعلام تطبیق شمارت کارت و کد ملی سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...panIdentifierInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          "استعلام تطبیق شماره کارت و کد ملی سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(panIdentifierInquiry) ? panIdentifierInquiry : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "استعلام تطبیق شماره کارت و کد ملی سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  panMobileIdentifier: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const { cardNumber, mobile, nationalID } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const panMobileIdentifier = await request.panMobileIdentifier({
        cardNumber,
        mobileNumber: mobile,
        identifier: nationalID,
        isSandBox: req.isSandBox!,
        trackID,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        panMobileIdentifier &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc:
            "کسر از اعتبار جهت استعلام تطبیق شمارت کارت و کد ملی و تلفن همراه سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...panMobileIdentifier, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          "استعلام تطبیق شماره کارت و کد ملی و تلفن همراه سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(panMobileIdentifier) ? panMobileIdentifier : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "استعلام تطبیق شماره کارت و کد ملی و تلفن همراه سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  accountMobileIdentifier: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const { sourceAccount, mobile, nationalID } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const accountMobileIdentifier = await request.accountMobileIdentifier({
        accountNumber: sourceAccount,
        mobileNumber: mobile,
        identifier: nationalID,
        isSandBox: req.isSandBox!,
        trackID,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        accountMobileIdentifier &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc:
            "کسر از اعتبار جهت استعلام تطبیق شمارت حساب و کد ملی و تلفن همراه سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...accountMobileIdentifier, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          "استعلام تطبیق شماره حساب و کد ملی و تلفن همراه سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(accountMobileIdentifier) ? accountMobileIdentifier : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "استعلام تطبیق شماره حساب و کد ملی و تلفن همراه سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  shahkarInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const { mobile, nationalID } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const shahkarInquiry = await request.shahkarInquiry({
        mobileNumber: mobile,
        identifier: nationalID,
        isSandBox: req.isSandBox!,
        trackID,
      });

      if (process.env.NODE_ENV !== "test" && shahkarInquiry && !req.isSandBox) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: "کسر از اعتبار جهت استعلام شاهکار سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...shahkarInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          " استعلام شاهکار سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(shahkarInquiry) ? shahkarInquiry : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "استعلام شاهکار سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  accountIdentifier: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const { sourceAccount, nationalID } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const accountIdentifier = await request.accountIdentifier({
        accountNumber: sourceAccount,
        identifier: nationalID,
        isSandBox: req.isSandBox!,
        trackID,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        accountIdentifier &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc:
            "کسر از اعتبار جهت استعلام تطابق شماره حساب و کد ملی سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...accountIdentifier, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          "استعلام تطابق شماره حساب و کد ملی سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(accountIdentifier) ? accountIdentifier : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "استعلام تطابق شماره حساب و کد ملی سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  cardToIban: async (req: Request, res: Response, next: NextFunction) => {
    const { cardNumber } = req.body;

    const startTime = performance.now();
    const trackID = v4();
    try {
      const cardToIban = await request.cardToIban({
        cardNumber,

        isSandBox: req.isSandBox!,
        trackID,
      });

      if (process.env.NODE_ENV !== "test" && cardToIban && !req.isSandBox) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: "کسر از اعتبار جهت تبدیل شماره کارت به شبا سیمرغ",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...cardToIban, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "tejarat",
          "تبدیل شماره کارت به شبا سیمرغ",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(cardToIban) ? cardToIban : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "tejarat",
        "تبدیل شماره کارت به شبا سیمرغ",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
