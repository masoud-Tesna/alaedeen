import https from "https";
import fs from "fs";
import { join } from "path";
import crypto from "crypto";

enum Method {
  "POST",
  "GET",
  "PUT",
  "DELETE",
  "PATCH",
}

const agent_certificate = new https.Agent({
  rejectUnauthorized: false,
  passphrase: "Ma@36002425#",
  ca: fs.readFileSync(join(__dirname, "./cert/orgCertBundle.pfx")),
  key: fs.readFileSync(join(__dirname, "./cert/keyPrivate.key")),
  cert: fs.readFileSync(join(__dirname, "./cert/orgCertificate.der")),
});

const agent_ignoreSSL = new https.Agent({
  rejectUnauthorized: false,
});

const getXObhsignature = (
  body: any,
  url: string,
  trackId: string,
  timeStamp: number,
  method: Method
) => {
  let payloadStr = "";
  for (let i of Object.keys(body)) {
    if (i == "cardInfo") {
      let cardInfoStr = "";
      for (let m of Object.keys(body[i])) {
        cardInfoStr += `${m}=${body[i][m]},`;
      }
      payloadStr += `${i}={${cardInfoStr.substr(0, cardInfoStr.length - 1)}},`;
    } else {
      payloadStr += `${i}=${body[i]},`;
    }
  }

  payloadStr = `{${payloadStr.substr(0, payloadStr.length - 1)}}`;
  const payloadHash = crypto
    .createHash("sha256")
    .update(payloadStr)
    .digest("hex")
    .toUpperCase();
  const XObhsignature_1 = crypto
    .createHash("sha256")
    .update(
      `${method}\n${url}\nx-obh-timestamp:${timeStamp}\nx-obh-uuid:${trackId}\n\nx-obh-timestamp;x-obh-uuid\n${payloadHash}`
    )
    .digest("hex")
    .toUpperCase();
  const sigkey = crypto
    .createHash("sha256")
    .update(`${new Date().getFullYear()}StK0TYgH5CtQ0A8jvio6`)
    .digest();
  const XObhsignature_2 = crypto
    .createHmac("sha256", sigkey)
    .update(XObhsignature_1)
    .digest("hex")
    .toUpperCase();
  const finalString = `OBH1-HMAC-SHA256;SignedHeaders=X-Obh-uuid,X-Obh-timestamp;Signature=${XObhsignature_2}`;

  return finalString;
};

export { agent_certificate, agent_ignoreSSL, getXObhsignature };
