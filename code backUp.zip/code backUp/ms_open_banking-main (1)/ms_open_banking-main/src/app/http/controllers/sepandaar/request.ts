import mspack from "mspack";
import axios from "axios";
import plateConverter from "../../../../util/plateConverter";
import https from "https";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/sepandaar/response_example";

class Fetch {
  private _clientID: string = process.env.SEPANDAAR_TOKEN_CLIENT_ID!;
  private _clientSecret: string = process.env.SEPANDAAR_TOKEN_PASSWORD!;
  private _token: string = process.env.SEPANDAAR_TOKEN!;
  private _cookie: any;
  private _baseURL: string = "https://finance.sepandaar.com";
  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._token || this._clientID || this._clientSecret) {
        throw new mspack.custom_error(
          "SEPANDAAR_TOKEN or SEPANDAAR_TOKEN_PASSWORD or SEPANDAAR_TOKEN_CLIENT_ID not set in env variables!",
          400
        );
      }

      const { headers } = await axios({
        url: `${this._baseURL}/api/auth/login`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          Username: this._clientID,
          Password: this._clientSecret,
        },
      });

      this._cookie = headers["set-cookie"][0].split("=")[1].split(";")[0];

      return headers["set-cookie"][0].split("=")[1].split(";")[0];
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async billInquiry(params: interfaces.IBillInquiry): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.billInquiry;
      }

      const plateConvetredCharCode = plateConverter(params.plateChar);
      const { data } = await axios({
        url: `${this._baseURL}/api/bill?plateNumber=${params.plateNumber.substr(
          0,
          2
        )}${plateConvetredCharCode}${params.plateNumber.substr(2)}`,
        method: "post",
        headers: { Authorization: `Basic ${this._token}` },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
      });

      return data;
    } catch (error: any) {
      if (error.response && error.response.status === 401) {
      } else {
        throw new mspack.custom_error(
          error.message,
          error.response?.status || 400,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
