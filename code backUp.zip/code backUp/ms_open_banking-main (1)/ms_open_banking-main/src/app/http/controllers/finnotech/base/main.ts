import { Request, Response, NextFunction } from "express";
import mspack from "mspack";
import _ from "lodash";
import User from "../../../../models/user";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  bankInfo: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();

    try {
      const trackID = v4();
      // const bankInfo = await request.bankInfo({
      //   trackID,
      //   isSandBox: req.isSandBox!,
      // });

      const banks = [
        { index: "01", code: "BMI", name: "بانک ملی" },
        { index: "02", code: "PAS", name: "بانک پاسارگاد" },
        { index: "03", code: "BSP", name: "بانک سپه" },
        { index: "04", code: "BSI", name: "بانک صادرات" },
        { index: "05", code: "MEL", name: "بانک ملت" },
        { index: "06", code: "SAM", name: "بانک سامان" },
        { index: "07", code: "BKV", name: "بانک کشاورزی" },
        { index: "08", code: "TEJ", name: "بانک تجارت" },
        { index: "09", code: "SAD", name: "بانک صادرات" },
        { index: "10", code: "ENB", name: "بانک اقتصاد نوین" },
        { index: "11", code: "REF", name: "بانک رفاه" },
        { index: "12", code: "BMK", name: "بانک مسکن" },
        { index: "13", code: "AYN", name: "بانک آینده" },
        { index: "14", code: "DEY", name: "بانک دی" },
        { index: "15", code: "SIN", name: "بانک سینا" },
        { index: "16", code: "PAR", name: "بانک پارسیان" },
        { index: "17", code: "BKA", name: "بانک کارآفرین" },
        { index: "18", code: "RES", name: "بانک رسالت" },
        { index: "19", code: "ANS", name: "بانک انصار" },
        { index: "20", code: "IRZ", name: "بانک ایران زمین" },
        { index: "21", code: "BSM", name: "بانک صنعت و معدن" },
        { index: "22", code: "SAR", name: "بانک سرمایه" },
        { index: "23", code: "BTS", name: "بانک توسعه صادرات" },
        { index: "24", code: "SHR", name: "بانک شهر" },
        { index: "25", code: "HEK", name: "بانک حکمت ایرانیان" },
        { index: "26", code: "KHMI", name: "بانک خاورمیانه" },
        { index: "27", code: "BTT", name: "بانک توسعه تعاون" },
        { index: "28", code: "PST", name: "بانک پست ایران" },
        { index: "29", code: "MEH", name: "بانک مهر" },
        { index: "30", code: "KSAC", name: "بانک کوثر" },
        { index: "31", code: "GHA", name: "بانک قوامین" },
        { index: "32", code: "NOR", name: "بانک نور" },
      ];

      // const findedUser = req.user as IUserDoc;

      mspack.response_normlizer_sender(true, res, { banks }, 200, trackID);
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount || 0,
        req.serviceBuyAmount || 0,
        "finnotech",
        "لیست بانک ها",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
