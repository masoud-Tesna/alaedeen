export interface ICardToIban {
  card: string;
  trackID: string;
  isSandBox: boolean;
}

export interface ICardToDeposit {
  card: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IDepositOwnerVerification {
  nationalCode: string;
  bank: string;
  deposit: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IDepositToIban {
  bank: string;
  deposit: string;
  trackID: string;
  isSandBox: boolean;
}
