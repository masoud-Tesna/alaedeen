import mspack from "mspack";
import axios from "axios";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/jibit/response_example";
import replacementServce from "../finnotech/inquiry/request";
import replacementServceConvert from "../finnotech/convert/request";

class Fetch {
  private _clientID: string = process.env.JIBIT_APIKEY!;
  private _clientSecret: string = process.env.JIBIT_SECRETKEY!;
  private _token: any;
  private _refreshToken: any;
  private _baseURL: string = "https://napi.jibit.ir";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "JIBIT_APIKEY or JIBIT_SECRETKEY not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: this._baseURL + `/ide/v1/tokens/generate`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          apiKey: this._clientID,
          secretKey: this._clientSecret,
        },
      });

      this._token = data.accessToken;

      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async inquiryShahkar(
    params: interfaces.IInquiryShahkar
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.shahkarInquiry;
      }
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/ide/v1/services/matching?nationalCode=${params.nationalCode}&mobileNumber=${params.mobileNumber}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IInquiryShahkar>(this.inquiryShahkar, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });

        if (interceptor) return interceptor;
        else throw error;
      } catch (error_2: any) {
        const multi_providers_service = await mspack.multi_providers_service(
          {
            mobile: params.mobileNumber,
            nationalID: params.nationalCode,
            isSandBox: params.isSandBox,
            trackID: params.trackID,
          },
          replacementServce,
          "shahkarInquiry",
          "finnotech",
          error_2.response ? error_2.response.status : error_2.status
        );

        if (multi_providers_service.replacement) {
          return multi_providers_service.response;
        } else
          throw new mspack.custom_error(
            error_2.response.data,
            error_2.response.status || 400
          );
      }
    }
  }

  public async inquiryCardNumberIdentity(
    params: interfaces.IInquiryCardNumberIdentity
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.inquiryCardNumberIdentity;
      }
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/ide/v1/services/matching?cardNumber=${params.cardNumber}&nationalCode=${params.nationalCode}&birthDate=${params.birthDate}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IInquiryCardNumberIdentity>(
          this.inquiryCardNumberIdentity,
          params,
          error,
          {
            sensitiveStausCode: [403],
            renewTokenFunc: this._getToken,
          }
        );

        if (interceptor) return interceptor;

        throw new mspack.custom_error(
          error.response.data,
          error.response.status || 400
        );
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error_2.response?.data || error_2.message,
          error_2.response?.status || 400
        );
      }
    }
  }

  public async inquiryCard(params: interfaces.IInquiryCard): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.inquiryCard;
      }
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/ide/v1/cards?number=${params.cardNumber}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IInquiryCard>(this.inquiryCard, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });

        if (interceptor) return interceptor;

        throw new mspack.custom_error(
          error.response.data,
          error.response.status || 400
        );
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error_2.response?.data || error_2.message,
          error_2.response?.status || 400
        );
      }
    }
  }

  public async cardToIban(params: interfaces.ICardToIbanConvert): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.cardToIban;
      }
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/ide/v1/cards?number=${params.cardNumber}&iban=true`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.ICardToIbanConvert>(this.cardToIban, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });

        if (interceptor) return interceptor;
        else throw error;
      } catch (error_2: any) {
        const multi_providers_service = await mspack.multi_providers_service(
          {
            card: params.cardNumber,
            isSandBox: params.isSandBox,
            trackID: params.trackID,
          },
          replacementServceConvert,
          "cardToIban",
          "finnotech",
          error_2.response ? error_2.response.status : error_2.status
        );

        if (multi_providers_service.replacement) {
          return multi_providers_service.response;
        } else
          throw new mspack.custom_error(
            error_2.response.data,
            error_2.response.status || 400
          );
      }
    }
  }

  public async cardToDeposit(params: interfaces.ICardToDeposit): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.cardToDeposit;
      }
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/ide/v1/cards?number=${params.cardNumber}&deposit=true`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.ICardToDeposit>(this.cardToDeposit, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });

        if (interceptor) return interceptor;
        else throw error;
      } catch (error_2: any) {
        const multi_providers_service = await mspack.multi_providers_service(
          {
            card: params.cardNumber,
            isSandBox: params.isSandBox,
            trackID: params.trackID,
          },
          replacementServceConvert,
          "cardToDeposit",
          "finnotech",
          error_2.response ? error_2.response.status : error_2.status
        );

        if (multi_providers_service.replacement) {
          return multi_providers_service.response;
        } else
          throw new mspack.custom_error(
            error_2.response.data,
            error_2.response.status || 400
          );
      }
    }
  }

  public async inquiryCardNumberWithName(
    params: interfaces.IInquiryCardNumberWithName
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.inquiryCard;
      }
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: encodeURI(
          `${this._baseURL}/ide/v1/services/matching?cardNumber=${params.cardNumber}&name=${params.name}`
        ),
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
      });

      return data;
    } catch (error: any) {
      console.log(error);
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IInquiryCardNumberWithName>(
          this.inquiryCardNumberWithName,
          params,
          error,
          {
            sensitiveStausCode: [403],
            renewTokenFunc: this._getToken,
          }
        );

        if (interceptor) return interceptor;

        throw new mspack.custom_error(
          error.response.data,
          error.response.status || 400
        );
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error_2.response?.data || error_2.message,
          error_2.response?.status || 400
        );
      }
    }
  }

  // public async inquiryDepositNumberWithName(
  //   params: interfaces.IInquiryCardNumberWithName
  // ): Promise<any> {
  //   try {
  //     if (params.isSandBox) {
  //       return response_example.inquiryCard;
  //     }
  //     if (!this._token) {
  //       await this._getToken();
  //     }

  //     const { data } = await axios({
  //       url: encodeURI(
  //         `${this._baseURL}/ide/v1/services/matching?cardNumber=${params.cardNumber}&name=${params.name}`
  //       ),
  //       method: "get",
  //       headers: {
  //         Authorization: `Bearer ${this._token}`,
  //         "Content-Type": "application/json",
  //       },
  //     });

  //     return data;
  //   } catch (error: any) {
  //     console.log(error);
  //     try {
  //       const interceptor = await mspack.request_interceptor.interceptor.bind(
  //         this
  //       )<interfaces.IInquiryCardNumberWithName>(
  //         this.inquiryCardNumberWithName,
  //         params,
  //         error,
  //         {
  //           sensitiveStausCode: [403],
  //           renewTokenFunc: this._getToken,
  //         }
  //       );

  //       if (interceptor) return interceptor;

  //       throw new mspack.custom_error(
  //         error.response.data,
  //         error.response.status || 400
  //       );
  //     } catch (error_2: any) {
  //       throw new mspack.custom_error(
  //         error_2.response?.data || error_2.message,
  //         error_2.response?.status || 400
  //       );
  //     }
  //   }
  // }
}

const FetchInstance = new Fetch();
export default FetchInstance;
