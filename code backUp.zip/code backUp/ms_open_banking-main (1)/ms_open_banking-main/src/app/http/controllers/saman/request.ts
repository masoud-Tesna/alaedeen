import mspack from "mspack";
import axios from "axios";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/saman/response_example";

enum accomplishType {
  "payaPayment",
  "satnaPayment",
  "normalPayment",
  "payaPaymentReport",
  "satnaPaymentReport",
}

class Fetch {
  private _clientID: string = process.env.SAMAN_USER!;
  private _clientSecret: string = process.env.SAMAN_SECRET!;
  private _clientChannel: string = process.env.SAMAN_CHANNEL!;
  private _clientPassword: string = process.env.SAMAN_PASSWORD!;
  private _clientCIF: string = process.env.SAMAN_CIF!;
  private _clientDepositNumber: string = process.env.SAMAN_DEPOSIT_NUMBER!;
  private _clientIban: string = process.env.SAMAN_IBAN!;
  private _token: any;
  private _refreshToken: any;
  private _baseURL: string = "https://kook.sb24.ir";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (
        !this._clientID ||
        !this._clientSecret ||
        !this._clientChannel ||
        !this._clientPassword
      ) {
        throw new mspack.custom_error(
          "SAMAN_SECRET or SAMAN_USER or SAMAN_CHANNEL or SAMAN_PASSWORD not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}:9000/login`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          channel: this._clientChannel,
          correlationId: "satpay-test",
          password: this._clientPassword,
          secretkey: this._clientSecret,
          username: this._clientID,
        },
      });
      this._token = data.token;

      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  private bodyAccomplishment(params: any, type: accomplishType): any {
    const paramsCopy = { ...params };
    switch (type) {
      case accomplishType.payaPayment:
        paramsCopy.channel = this._clientChannel;
        // paramsCopy.token = this._token;
        paramsCopy.cif = this._clientCIF;
        paramsCopy.sourceDepositNumber = this._clientDepositNumber;
        paramsCopy.trackerId = paramsCopy.trackID;
        paramsCopy.clientIp = "192.168.1.114"; // this is just for sample :);
        break;
      case accomplishType.satnaPayment:
        paramsCopy.channel = this._clientChannel;
        paramsCopy.token = this._token;
        paramsCopy.cif = this._clientCIF;
        paramsCopy.sourceDepositNumber = this._clientDepositNumber;
        paramsCopy.trackerId = paramsCopy.trackID;
        paramsCopy.clientIp = "192.168.1.114"; // this is just for sample :);
        break;
      case accomplishType.normalPayment:
        paramsCopy.channel = this._clientChannel;
        paramsCopy.token = this._token;
        paramsCopy.cif = this._clientCIF;
        paramsCopy.referenceNumber = new Date().getTime();
        paramsCopy.sourceDeposit = this._clientDepositNumber;
        paramsCopy.trackerId = paramsCopy.trackID;
        paramsCopy.clientIp = "192.168.1.114"; // this is just for sample :);
        break;
      case accomplishType.payaPaymentReport:
        paramsCopy.channel = this._clientChannel;
        paramsCopy.token = this._token;
        paramsCopy.cif = this._clientCIF;
        paramsCopy.sourceDepositNumber = this._clientDepositNumber;

        break;
      case accomplishType.satnaPaymentReport:
        paramsCopy.channel = this._clientChannel;
        paramsCopy.token = this._token;
        paramsCopy.cif = this._clientCIF;
        paramsCopy.depositNumber = this._clientDepositNumber;
        paramsCopy.trackerId = paramsCopy.trackID;
        paramsCopy.clientIp = "192.168.1.114"; // this is just for sample :);
        break;
      default:
        break;
    }

    return paramsCopy;
  }

  public async payaPayment(params: interfaces.IPayaPayment): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.payaPayment;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}:9003/transfer/ach/normal`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: this.bodyAccomplishment(params, accomplishType.payaPayment),
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IPayaPayment>(this.payaPayment, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });
        if (interceptor) return interceptor;
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error.response.data.message,
          error.response.status
        );
      }

      throw new mspack.custom_error(
        error.response.data.message,
        error.response.status
      );
    }
  }

  public async satnaPayment(params: interfaces.ISatnaPayment): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.payaPayment;
      }

      if (!this._token) {
        await this._getToken();
      }
      console.log(this.bodyAccomplishment(params, accomplishType.satnaPayment));
      const { data } = await axios({
        url: `${this._baseURL}:9006/transfer/rtgs`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: this.bodyAccomplishment(params, accomplishType.satnaPayment),
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.ISatnaPayment>(this.satnaPayment, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });
        if (interceptor) return interceptor;
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error.response.data.message,
          error.response.status
        );
      }

      throw new mspack.custom_error(
        error.response.data.message,
        error.response.status
      );
    }
  }

  public async normalPayment(params: interfaces.INormalPayment): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.normalPayment;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}:9001/transfer/normal`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: this.bodyAccomplishment(params, accomplishType.normalPayment),
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.INormalPayment>(this.normalPayment, params, error, {
          sensitiveStausCode: [403],
          renewTokenFunc: this._getToken,
        });
        if (interceptor) return interceptor;
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error.response.data.message,
          error.response.status
        );
      }

      throw new mspack.custom_error(
        error.response.data.message,
        error.response.status
      );
    }
  }

  public async payaPaymentReport(
    params: interfaces.IPayaPaymentReport
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.payaPayment;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}:9013/transfer/ach/transaction/report`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: this.bodyAccomplishment(params, accomplishType.payaPaymentReport),
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IPayaPaymentReport>(
          this.payaPaymentReport,
          params,
          error,
          { sensitiveStausCode: [403], renewTokenFunc: this._getToken }
        );
        if (interceptor) return interceptor;
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error.response.data.message,
          error.response.status
        );
      }
      throw new mspack.custom_error(
        error.response.data.message,
        error.response.status
      );
    }
  }

  public async satnaPaymentReport(
    params: interfaces.ISatnaPaymentReport
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.payaPayment;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}:9024/transfer/rtgs/report`,
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        data: this.bodyAccomplishment(
          params,
          accomplishType.satnaPaymentReport
        ),
      });

      return data;
    } catch (error: any) {
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.ISatnaPaymentReport>(
          this.satnaPaymentReport,
          params,
          error,
          { sensitiveStausCode: [403], renewTokenFunc: this._getToken }
        );
        if (interceptor) return interceptor;
      } catch (error_2: any) {
        throw new mspack.custom_error(
          error.response.data.message,
          error.response.status
        );
      }
      throw new mspack.custom_error(
        error.response.data.message,
        error.response.status
      );
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
