import mspack from "mspack";
import axios from "axios";
import {
  agent_certificate,
  agent_ignoreSSL,
  getXObhsignature,
} from "../config";
import * as interfaces from "./interfaces";
import response_example from "../../../../../misc/shahin/inquiry/response_example";

class Fetch {
  private _clientID: string = process.env.SHAHIN_CLIENT_ID!;
  private _clientSecret: string = process.env.SHAHIN_PASSWORD!;
  private _token: any;

  private _baseURL: string = "https://94.184.140.112:443";
  private _baseURL_2: string = "https://94.184.140.112:5443";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!",
          400
        );
      }
      const Token = Buffer.from(
        `${this._clientID}:${this._clientSecret}`
      ).toString("base64");
      const { data } = await axios({
        url: `${this._baseURL}/v0.3/obh/oauth/token?grant_type=client_credentials&bank=BSI`,
        method: "post",
        httpsAgent: agent_ignoreSSL,
        headers: {
          authorization: `Basic ${Token}`,
        },
      });

      this._token = data.access_token;
      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async sayyadChequeRegister(
    params: interfaces.ISayyadChequeRegister
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanIdentityInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/aisp/cheque-register`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              chequeSerial: params.chequeSerial,
            },
            "/v0.3/obh/api/aisp/cheque-register",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          chequeSerial: params.chequeSerial,
          nationalCode: params.nationalCode,
          sourceAccount: params.sourceAccount,
          amount: params.amount,
          chequeMedia: params.chequeMedia,
          currency: params.currency,
          description: params.description,
          dueDate: params.dueDate,
          sayadId: params.sayadId,
          serialNo: params.serialNo,
          seriesNo: params.seriesNo,
          accountOwners: params.accountOwners,
          name: params.name,
          shahabId: params.shahabId,
          idCode: params.idCode,
          idType: params.idType,
          receivers: params.receivers,
          signers: params.signers,
          branchCode: params.branchCode,
          chequeType: params.chequeType,
          reason: params.reason,
          bank: params.bank,
          toIban: params.toIban,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      // return;
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.sayyadChequeRegister(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
