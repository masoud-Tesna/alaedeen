import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../models/user";
import Transaction from "../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  inquiryShahkar: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { nationalID, mobile } = req.body;
    try {
      const trackID = v4();
      var shahkarInquiry = await request.inquiryShahkar({
        nationalCode: nationalID,
        mobileNumber: mobile,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      let provider;

      if (shahkarInquiry?.matched) {
        provider = 1;
      }
      if (shahkarInquiry?.status) {
        provider = 2;
      }
      shahkarInquiry = mspack.providers_response_normilizer(
        "shahkar",
        shahkarInquiry
      );
      if (
        shahkarInquiry?.status === "DONE" &&
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شاهکار`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...shahkarInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          shahkarInquiry.provider || "jibit",
          "استعلام شاهکار",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      delete shahkarInquiry.provider; // better to do this at  mspack.response_normlizer_sender
      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(shahkarInquiry) ? { shahkarInquiry, provider } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "jibit",
        "استعلام شاهکار",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  cardToIban: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { card } = req.body;
    try {
      const trackID = v4();
      var cardToIban = await request.cardToIban({
        cardNumber: card,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      let provider;

      if (cardToIban?.number) {
        provider = 1;
      }
      if (cardToIban?.status) {
        provider = 2;
      }
      cardToIban = mspack.providers_response_normilizer(
        "cardToIban",
        cardToIban
      );
      if (
        cardToIban?.status === "DONE" &&
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت تبدیل شماره کارت به شبا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...cardToIban, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          cardToIban.provider || "jibit",
          "تبدیل شماره کارت به شبا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      delete cardToIban.provider; // better to do this at  mspack.response_normlizer_sender
      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(cardToIban) ? { cardToIban, provider } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "jibit",
        "تبدیل شماره کارت به شبا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  cardToIbanArray: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { cards } = req.body;

    const result: any[] = [];
    const totalTrackID = v4();
    for (let card of cards) {
      try {
        const trackID = v4();
        let cardToIban = await request.cardToIban({
          cardNumber: card,
          trackID,
          isSandBox: req.isSandBox!,
        });

        // const findedUser = req.user as IUserDoc;

        let provider;

        if (cardToIban?.number) {
          provider = 1;
        }
        if (cardToIban?.status) {
          provider = 2;
        }
        cardToIban = mspack.providers_response_normilizer(
          "cardToIban",
          cardToIban
        );

        if (
          process.env.NODE_ENV !== "test" &&
          cardToIban?.status === "DONE" &&
          !req.isSandBox
        ) {
          const user =
            (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
              User,
              req,
              mspack.nats_connection.default.client,
              "openBanking"
            )) as unknown as IUserDoc;
          const transaction = await Transaction.build({
            userId: user.id,
            amount: -req.serviceAmount!,
            paymentDesc: `کسر از اعتبار جهت تبدیل شماره کارت به شبا لیستی`,
            paymentProvider: "none" as any,
            terminalNumber: "API usage",
            paymentToken: "API usage",
            paymentSessionID: "API usage",
            status: true,
            orderID: new Date().getTime(),
            traceCode: trackID,
            cardNumber: "API usage",
          });
          const endTime = performance.now();
          await transaction.save();
          await transaction.fireTransactionCompletedEvent();
          await user.fireIncameLogEvent(
            JSON.stringify(req.body),
            JSON.stringify({ ...cardToIban, trackID }),
            JSON.stringify(req.headers),
            200,
            "success",
            endTime - startTime,
            req.url,
            req.serviceAmount!,
            req.serviceBuyAmount!,
            cardToIban.provider || "jibit",
            "تبدیل شماره کارت به شبا(list)",
            req.appLogo,
            req.headers["appname"] as unknown as string
          );
        }
        delete cardToIban.provider; // better to do this at  mspack.response_normlizer_sender
        result.push({
          card,
          hasError: false,
          iban: cardToIban,
          provider,
          error: null,
        });
      } catch (error) {
        const endTime = performance.now();
        await User.fireIncameLogEventStatic(
          req.APIkeyPayload!.userId,
          JSON.stringify(req.body),
          JSON.stringify({ ...error, message: error.message }),
          JSON.stringify(req.headers),
          error.status,
          "error",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "jibit",
          "تبدیل شماره کارت به شبا(list)",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );

        result.push({
          card,
          hasError: true,
          iban: {},
          error: error.message,
          provider: 1,
        });
        //next(error);
      }
    }

    mspack.response_normlizer_sender(true, res, result, 200, totalTrackID);
  },
  cardToDeposit: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { card } = req.body;
    try {
      const trackID = v4();
      var cardToDeposit = await request.cardToDeposit({
        cardNumber: card,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      let provider;

      if (cardToDeposit?.number) {
        provider = 1;
      }
      if (cardToDeposit?.status) {
        provider = 2;
      }
      cardToDeposit = mspack.providers_response_normilizer(
        "cardToDeposit",
        cardToDeposit
      );
      if (
        cardToDeposit?.status === "DONE" &&
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت تبدیل شماره کارت به حساب`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...cardToDeposit, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          cardToDeposit.provider || "jibit",
          "تبدیل شماره کارت به حساب",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      delete cardToDeposit.provider; // better to do this at  mspack.response_normlizer_sender
      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(cardToDeposit) ? { cardToDeposit, provider } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "jibit",
        "تبدیل شماره کارت به حساب",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  inquiryCardNumberIdentity: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { cardNumber, birthDate, nationalID } = req.body;
    try {
      const trackID = v4();
      var inquiryCardNumberIdentity = await request.inquiryCardNumberIdentity({
        cardNumber,
        birthDate,
        nationalCode: nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        typeof inquiryCardNumberIdentity?.matched === "boolean" &&
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام تطبیق شماره کارت با کد ملی`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...inquiryCardNumberIdentity, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "jibit",
          "استعلام تطبیق شماره کارت با کد ملی",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(inquiryCardNumberIdentity)
          ? { inquiryCardNumberIdentity }
          : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "jibit",
        "استعلام تطبیق شماره کارت با کد ملی",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  inquiryCard: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { cardNumber } = req.body;
    try {
      const trackID = v4();
      var inquiryCard = await request.inquiryCard({
        cardNumber,

        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        typeof inquiryCard?.matched === "boolean" &&
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شماره کارت`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...inquiryCard, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "jibit",
          "استعلام شماره کارت",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(inquiryCard) ? { inquiryCard } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "jibit",
        "استعلام شماره کارت",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  inquiryCardNumberWithName: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { cardNumber, name } = req.body;
    try {
      const trackID = v4();
      var inquiryCardNumberWithName = await request.inquiryCardNumberWithName({
        cardNumber,
        name,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        typeof inquiryCardNumberWithName?.matched === "boolean" &&
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام تطبیق شماره کارت و نام`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...inquiryCardNumberWithName, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "jibit",
          "استعلام تطبیق شماره کارت و نام",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(inquiryCardNumberWithName)
          ? { inquiryCardNumberWithName }
          : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "jibit",
        "استعلام تطبیق شماره کارت و نام",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
