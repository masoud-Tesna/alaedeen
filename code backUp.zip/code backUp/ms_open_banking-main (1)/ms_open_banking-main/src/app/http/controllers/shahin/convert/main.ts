import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../../models/user";
import Transaction from "../../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  depositToIban: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { bank, accType, sourceAccount } = req.body;
    try {
      const trackID = v4();
      let depositToIban = await request.depositToIban({
        nationalCode: "10320813170",
        bank,
        accType: "currentAccountJam" as any,
        sourceAccount,
        trackID,
        isSandBox: req.isSandBox!,
      });
      let provider;
      if (depositToIban?.transactionState) {
        provider = 1;
      }
      if (depositToIban?.status) {
        provider = 2;
      }

      depositToIban = mspack.providers_response_normilizer(
        "cardToDeposit",
        depositToIban,
        trackID
      );

      if (
        process.env.NODE_ENV !== "test" &&
        depositToIban?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت تبدیل شماره حساب به شبا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...depositToIban, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          provider === 1 ? "shahin" : "finnotech",
          "تبدیل شماره حساب به شبا",
          req.appLogo,

          req.headers["appname"] as unknown as string
        );
      }
      delete depositToIban.provider;

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(depositToIban) ? { depositToIban, provider } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "تبدیل شماره حساب به شبا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
