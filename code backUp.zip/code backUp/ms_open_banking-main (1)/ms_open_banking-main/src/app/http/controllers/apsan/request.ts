import mspack from "mspack";
import axios from "axios";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/finnotech/inquiry/response_example";

class Fetch {
  private _clientID: string = process.env.APSAN_CLIENT_ID!;
  private _clientSecret: string = process.env.APSAN_PASSWORD!;
  private _token: string = Buffer.from(
    `${this._clientID}:${this._clientSecret}`
  ).toString("base64");
  private _refreshToken: any;
  private _baseURL: string = "https://pay.cpg.ir";

  private async _getPayToken(
    params: interfaces.IGetPayToken
  ): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "APSAN_CLIENT_ID or APSAN_PASSWORD not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}/token`,
        method: "post",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Basic ${this._token}`,
        },
        data: {
          amount: params.amount,
          redirectUri: params.redirectUri,
          terminalId: params.terminalID,
          uniqueIdentifier: params.trackID,
        },
      });
      console.log(data);
      this._token = data.access_token;

      return data;
    } catch (error: any) {
      mspack.log(error);
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async addressByPostcode(
    params: interfaces.IAddressByPostcode
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }
      console.log(`${this._baseURL}/api/v0/Postcode/AddressByPostcode`);
      let clRowId = "";
      for (let i = 0; i < 19; ++i) clRowId += Math.floor(Math.random() * 10);
      const { data } = await axios({
        url: `${this._baseURL}/api/v0/Postcode/AddressByPostcode`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: {
          ClientBatchID: params.trackID,
          PostCodes: [{ ClientRowID: clRowId, PostCode: params.postCode }],
        },
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      mspack.log(error.message);
      throw new mspack.custom_error(error.message, 400);
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
