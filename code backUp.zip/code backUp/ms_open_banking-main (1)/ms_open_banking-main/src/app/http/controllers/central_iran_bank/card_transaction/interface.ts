export interface cardHolderInquiry {
  sourcePAN: string;
  destinationPAN: string;
  amount: number;
  referenceNumber: string;
  sourceAddress: string;
  localization: number;
  acceptorCode: string;
  terminalNumber: string;
  terminalType: number;
  trackID: string;
  isSandBox: boolean;
}
