import mspack from "mspack";
import axios from "axios";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/pardakhtyari/response_example";

class Fetch {
  private _clientID: string = process.env.POST_CLIENT_ID!;
  private _clientSecret: string = process.env.POST_PASSWORD!;
  private _token: string = "bWZzaF9wZjpFQDM2MDAyNDI1YW0=";
  private _refreshToken: any;
  private _baseURL: string = "https://mms.shaparak.ir";

  public async inquirySIAH(params: interfaces.IInquirySIAH): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.inquirySIAH;
      }
      console.log(params);
      const { data } = await axios({
        url: `${this._baseURL}/merchant/webService/api/sayah/proxy/ibanInquiry`,
        method: "post",
        headers: {
          Authorization: `Basic ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });
      delete data.trackingNumber;
      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.response.data, 400);
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
