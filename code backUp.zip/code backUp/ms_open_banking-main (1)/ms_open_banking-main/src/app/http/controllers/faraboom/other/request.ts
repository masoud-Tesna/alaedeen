import mspack from "mspack";
import axios from "axios";
import qs from "qs";
import convert_bank_names from "../../../../../util/convert_bank_names";
import * as interfaces from "./interfaces";

class Fetch {
  private _clientID: string = process.env.FARABOOM_CLIENT_ID!;
  private _clientSecret: string = process.env.FARABOOM_CLIENT_SECRET!;
  private _appKey: string = process.env.FARABOOM_APP_KEY!;
  private _boomToken: string = process.env.FARABOOM_TOKEN_ID_MAIN!;
  private _appKeyMain: string = process.env.FARABOOM_APP_KEY_MAIN!;
  private _token: any;

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._appKey || !this._clientSecret) {
        throw new mspack.custom_error(
          "FARABOOM_CLIENT_ID or FARABOOM_CLIENT_SECRET or FARABOOM_APP_KEY not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: "https://payman2.sandbox.faraboom.co/oauth/token",
        method: "post",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        data: qs.stringify({
          client_id: this._clientID,
          client_secret: this._clientSecret,
          grant_type: "client_credentials",
        }),
      });
      this._token = data.access_token;
      return data;
    } catch (error) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async permissions(): Promise<string | undefined> {
    try {
      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: "https://payman2.sandbox.faraboom.co/v1/payman/creditor/permissions",
        method: "get",
        headers: {
          "app-key": this._appKey,
          "Content-Type": "application/json",
          "Client-Ip-Address": "",
          "Client-Device-Id": "",
          "Client-User-Agent": "",
          "Client-Platform-Type": "",
          "Client-User-Id": "",
          Authorization: `Bearer ${this._token}`,
        },
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.permissions();
        } catch (error_2) {
          throw new mspack.custom_error(
            error.response.data ? error.response.data.error : error.message,
            error.response.status || 400
          );
        }
      } else {
        throw new mspack.custom_error(
          error.response.data ? error.response.data.error : error.message,
          error.response.status || 400
        );
      }
    }
  }

  public async tollDebts(params: interfaces.ITollDebts): Promise<
    | {
        total_amount: string;
        operation_time: string;
      }
    | undefined
  > {
    try {
      const { data } = await axios({
        url: "http://api.faraboom.co/v1/vas/toll/freeway/debts/total",
        method: "post",
        headers: {
          "Accept-Language": "fa",
          "App-Key": this._appKeyMain,
          "Device-Id": "91.92.209.13",
          "Token-Id": this._boomToken,
          "CLIENT-DEVICE-ID": "91.92.209.13",
          "CLIENT-IP-ADDRESS": "127.0.0.1",
          "CLIENT-USER-AGENT": "User Agent",
          "CLIENT-USER-ID": "09197393931",
          "CLIENT-PLATFORM-TYPE": "WEB",
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.tollDebts(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async cardsHolder(params: interfaces.ICardsHolder): Promise<
    | {
        first_name?: "string";
        last_name?: "string";
        transaction_id?: "string";
        operation_time?: "string";
      }
    | undefined
  > {
    try {
      const { data } = await axios({
        url: "http://api.sandbox.faraboom.co/v1/cards/holder",
        method: "post",
        headers: {
          "Accept-Language": "fa",
          "App-Key": this._appKeyMain,
          "Device-Id": "91.92.209.13",
          "Token-Id": this._boomToken,
          "CLIENT-DEVICE-ID": "91.92.209.13",
          "CLIENT-IP-ADDRESS": "127.0.0.1",
          "CLIENT-USER-AGENT": "User Agent",
          "CLIENT-USER-ID": "09197393931",
          "CLIENT-PLATFORM-TYPE": "WEB",
          "Content-Type": "application/json",
        },
        data: params,
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.cardsHolder(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async balance(params: interfaces.IBalance): Promise<
    | {
        available_balance?: number;
        ledger_balance?: number;
        currency?: string;
        operation_time?: string;
      }
    | undefined
  > {
    try {
      const { data } = await axios({
        url: `http://api.sandbox.faraboom.co/v1/cards/${params.pan}/balance`,
        method: "post",
        headers: {
          "Accept-Language": "fa",
          "App-Key": this._appKeyMain,
          "Device-Id": "91.92.209.13",
          "Token-Id": this._boomToken,
          "CLIENT-DEVICE-ID": "91.92.209.13",
          "CLIENT-IP-ADDRESS": "127.0.0.1",
          "CLIENT-USER-AGENT": "User Agent",
          "CLIENT-USER-ID": "09197393931",
          "CLIENT-PLATFORM-TYPE": "WEB",
          "Content-Type": "application/json",
          "Bank-Id": convert_bank_names(params.bankId, "faraboom"),
        },
        data: params,
      });

      return data;
    } catch (error) {
      if (error.response.data.code === "2069") {
        this._token = undefined;
        try {
          await this.cardsHolder(params);
        } catch (error_2) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.errors.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.error
              ? error.response.data.error
              : error.response.data.message
              ? error.response.data.message
              : error.message,
            error.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error
            ? error.response.data.error
            : error.response.data.message
            ? error.response.data.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
