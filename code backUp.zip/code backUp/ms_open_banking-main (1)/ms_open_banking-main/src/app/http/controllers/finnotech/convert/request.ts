import mspack from "mspack";
import axios from "axios";
import qs from "qs";
import scopes from "../scopes";
import * as interfaces from "./interfaces";
import response_example from "../../../../../misc/finnotech/convert/response_example";

class Fetch {
  private _clientID: string = process.env.FINNOTECH_CLIENT_ID!;
  private _clientSecret: string = process.env.FINNOTECH_PASSWORD!;
  private _clientNID: string = process.env.FINNOTECH_NID!;
  private _token: any;
  private _refreshToken: any;

  private _baseURL: string = "https://apibeta.finnotech.ir";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret || !this._clientNID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID or FINNOTECH_PASSWORD or FINNOTECH_NID not set in env variables!",
          400
        );
      }
      const Token = Buffer.from(
        `${this._clientID}:${this._clientSecret}`
      ).toString("base64");
      const { data } = await axios({
        url: `${this._baseURL}/dev/v2/oauth2/token`,
        method: "post",
        headers: {
          authorization: `Basic ${Token}`,
          "Content-Type": "application/json",
        },
        data: {
          grant_type: "client_credentials",
          nid: this._clientNID,
          scopes,
        },
      });

      this._token = data.result.value;
      this._refreshToken = data.result.refreshToken;

      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async cardToIban(params: interfaces.ICardToIban): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.cardToIban;
      }

      if (!this._token) {
        await this._getToken();
      }
      const { data } = await axios({
        url: `${this._baseURL}/facility/v2/clients/${this._clientID}/cardToIban?version=2&trackId=${params.trackID}&card=${params.card}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.cardToIban(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async depositToIban(params: interfaces.IDepositToIban): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.depositToIban;
      }

      if (!this._token) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/facility/v2/clients/${this._clientID}/depositToIban?trackId=${params.trackID}&bankCode=${params.bank}&deposit=${params.deposit}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.depositToIban(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async cardToDeposit(params: interfaces.ICardToDeposit): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.cardToDeposit;
      }

      if (!this._token) {
        await this._getToken();
      }
      const { data } = await axios({
        url: `${this._baseURL}/facility/v2/clients/${this._clientID}/cardToDeposit?trackId=${params.trackID}&card=${params.card}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.cardToDeposit(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
  public async depositOwnerVerifications(
    params: interfaces.IDepositOwnerVerification
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.cardToDeposit;
      }

      if (!this._token) {
        await this._getToken();
      }
      const { data } = await axios({
        url: `${this._baseURL}/facility/v2/clients/${this._clientID}/depositOwnerVerification?trackId=${params.trackID}&deposit=${params.deposit}&bank=${params.bank}&nationalCode=${params.nationalCode}`,
        method: "get",
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
        },
        data: params,
      });

      delete data.trackId;
      return data;
    } catch (error: any) {
      if (
        error.response.data.code === "2069" ||
        error.response.status === 403
      ) {
        this._token = undefined;
        try {
          await this.depositOwnerVerifications(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
