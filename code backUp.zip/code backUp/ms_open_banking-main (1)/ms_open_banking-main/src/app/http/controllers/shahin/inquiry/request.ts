import mspack from "mspack";
import axios from "axios";
import replacementServce from "../../finnotech/inquiry/request";
//import multi_providers from "../../../../../util/multi_providers_service";
import {
  agent_certificate,
  agent_ignoreSSL,
  getXObhsignature,
} from "../config";
import * as interfaces from "./interfaces";
import response_example from "../../../../../misc/shahin/inquiry/response_example";

class Fetch {
  private _clientID: string = process.env.SHAHIN_CLIENT_ID!;
  private _clientSecret: string = process.env.SHAHIN_PASSWORD!;
  private _token: any;

  private _baseURL: string = "https://94.184.140.112:443";
  private _baseURL_2: string = "https://94.184.140.112:5443";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!",
          400
        );
      }
      const Token = Buffer.from(
        `${this._clientID}:${this._clientSecret}`
      ).toString("base64");
      const { data } = await axios({
        url: `${this._baseURL}/v0.3/obh/oauth/token?grant_type=client_credentials&bank=BSI`,
        method: "post",
        httpsAgent: agent_ignoreSSL,
        headers: {
          authorization: `Basic ${Token}`,
        },
      });

      this._token = data.access_token;
      return data;
    } catch (error: any) {
  
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async nationalIdentityInquiry(
    params: interfaces.INationalIdentityInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.nationalIdentityInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/inquiry/get-national-identity`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            { nationalCode: params.nationalCode, birthDate: params.birthDate },
            "/v0.3/obh/api/inquiry/get-national-identity",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          birthDate: params.birthDate,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }

      // return;
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.nationalIdentityInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async ibanIdentityInquiry(
    params: interfaces.IIbanIdentityInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanIdentityInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/inquiry/check-iban-nationalcode`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              birthDate: params.birthDate,
              iban: params.iban,
            },
            "/v0.3/obh/api/inquiry/check-iban-nationalcode",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          birthDate: params.birthDate,
          iban: params.iban,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      // return;
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.ibanIdentityInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async ibanInquiry(params: interfaces.IIbanInquiry): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/aisp/get-iban-info`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              bank: params.bank,
              sourceAccount: params.iban,
            },
            "/v0.3/obh/api/aisp/get-iban-info",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          bank: params.bank,
          sourceAccount: params.iban,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      const multi_providers_service = await mspack.multi_providers_service(
        {
          isSandBox: params.isSandBox,
          trackID: params.trackID,
          iban: params.iban,
        },
        replacementServce,
        "ibanInquiry",
        "finnotech",
        error.response.status
      );

      if (multi_providers_service.replacement) {
        return multi_providers_service.response;
      }
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.ibanInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async cardInquiry(params: interfaces.ICardInquiry): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/card/get-card-info`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              bank: params.bank,
              cardNumber: params.cardNumber,
              sourceAccount: params.sourceAccount,
            },
            "/v0.3/obh/api/card/get-card-info",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          bank: params.bank,
          cardNumber: params.cardNumber,
          sourceAccount: params.sourceAccount,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      // return;
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.cardInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async phoneValidityInquiry(
    params: interfaces.IPhoneValidityInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanIdentityInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/inquiry/check-phone-validity`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              mobileNumber: params.mobileNumber,
            },
            "/v0.3/obh/api/inquiry/check-phone-validity",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          mobileNumber: params.mobileNumber,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      // return;
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.phoneValidityInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async accountInfoInquiry(
    params: interfaces.IAccountInfoInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanIdentityInquiry;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/aisp/get-account-info`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              bank: params.bank,
              sourceAccount: params.sourceAccount,
            },
            "/v0.3/obh/api/aisp/get-account-info",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          bank: params.bank,
          sourceAccount: params.sourceAccount,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      // return;
      if (error.response.status === 401) {
        this._token = undefined;
        try {
          await this.accountInfoInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }

  public async sayyadChequeInquiry(
    params: interfaces.ISayyadChequeInquiry
  ): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.ibanIdentityInquiry;
      }
 
      if (!this._token) {
   
        await this._getToken();
      }
    
      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/inquiry/cheque-inquiry`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              chequeSerial: params.chequeSerial,
            },
            "/v0.3/obh/api/inquiry/cheque-inquiry",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          chequeSerial: params.chequeSerial,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      // return;

      if (error.response.status === 401) {
      
        this._token = undefined;
        try {
          await this.sayyadChequeInquiry(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error.response.data.respObject.message
              ? error.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.respObject.subErrors?.map((i: any) => {
          detail.push({
            message: `rejectedValue is : ${i.rejectedValue}`,
            param: i.field,
          });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.respObject.message
            ? error.response.data.respObject.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
