export interface ICardInquiry {
  card: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IPanIdentifierInquiry {
  cardNumber: string;
  mobileNumber: string;
  identifier: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IPanMobileIdentifier {
  cardNumber: string;
  mobileNumber: string;
  identifier: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IAccountMobileIdentifier {
  accountNumber: string;
  mobileNumber: string;
  identifier: string;
  trackID: string;
  isSandBox: boolean;
}
export interface IShahkarInquiry {
  mobileNumber: string;
  identifier: string;
  trackID: string;
  isSandBox: boolean;
}
export interface IAccountIdentifier {
  accountNumber: string;
  identifier: string;
  trackID: string;
  isSandBox: boolean;
}

export interface cardToIban {
  cardNumber: string;
  trackID: string;
  isSandBox: boolean;
}
