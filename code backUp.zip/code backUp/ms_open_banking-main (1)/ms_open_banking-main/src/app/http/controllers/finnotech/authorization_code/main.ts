import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../../models/user";
import Transaction from "../../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  getAuthPage: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const {
      bank,
      scope,
      // callBack
    } = req.body;
    try {
      const requestInstance = new request();
      const getAuthPage = await requestInstance.getAuthPage({
        bank,
        scope,
        userCallBack: "https://micro.satpay.ir/api/finnotech/authorize/back",
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;
      res.setHeader("location", getAuthPage!);
      mspack.response_normlizer_sender(true, res, {}, 302);
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount || 0,
        req.serviceBuyAmount || 0,
        "finnotech",
        "internal",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  callBack: async (req: Request, res: Response, next: NextFunction) => {
    const { code, state } = req.query;
    try {
      const requestInstance = new request();
      const getToken = await requestInstance.getToken({
        code: code as string,
        state: state as string,
        isSandBox: req.isSandBox!,
      });
      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(getToken) ? { getToken } : {},
        200
      );
    } catch (error) {
      next(error);
    }
  },
  getBalance: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { deposit, token, bank, refreshToken } = req.body;
    try {
      const trackID = v4();
      const requestInstance = new request();
      const getBalance = await requestInstance.getBalance({
        deposit,
        token,
        bank,
        refreshToken,
        trackID,
        isSandBox: req.isSandBox!,
      });
      // const findedUser = req.user as IUserDoc;
      if (
        process.env.NODE_ENV !== "test" &&
        getBalance?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام موجودی حساب`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...getBalance, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام موجودی حساب",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(getBalance) ? { getBalance } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام موجودی حساب",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  getStatement: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { deposit, token, bank, refreshToken } = req.body;
    try {
      const trackID = v4();
      const requestInstance = new request();
      const getStatement = await requestInstance.getStatement({
        deposit,
        token,
        bank,
        refreshToken,
        trackID,
        isSandBox: req.isSandBox!,
      });
      // const findedUser = req.user as IUserDoc;
      if (
        process.env.NODE_ENV !== "test" &&
        getStatement?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام گردش حساب`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...getStatement, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام گردش حساب",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(getStatement) ? { getStatement } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام گردش حساب",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
