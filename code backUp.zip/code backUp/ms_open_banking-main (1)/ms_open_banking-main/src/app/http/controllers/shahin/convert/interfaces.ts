enum accType {
  "currentAccountJam",
}

export interface IDepositToIban {
  nationalCode: string;
  bank: string;
  sourceAccount: string;
  accType?: accType;
  trackID: string;
  isSandBox: boolean;
}

// export interface IInquiryCard {
//   mobile: string;
//   trackID: string;
//   isSandBox: boolean;
// }

// export interface IShahkarInquiry {
//   mobile: string;
//   nationalID: string;
//   trackID: string;
//   isSandBox: boolean;
// }

// export interface IFacilityInquiry {
//   nationalID: string;
//   trackID: string;
//   isSandBox: boolean;
// }
// export interface IBackChequesInquiry {
//   nationalID: string;
//   trackID: string;
//   isSandBox: boolean;
// }
// export interface IDrivingOffenseInquiry {
//   serial: string;
//   trackID: string;
//   isSandBox: boolean;
// }

// export interface IBillingInquiry {
//   type: string;
//   billID: string;
//   trackID: string;
//   isSandBox: boolean;
// }
