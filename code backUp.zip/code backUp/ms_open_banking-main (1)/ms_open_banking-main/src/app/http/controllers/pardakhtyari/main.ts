import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../models/user";
import Transaction from "../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  inquirySIAH: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { identifierType, iban, nationalID } = req.body;
    try {
      const trackID = v4();
      const inquirySIAH = await request.inquirySIAH({
        identifierType,
        iban,
        identifier: nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        !req.isSandBox &&
        inquirySIAH.result === 0
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام تطبیق کد ملی و شبا به تفکیک حقوقی/حقیقی`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...inquirySIAH, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "centralBank",
          "استعلام تطبیق کد ملی و شبا به تفکیک حقوقی/حقیقی",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(inquirySIAH) ? { inquirySIAH } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "centralBank",
        "استعلام تطبیق کد ملی و شبا به تفکیک حقوقی/حقیقی",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
