import mspack from "mspack";
import axios from "axios";
import qs from "qs";
import https from "https";
import * as interfaces from "./interfaces";
import response_example from "../../../../misc/iran_credit/response_example";

class Fetch {
  private _clientID: string = process.env.IRANCREDIT_CLIENT_ID!;
  private _clientSecret: string = process.env.IRANCREDIT_PASSWORD!;
  private _token: any;
  private _APIKey: any;
  private _baseURL: string = "https://app.ics24.ir";
  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "IRANCREDIT_CLIENT_ID or IRANCREDIT_PASSWORD not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}/connect/token`,
        method: "post",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
        data: qs.stringify({
          Username: this._clientID,
          Password: this._clientSecret,
        }),
      });

      if (data.hasError) {
        throw new mspack.custom_error(data.messages[0], 400);
      }
      this._token = data.data.accessToken;
      this._APIKey = data.data.apiKey;

      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async startRequest(params: interfaces.IStartRequest): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.startRequest;
      }

      if (!this._token && !this._APIKey) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/b2b/api/request`,
        method: "post",
        headers: {
          "x-version": "2.0",
          "x-apikey": this._APIKey,
          Authorization: `Bearer ${this._token}`,
          "Content-Type": params.multipart
            ? "application/x-www-form-urlencoded"
            : "application/json",
        },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
        data: qs.stringify({
          RealPersonNationalCode: params.realPersonNationalCode,
          MobileNumber: params.mobileNumber,
          LegalPersonNationalCode: params.legalPersonNationalCode,
        }),
      });

      if (data.hasError) {
        throw new mspack.custom_error(data.messages[0], 400);
      }

      return data;
    } catch (error: any) {
      if (error.response && error.response.status === 401) {
        this._token = undefined;
        this._APIKey = undefined;
        try {
          await this.startRequest(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.message,
            error_2.response?.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.message,
          error.response?.status || 400,
          params.trackID
        );
      }
    }
  }

  public async validate(params: interfaces.IValidate): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.validate;
      }

      if (!this._token && !this._APIKey) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/b2b/api/request/${params.token}/validate`,
        method: "post",
        headers: {
          "x-version": "2.0",
          "x-apikey": this._APIKey,
          Authorization: `Bearer ${this._token}`,
          "Content-Type": params.multipart
            ? "application/x-www-form-urlencoded"
            : "application/json",
        },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
        data: qs.stringify({
          Token: params.code,
        }),
      });

      if (data.hasError) {
        throw new mspack.custom_error(data.messages[0], 400);
      }

      return data;
    } catch (error: any) {
      if (error.response && error.response.status === 401) {
        this._token = undefined;
        this._APIKey = undefined;
        try {
          await this.validate(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.message,
            error_2.response?.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.message,
          error.response?.status || 400,
          params.trackID
        );
      }
    }
  }

  public async reportJSON(params: interfaces.IReportJSON): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token && !this._APIKey) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/b2b/api/request/${params.token}/status`,
        method: "get",
        headers: {
          "x-version": "2.0",
          "x-apikey": this._APIKey,
          Authorization: `Bearer ${this._token}`,
          "Content-Type": params.multipart
            ? "application/x-www-form-urlencoded"
            : "application/json",
        },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
      });

      if (data.hasError || !data.data.reportLink) {
        throw new mspack.custom_error(
          data.messages ? data.messages[0] : data.data.statusTitle,
          400
        );
      }

      const uniqueIcCode = data.data.reportLink.toString().split("report/")[1];

      const JSON_report = await axios({
        url: `${this._baseURL}/report/${uniqueIcCode}/json`,
        method: "get",
        headers: {
          "x-version": "2.0",
          "x-apikey": this._APIKey,
          Authorization: `Bearer ${this._token}`,
          "Content-Type": params.multipart
            ? "application/x-www-form-urlencoded"
            : "application/json",
        },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
      });
      if (JSON_report.data.hasError) {
        throw new mspack.custom_error(
          JSON_report.data.messages[0].message,
          400
        );
      }
      return JSON_report.data;
    } catch (error: any) {
      if (error.response && error.response.status === 401) {
        this._token = undefined;
        this._APIKey = undefined;
        try {
          await this.reportJSON(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.message,
            error_2.response?.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.message,
          error.response?.status || 400,
          params.trackID
        );
      }
    }
  }
  public async reportLink(params: interfaces.IReportJSON): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.reportJSON;
      }

      if (!this._token && !this._APIKey) {
        await this._getToken();
      }

      const { data } = await axios({
        url: `${this._baseURL}/b2b/api/request/${params.token}/status`,
        method: "get",
        headers: {
          "x-version": "2.0",
          "x-apikey": this._APIKey,
          Authorization: `Bearer ${this._token}`,
          "Content-Type": params.multipart
            ? "application/x-www-form-urlencoded"
            : "application/json",
        },
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
        }),
      });

      if (data.hasError || !data.data.reportLink) {
        throw new mspack.custom_error(
          data.messages ? data.messages[0] : data.data.statusTitle,
          400
        );
      }

      return data.data;
    } catch (error: any) {
      if (error.response && error.response.status === 401) {
        this._token = undefined;
        this._APIKey = undefined;
        try {
          await this.reportJSON(params);
        } catch (error_2: any) {
          throw new mspack.custom_error(
            error_2.message,
            error_2.response?.status || 400,
            params.trackID
          );
        }
      } else {
        throw new mspack.custom_error(
          error.message,
          error.response?.status || 400,
          params.trackID
        );
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
