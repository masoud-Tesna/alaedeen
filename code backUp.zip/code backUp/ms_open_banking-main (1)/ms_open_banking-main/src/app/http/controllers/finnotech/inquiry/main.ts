import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../../models/user";
import Transaction from "../../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  ibanInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { iban } = req.body;
    try {
      const trackID = v4();
      const ibanInquiry = await request.ibanInquiry({
        iban,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        ibanInquiry?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شماره شبا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...ibanInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام شماره شبا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(ibanInquiry) ? { ibanInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام شماره شبا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  shahkarInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { mobile, nationalID } = req.body;
    try {
      const trackID = v4();

      const shahkarInquiry = await request.shahkarInquiry({
        mobile,
        nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        shahkarInquiry?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شاهکار`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...shahkarInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام شاهکار",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(shahkarInquiry) ? { shahkarInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام شاهکار",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  facilityInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { nationalID } = req.body;
    try {
      const trackID = v4();

      const facilityInquiry = await request.facilityInquiry({
        nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        facilityInquiry?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام تسهیلات`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...facilityInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام تسهیلات",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(facilityInquiry) ? { facilityInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام تسهیلات",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  backChequesInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { nationalID } = req.body;
    try {
      const trackID = v4();

      const backChequesInquiry = await request.backChequesInquiry({
        nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        backChequesInquiry?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام چک برگشتی`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...backChequesInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام چک برگشتی",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(backChequesInquiry) ? { backChequesInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام چک برگشتی",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  drivingOffenseInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { serial } = req.body;
    try {
      const trackID = v4();

      const drivingOffenseInquiry = await request.drivingOffenseInquiry({
        serial,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        drivingOffenseInquiry?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام خلافی خودرو`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...drivingOffenseInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام خلافی خودرو",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(drivingOffenseInquiry) ? { drivingOffenseInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام خلافی خودرو",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );

      next(error);
    }
  },
  billingInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { type, billID } = req.body;
    try {
      const trackID = v4();

      const billingInquiry = await request.billingInquiry({
        type,
        billID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        billingInquiry?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام قبوض`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...billingInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام قبوض",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(billingInquiry) ? { billingInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام قبوض",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );

      next(error);
    }
  },
  inquiryCard: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { mobile } = req.body;
    try {
      const trackID = v4();

      const inquiryCard = await request.inquiryCard({
        mobile,
        trackID,
        isSandBox: req.isSandBox!,
      });

      // const findedUser = req.user as IUserDoc;

      if (
        process.env.NODE_ENV !== "test" &&
        inquiryCard?.status === "DONE" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام اطلاعات کارت`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...inquiryCard, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "استعلام اطلاعات کارت",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(inquiryCard) ? { inquiryCard } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "finnotech",
        "استعلام اطلاعات کارت",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );

      next(error);
    }
  },
};
