import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../../models/user";
import DirectDebit from "../../../../models/directDebit";
import Transaction from "../../../../models/transaction";
import * as interfaces from "./interfaces";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  permissions: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const permissions = await request.permissions();
      await mspack.increase_APIkey_usage_count.default<IUserDoc>(
        User,
        req,
        mspack.nats_connection.default.client,
        "openBanking"
      );

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(permissions) ? permissions : {},
        200
      );
    } catch (error) {
      next(error);
    }
  },
  create_covenant: async (req: Request, res: Response, next: NextFunction) => {
    const { covenant, redirectURL, mobile, nationalID, traceNumber } = req.body;
    try {
      const trackID = v4();
      const create_covenant = await request.create_covenant({
        payman: covenant as interfaces.PaymanObject,
        redirect_url:
          process.env.PRODUCT_MODE === "NO"
            ? `http://ms.local/api/open-banking/direct-debit/back?state=${traceNumber}`
            : `https://localhost/?state=${traceNumber}`,
        trace_id: traceNumber,
        mobile,
        nationalID,
        trackID,
      });
      const directDebit = await DirectDebit.build({
        callbackURL: redirectURL,
        mobile,
        traceNumber,
        nationalID,
        covenant,
        userId: req.APIkeyPayload.userId,
      });
      await directDebit.save();
      await mspack.increase_APIkey_usage_count.default<IUserDoc>(
        User,
        req,
        mspack.nats_connection.default.client,
        "openBanking"
      );

      res.setHeader("location", create_covenant!);

      mspack.response_normlizer_sender(true, res, {}, 302, trackID);
    } catch (error) {
      next(error);
    }
  },

  peyman_back: async (req: Request, res: Response, next: NextFunction) => {
    const { payman_code, status, state } = req.query;
    let callbackURL;
    try {
      const trackID = v4();
      const peymanID = await request.getPeymanID({
        payman_code: payman_code as string,
        trace_id: trackID,
      });

      // const tracePeymanID = await request.getTracePeymanID({
      //   trace_id: state as string,
      // });
      const directDebit = await DirectDebit.findOne({
        traceNumber: state as string,
      });
      if (!directDebit)
        throw new mspack.custom_error("Invalid traceNumber", 400);
      directDebit.set({ sign: true, peymanID: peymanID!.payman_id });
      await directDebit.save();
      callbackURL = directDebit.callbackURL;

      res.redirect(`${callbackURL}?traceNumber=${state}&$status=${status}`);
      // mspack.response_normlizer_sender(
      //   true,
      //   res,
      //   { directDebit },
      //   200,
      //   trackID
      // );
    } catch (error) {
      res.redirect(`${callbackURL}?traceNumber=0&$status=ERROR`);
      //next(error);
    }
  },
  start_pay: async (req: Request, res: Response, next: NextFunction) => {
    const { payman_id, amount, description } = req.body;
    try {
      const startTime = performance.now();
      const trackID = v4();
      const client_transaction_date = new Date();
      const paymentInfo = await request.startPay({
        amount,
        client_transaction_date,
        description:
          description ||
          `direct debit ${amount} Rial transaction request at ${client_transaction_date}`,
        payman_id,
        trace_id: trackID,
        trackID,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        paymentInfo!.status === "SUCCEED" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc:
            "کسر از اعتبار جهت درخواست برداشت وجه از سرویس برداشت مستقیم",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...paymentInfo, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "درخواست برداشت وجه از سرویس برداشت مستقیم",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(paymentInfo) ? paymentInfo : {},
        200,
        trackID
      );
    } catch (error) {
      next(error);
    }
  },

  start_bill_pay: async (req: Request, res: Response, next: NextFunction) => {
    const { payman_id, bill_id, pay_id } = req.body;
    try {
      const startTime = performance.now();
      const trackID = v4();
      const paymentInfo = await request.startBillPay({
        bill_id,
        pay_id,
        payman_id,
        trace_id: trackID,
        trackID,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        paymentInfo!.referral_number &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc:
            "کسر از اعتبار جهت درخواست برداشت وجه از سرویس برداشت مستقیم جهت تسویه قبوض",
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...paymentInfo, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "finnotech",
          "درخواست برداشت وجه از سرویس برداشت مستقیم جهت تسویه قبوض",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(paymentInfo) ? paymentInfo : {},
        200,
        trackID
      );
    } catch (error) {
      next(error);
    }
  },

  covenantInfo: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const trackID = v4();

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(req.report) ? req.report : {},
        200,
        trackID
      );
    } catch (error) {
      next(error);
    }
  },
};
