import mspack from "mspack";
import axios from "axios";
import qs from "qs";
import * as interfaces from "./interface";

class Fetch {
  private _clientID: string = process.env.CBI_CLIENT_ID!;
  private _clientSecret: string = process.env.CBI_CLIENT_SECRET!;
  private _token: string = Buffer.from(
    `${process.env.CBI_CLIENT_ID!}:${process.env.CBI_CLIENT_SECRET!}`
  ).toString("base64");
  private _baseURL: string = "185.167.72.9";
  private _hobPort: string = "8090";

  public async cardHolderInquiry(
    params: interfaces.cardHolderInquiry
  ): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "CBI_CLIENT_ID or CBI_CLIENT_SECRET not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}:${this._hobPort}/banking/cardHolderInquiry/sync`,
        method: "post",
        headers: {
          Authorization: `Bearer ${this._token}`,
        },
        data: {
          trackingNumber: params.trackID,
          sourcePAN: params.sourcePAN,
          destinationPAN: params.destinationPAN,
          amount: params.amount,
          referenceNumber: params.referenceNumber,
          sourceAddress: params.sourceAddress,
          localization: params.localization,
          acceptorCode: params.acceptorCode,
          terminalNumber: params.terminalNumber,
          terminalType: params.terminalType,
        },
      });

      return data;
    } catch (error) {}
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
