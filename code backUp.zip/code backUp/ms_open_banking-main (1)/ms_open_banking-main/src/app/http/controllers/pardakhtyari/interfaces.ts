export interface IInquirySIAH {
  identifierType: number;
  iban: string;
  identifier: string;
  trackID: string;
  isSandBox: boolean;
}
