import mspack from "mspack";
import axios from "axios";
import replacementServce from "../../finnotech/convert/request";
//import multi_providers from "../../../../../util/multi_providers_service";
import convert_bank_names from "../../../../../util/convert_bank_names";

import {
  agent_certificate,
  agent_ignoreSSL,
  getXObhsignature,
} from "../config";
import * as interfaces from "./interfaces";
import response_example from "../../../../../misc/shahin/inquiry/response_example";

class Fetch {
  private _clientID: string = process.env.SHAHIN_CLIENT_ID!;
  private _clientSecret: string = process.env.SHAHIN_PASSWORD!;
  private _token: any;

  private _baseURL: string = "https://94.184.140.112:443";
  private _baseURL_2: string = "https://94.184.140.112:5443";

  private async _getToken(): Promise<string | undefined> {
    try {
      if (!this._clientID || !this._clientSecret) {
        throw new mspack.custom_error(
          "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!",
          400
        );
      }
      const Token = Buffer.from(
        `${this._clientID}:${this._clientSecret}`
      ).toString("base64");
      const { data } = await axios({
        url: `${this._baseURL}/v0.3/obh/oauth/token?grant_type=client_credentials&bank=BSI`,
        method: "post",
        httpsAgent: agent_ignoreSSL,
        headers: {
          authorization: `Basic ${Token}`,
        },
      });

      this._token = data.access_token;
      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  public async depositToIban(params: interfaces.IDepositToIban): Promise<any> {
    try {
      if (params.isSandBox) {
        return response_example.depositToIban;
      }

      if (!this._token) {
        await this._getToken();
      }

      const timeStamp = new Date().getTime();
      const { data } = await axios({
        url: `${this._baseURL_2}/v0.3/obh/api/aisp/get-iban`,
        method: "post",
        httpsAgent: agent_certificate,
        headers: {
          Authorization: `Bearer ${this._token}`,
          "Content-Type": "application/json",
          "X-Obh-uuid": params.trackID,
          "X-Obh-timestamp": timeStamp,
          "X-Obh-signature": getXObhsignature(
            {
              nationalCode: params.nationalCode,
              sourceAccount: params.sourceAccount,
              bank: params.bank,
              accType: params.accType,
            },
            "/v0.3/obh/api/aisp/get-iban",
            params.trackID,
            timeStamp,
            "POST" as any
          ),
        },
        data: {
          nationalCode: params.nationalCode,
          sourceAccount: params.sourceAccount,
          bank: params.bank,
          accType: params.accType,
        },
      });

      return data;
    } catch (error: any) {
      if (
        error.message ===
        "SHAHIN_CLIENT_ID or SHAHIN_PASSWORD not set in env variables!"
      ) {
        throw error;
      }
      try {
        const interceptor = await mspack.request_interceptor.interceptor.bind(
          this
        )<interfaces.IDepositToIban>(this.depositToIban, params, error, {
          sensitiveStausCode: [401],
          renewTokenFunc: this._getToken,
        });

        if (interceptor) return interceptor;
        else throw error;
      } catch (error_2: any) {
        const multi_providers_service = await mspack.multi_providers_service(
          {
            isSandBox: params.isSandBox,
            trackID: params.trackID,
            deposit: params.sourceAccount.replace(/-/g, "/"),
            bank: convert_bank_names(params.bank),
          },
          replacementServce,
          "depositToIban",
          "finnotech",
          error_2.response.status
        );
        if (multi_providers_service.replacement) {
          return multi_providers_service.response;
        } else {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.respObject.subErrors?.map((i: any) => {
            detail.push({
              message: `rejectedValue is : ${i.rejectedValue}`,
              param: i.field,
            });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.respObject.message
              ? error_2.response.data.respObject.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      }
    }
  }
}

const FetchInstance = new Fetch();
export default FetchInstance;
