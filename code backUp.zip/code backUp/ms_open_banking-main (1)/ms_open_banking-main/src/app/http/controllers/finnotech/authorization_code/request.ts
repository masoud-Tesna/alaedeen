import mspack from "mspack";
import axios from "axios";
import * as interfaces from "./interfaces";
import response_example from "../../../../../misc/finnotech/authorization_code/response_example";

class Fetch {
  private _clientID: string = process.env.FINNOTECH_CLIENT_ID!;
  private _clientSecret: string = process.env.FINNOTECH_PASSWORD!;
  private _clientNID: string = process.env.FINNOTECH_NID!;
  private _callBackURL: string =
    "https://ms.local/api/finnotech/authorize/back";
  private _token: any;
  private _refreshToken: any;
  private _baseURL: string = "https://apibeta.finnotech.ir";

  public async getAuthPage(
    params: interfaces.IGetToken
  ): Promise<string | undefined> {
    try {
      if (!this._clientID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID not set in env variables!",
          400
        );
      }

      let scope = "";
      for (let i in params.scope) {
        if (params.scope.length === parseInt(i) + 1) {
          scope += `${params.scope[i]}`;
        } else {
          scope += `${params.scope[i]},`;
        }
      }

      const { config } = await axios({
        url: `${this._baseURL}/dev/v2/oauth2/authorize?client_id=${this._clientID}&response_type=code&redirect_uri=${this._callBackURL}&scope=${scope}&limit=&count=&bank=${params.bank}&state=${params.bank}_${params.userCallBack}`,
        method: "get",
        headers: {
          "Content-Type": "application/json",
        },
      });

      return config.url;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }

  private async _getRefreshToken(
    refresh_token: string,
    bankID: string
  ): Promise<string | undefined> {
    try {
      if (!this._clientID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}/dev/v2/oauth2/token`,
        method: "post",
        headers: {
          Authorization: `Basic c2F0cGF5OmY5ZDMwNDlkOTI2MjhjODhhZDQz`,
          "Content-Type": "application/json",
        },
        data: {
          refresh_token,
          grant_type: "refresh_token",
          bank: bankID,
          token_type: "CODE",
        },
      });

      return data.result;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }
  public async getToken(
    params: interfaces.IToken
  ): Promise<string | undefined> {
    try {
      if (!this._clientID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID not set in env variables!",
          400
        );
      }

      const { data } = await axios({
        url: `${this._baseURL}/dev/v2/oauth2/token`,
        method: "post",
        headers: {
          Authorization: `Basic c2F0cGF5OmY5ZDMwNDlkOTI2MjhjODhhZDQz`,
          "Content-Type": "application/json",
        },
        data: {
          code: params.code,
          grant_type: "authorization_code",
          bank: params.state.split("_")[0],
          redirect_uri: this._callBackURL,
        },
      });

      return data;
    } catch (error: any) {
      throw new mspack.custom_error(error.message, 400);
    }
  }
  public async getBalance(params: interfaces.IGetBalance): Promise<any> {
    try {
      if (!this._clientID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID not set in env variables!",
          400
        );
      }

      if (params.isSandBox) {
        return response_example.getBalance;
      }
      const { data } = await axios({
        url: `${this._baseURL}/oak/v2/clients/${this._clientID}/deposits/${params.deposit}/balance?trackId=${params.trackID}`,
        method: "get",
        headers: {
          Authorization: `Basic ${params.token}`,
          "Content-Type": "application/json",
        },
        data: {
          deposit: params.deposit,
        },
      });
      delete data.trackId;
      return data;
    } catch (error: any) {
      if (error.code == "UNAUTHORIZED") {
        try {
          const new_token = await this._getRefreshToken(
            params.refreshToken,
            params.bank
          );
          params.token = new_token!;
          await this.getBalance(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
  public async getStatement(params: interfaces.IGetStatement): Promise<any> {
    try {
      if (!this._clientID) {
        throw new mspack.custom_error(
          "FINNOTECH_CLIENT_ID not set in env variables!",
          400
        );
      }

      if (params.isSandBox) {
        return response_example.getStatement;
      }
      const { data } = await axios({
        url: `${this._baseURL}/oak/v2/clients/${this._clientID}/deposits/${params.deposit}/statement?trackId=${params.trackID}`,
        method: "get",
        headers: {
          Authorization: `Basic ${params.token}`,
          "Content-Type": "application/json",
        },
        data: {
          deposit: params.deposit,
        },
      });
      delete data.trackId;
      return data;
    } catch (error: any) {
      if (error.code == "UNAUTHORIZED") {
        try {
          const new_token = await this._getRefreshToken(
            params.refreshToken,
            params.bank
          );
          params.token = new_token!;
          await this.getStatement(params);
        } catch (error_2: any) {
          const detail: { message: any; param: string }[] = [];
          error_2.response.data.errors?.map((i: any) => {
            detail.push({ message: i.error || i.message, param: "" });
          });
          throw new mspack.custom_error_with_detail(
            error_2.response.data.error.message
              ? error_2.response.data.error.message
              : error_2.message,
            error_2.response.status || 400,
            detail,
            params.trackID
          );
        }
      } else {
        const detail: { message: any; param: string }[] = [];
        error.response.data.errors?.map((i: any) => {
          detail.push({ message: i.error || i.message, param: "" });
        });
        throw new mspack.custom_error_with_detail(
          error.response.data.error.message
            ? error.response.data.error.message
            : error.message,
          error.response.status || 400,
          detail,
          params.trackID
        );
      }
    }
  }
}

//const FetchInstance = new Fetch();
export default Fetch;
