export interface IGetToken {
  scope: string[];
  bank: string;
  userCallBack: string;
  isSandBox: boolean;
}

export interface IToken {
  code: string;
  state: string;
  isSandBox: boolean;
}
export interface IGetBalance {
  deposit: string;
  bank: string;
  token: string;
  refreshToken: string;
  trackID: string;
  isSandBox: boolean;
}
export interface IGetStatement {
  deposit: string;
  bank: string;
  token: string;
  refreshToken: string;
  trackID: string;
  isSandBox: boolean;
}
