import { Request, Response, NextFunction } from "express";
import request from "./request";
import mspack from "mspack";
import _ from "lodash";
import User, { IUserDoc } from "../../../../models/user";
import Transaction from "../../../../models/transaction";
import { v4 } from "uuid";
import { performance } from "perf_hooks";

export default {
  nationalIdentityInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { nationalID, birthDate } = req.body;
    try {
      const trackID = v4();
      const nationalIdentityInquiry = await request.nationalIdentityInquiry({
        nationalCode: nationalID,
        birthDate,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        nationalIdentityInquiry?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام اطلاعات کد ملی`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...nationalIdentityInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "shahin",
          "استعلام اطلاعات کد ملی",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(nationalIdentityInquiry) ? { nationalIdentityInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام اطلاعات کد ملی",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  ibanIdentityInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { nationalID, birthDate, iban } = req.body;
    try {
      const trackID = v4();
      const ibanIdentityInquiry = await request.ibanIdentityInquiry({
        iban,
        nationalCode: nationalID,
        birthDate,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        ibanIdentityInquiry?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام صحت سنجی کد ملی و شماره شبا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...ibanIdentityInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "shahin",
          "استعلام صحت سنجی کد ملی و شماره شبا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(ibanIdentityInquiry) ? { ibanIdentityInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام صحت سنجی کد ملی و شماره شبا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  ibanInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { iban } = req.body;

    try {
      const trackID = v4();
      const ibanInquiry = await request.ibanInquiry({
        iban,
        bank: "BSI",
        nationalCode: "10320813170",
        trackID,
        isSandBox: req.isSandBox!,
      });
      let provider;

      if (ibanInquiry?.transactionState) {
        provider = 1;
      }
      if (ibanInquiry?.status) {
        provider = 2;
      }
      if (
        process.env.NODE_ENV !== "test" &&
        (ibanInquiry?.transactionState === "SUCCESS" ||
          ibanInquiry?.status === "DONE") &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شماره شبا`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...ibanInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          ibanInquiry.provider || "shahin",
          "استعلام شماره شبا",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      delete ibanInquiry.provider; // better to do this at  mspack.response_normlizer_sender

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(ibanInquiry) ? { ibanInquiry, provider } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام شماره شبا",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  cardInquiry: async (req: Request, res: Response, next: NextFunction) => {
    const startTime = performance.now();
    const { cardNumber } = req.body;
    try {
      const trackID = v4();
      const cardInquiry = await request.cardInquiry({
        cardNumber,
        sourceAccount: "0116100714000",
        bank: "BSI",
        nationalCode: "10320813170",
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        cardInquiry?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام اطلاعات کارت`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...cardInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "shahin",
          "استعلام اطلاعات کارت",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(cardInquiry) ? { cardInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام اطلاعات کارت",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
  phoneValidityInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { nationalID, mobile } = req.body;
    try {
      const trackID = v4();
      const phoneValidityInquiry = await request.phoneValidityInquiry({
        mobileNumber: mobile,
        nationalCode: nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        phoneValidityInquiry?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شاهکار`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...phoneValidityInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "shahin",
          "استعلام شاهکار",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(phoneValidityInquiry) ? { phoneValidityInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام شاهکار",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  accountInfoInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { nationalID, bank, sourceAccount } = req.body;
    try {
      const trackID = v4();
      const accountInfoInquiry = await request.accountInfoInquiry({
        bank,
        sourceAccount,
        nationalCode: nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        accountInfoInquiry?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام شماره حساب`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...accountInfoInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "shahin",
          "استعلام شماره حساب",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(accountInfoInquiry) ? { accountInfoInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام شماره حساب",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },

  sayyadChequeInquiry: async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const startTime = performance.now();
    const { nationalID, chequeSerial } = req.body;
    try {
      const trackID = v4();
      const sayyadChequeInquiry = await request.sayyadChequeInquiry({
        chequeSerial,
        nationalCode: nationalID,
        trackID,
        isSandBox: req.isSandBox!,
      });

      if (
        process.env.NODE_ENV !== "test" &&
        sayyadChequeInquiry?.transactionState === "SUCCESS" &&
        !req.isSandBox
      ) {
        const user =
          (await mspack.increase_APIkey_usage_count.default<IUserDoc>(
            User,
            req,
            mspack.nats_connection.default.client,
            "openBanking"
          )) as unknown as IUserDoc;
        const transaction = await Transaction.build({
          userId: user.id,
          amount: -req.serviceAmount!,
          paymentDesc: `کسر از اعتبار جهت استعلام چک سیاد`,
          paymentProvider: "none" as any,
          terminalNumber: "API usage",
          paymentToken: "API usage",
          paymentSessionID: "API usage",
          status: true,
          orderID: new Date().getTime(),
          traceCode: trackID,
          cardNumber: "API usage",
        });
        const endTime = performance.now();
        await transaction.save();
        await transaction.fireTransactionCompletedEvent();
        await user.fireIncameLogEvent(
          JSON.stringify(req.body),
          JSON.stringify({ ...sayyadChequeInquiry, trackID }),
          JSON.stringify(req.headers),
          200,
          "success",
          endTime - startTime,
          req.url,
          req.serviceAmount!,
          req.serviceBuyAmount!,
          "shahin",
          "استعلام چک سیاد",
          req.appLogo,
          req.headers["appname"] as unknown as string
        );
      }

      mspack.response_normlizer_sender(
        true,
        res,
        _.isObject(sayyadChequeInquiry) ? { sayyadChequeInquiry } : {},
        200,
        trackID
      );
    } catch (error) {
      const endTime = performance.now();
      await User.fireIncameLogEventStatic(
        req.APIkeyPayload!.userId,
        JSON.stringify(req.body),
        JSON.stringify({ ...error, message: error.message }),
        JSON.stringify(req.headers),
        error.status,
        "error",
        endTime - startTime,
        req.url,
        req.serviceAmount!,
        req.serviceBuyAmount!,
        "shahin",
        "استعلام چک سیاد",
        req.appLogo,
        req.headers["appname"] as unknown as string
      );
      next(error);
    }
  },
};
