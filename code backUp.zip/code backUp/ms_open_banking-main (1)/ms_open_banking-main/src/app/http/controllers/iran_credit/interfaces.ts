export interface IStartRequest {
  realPersonNationalCode: string;
  mobileNumber: string;
  legalPersonNationalCode?: string;
  multipart: boolean;
  trackID: string;
  isSandBox: boolean;
}

export interface IValidate {
  code: string;
  token: string;
  multipart: boolean;
  trackID: string;
  isSandBox: boolean;
}

export interface IReportJSON {
  token: string;
  multipart: boolean;
  trackID: string;
  isSandBox: boolean;
}

export interface IReportLink {
  token: string;
  multipart: boolean;
  trackID: string;
  isSandBox: boolean;
}

