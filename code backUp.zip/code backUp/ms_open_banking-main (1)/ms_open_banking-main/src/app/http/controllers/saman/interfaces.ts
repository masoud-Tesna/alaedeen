export interface IPayaPayment {
  amount: number;
  channel?: string;
  cif?: string;
  clientIp?: string;
  ibanNumber: string;
  description?: string;
  factorNumber: number;
  ownerName: string;
  sourceDepositNumber?: string;
  token?: string;
  trackerId?: string;
  transferDescription?: string;
  trackID: string;
  isSandBox: boolean;
}

export interface ISatnaPayment {
  amount: number;
  channel?: string;
  cif?: string;
  clientIp?: string;
  destinationIbanNumber: string;
  description?: string;
  factorNumber: number;
  receiverName: string;
  receiverFamily: string;
  receiverTelephoneNumber: string;
  sourceDepositNumber?: string;
  token?: string;
  trackerId?: string;
  trackID: string;
  isSandBox: boolean;
}

export interface INormalPayment {
  amount: number;
  channel?: string;
  cif?: string;
  clientIp?: string;
  destinationComment?: string;
  additionalDocumentDesc?: string;
  sourceComment: string;
  referenceNumber?: number;
  destinationDeposit: string;
  sourceDepositNumber?: string;
  token?: string;
  trackerId?: string;
  trackID: string;
  isSandBox: boolean;
}

export interface IPayaPaymentReport {
  channel?: string;
  cif?: string;
  offset: number;
  sourceDepositNumber?: string;
  length: number;
  trackID: string;
  isSandBox: boolean;
}

export interface ISatnaPaymentReport {
  channel?: string;
  cif?: string;
  clientIp?: string;
  order?: Order;
  description?: string;
  englishDescription?: string;
  depositNumber?: string;
  token?: string;
  fromDate?: Date;
  toDate?: Date;
  trackID: string;
  isSandBox: boolean;
}

enum Order {
  "ASC",
  "DESC",
}
