export interface PaymanObject {
  bank_code: number;
  user_id: string;
  permission_ids: number[];
  contract: {
    expiration_date: Date;
    max_daily_transaction_count: number;
    max_monthly_transaction_count: number;
    max_transaction_amount: number;
    start_date: Date;
  };
}

export interface IGetPeymanID {
  payman_code: string;
  trace_id: string;
}

export interface IStartPayBill {
  bill_id: string;
  pay_id: string;
  payman_id: string;
  trace_id: string;
  trackID: string;
}

export interface IStartPay {
  trace_id: string;
  trackID: string;
  payman_id: string;
  amount: number;
  description: string;
  client_transaction_date: Date;
}

export interface ITracePeymanID {
  trace_id: string;
}

export interface IDirectDebitCreate {
  payman: PaymanObject;
  redirect_url: string;
  trace_id: string;
  mobile: string;
  nationalID: string;
  trackID: string;
}
