import mongoose from "mongoose";
const getDate = () => new Date().toISOString();

export default new mongoose.Schema(
  {
    APIkey: {
      type: String,
      required: true,
    },
    refreshAPIkey: {
      type: String,
      required: true,
    },
    lifeTime: {
      type: Number,
      required: true,
    },
    level: {
      type: String,
      enum: ["startup", "sm_business", "md_business", "lg_business"],
      required: true,
    },
    scopes: {
      type: Array,
      required: true,
    },
    IP: {
      type: Array,
      required: true,
    },
    grantType: {
      type: String,
      enum: ["client_credentials", "authorization_code", "device_code"],
      required: true,
    },
    usageCount: {
      type: Number,
      default: 0,
    },
    appName: {
      type: String,
      required: true,
    },
    appLogo: {
      type: String,
      required: false,
    },
    isSandBox: {
      type: Boolean,
      default: false,
    },
    createdDate: {
      type: mongoose.SchemaTypes.Date,
      required: false,
    },
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at",
    },
    _id: false,
    toJSON: {
      transform(doc: any, ret: any) {
        delete ret.created_at;
        delete ret.updated_at;
      },
    },
  }
);
