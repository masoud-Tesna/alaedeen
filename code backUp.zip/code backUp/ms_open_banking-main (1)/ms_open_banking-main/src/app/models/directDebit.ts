import mongoose from "mongoose";
import * as interfaces from "../http/controllers/faraboom/direct_debit/interfaces";

export interface IDirectDebitDoc extends mongoose.Document {
  callbackURL: string;
  mobile: string;
  nationalID: string;
  covenant: interfaces.PaymanObject;
  traceNumber: string;
  sign: boolean;
  peymanID?: string;
  userId: string;
}

export interface IDirectDebitAttrs {
  callbackURL: string;
  mobile: string;
  nationalID: string;
  covenant: interfaces.PaymanObject;
  traceNumber: string;
  userId: string;
}

interface IDirectDebitModel extends mongoose.Model<IDirectDebitDoc> {
  build(attrs: IDirectDebitAttrs): IDirectDebitDoc;
}

const DirectDebitchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,IDirectDebitAttrs
    },

    callbackURL: {
      type: String,
      required: true,
    },
    mobile: {
      type: String,
      required: false,
    },
    nationalID: {
      type: String,
      required: true,
    },
    covenant: {
      bank_code: { type: String, required: true },
      user_id: { type: String, required: true },
      permission_ids: [{ type: Number, required: true }],
      contract: {
        expiration_date: { type: Date, required: true },
        max_daily_transaction_count: { type: Number, required: true },
        max_monthly_transaction_count: { type: Number, required: true },
        max_transaction_amount: { type: Number, required: true },
        start_date: { type: Date, required: true },
      },
    },
    traceNumber: { type: String, required: true },
    sign: { type: Boolean, default: false },
    peymanID: { type: String, required: false },
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at",
    },
    versionKey: "version",
    toJSON: {
      transform(doc: any, ret: any) {
        delete ret.created_at;
        delete ret.updated_at;
        delete ret.version;
      },
    },
  }
);

DirectDebitchema.statics.build = (
  attrs: IDirectDebitAttrs
): IDirectDebitDoc => {
  const directDebit = new DirectDebit(attrs);
  return directDebit;
};

const DirectDebit = mongoose.model<IDirectDebitDoc, IDirectDebitModel>(
  "directDebit",
  DirectDebitchema
);
export default DirectDebit;
