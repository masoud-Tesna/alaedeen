import mongoose, { Date } from "mongoose";
import { updateIfCurrentPlugin } from "mongoose-update-if-current";
import mspack from "mspack";
import APIkeySchema from "./APIkey";
import Transaction from "./transaction";
import incommingLogEventPublisher from "../events/publishers/log/incomming_log";

declare const global: NodeJS.Global;

enum Activity {
  "blockChain",
  "GOV",
  "cityService",
  "AI",
  "openBanking",
  "IOT",
  "tourism",
  "bourse ",
  "other",
}

enum Scope {
  "GOV",
  "smartCity",
  "openBanking",
  "blockChain",
  "tourism",
  "wallet",
  "bourse",
}

enum GrantType {
  "client_credentials",
  "authorization_code",
  "device_code",
}

enum Level {
  "startup",
  "sm_business",
  "md_business",
  "lg_business",
}

enum Role {
  "developer",
  "organization",
  "operator",
  "admin",
}

enum PaymentProvider {
  "pardakht_novin",
  "fan_ava",
  "saman_kish",
  "zarin_pal",
  "none",
}

interface IUserAttrs {
  _id: mongoose.Types.ObjectId;
  email: string;
  emailVerifiedAt?: Date;
  password: string;
  username: string;
  mobile: string;
  firstName: string;
  lastName: string;
  country: string;
  timezone: string;
  organizationName?: string;
  activity?: Activity;
  lastLogin?: Date;
  isBanned?: boolean;
  role?: Role;
}

interface IUserUpdateAttrs {
  new_password?: string;
  current_password?: string;
  mobile: string;
  firstName: string;
  lastName: string;
  country: string;
  timezone: string;
  organizationName?: string;
  activity: Activity;
}

interface IAPIkeyAttrs {
  APIkey: string;
  refreshAPIkey: string;
  level: Level;
  scopes: string[];
  grantType: GrantType;
  IP: string[];
  appName: string;
  appLogo?: string;
  lifeTime: number;
  isSandBox: boolean;
  createdDate: string;
}

interface IAPIkeyEditAttrs {
  level: Level;
  scopes: string[];
  IP: string[];
  appName: string;
  appLogo?: string;
}

interface IRefreshAPIkeyAttrs {
  refreshAPIkey: string;
  newAPIkey: string;
  appName: string;
}

interface IUserModel extends mongoose.Model<IUserDoc> {
  build(attrs: IUserAttrs): Promise<IUserDoc>;
  fireIncameLogEventStatic(
    id: string,
    input: string,
    output: string,
    headers: string,
    status: number,
    type: any,
    responseTime: number,
    route: string,
    salePrice: number,
    buyPrice: number,
    provider: string,
    name: string,
    appLogo?: string,
    appName?: string
  ): Promise<any>;
  
}

interface IAPIkeyDoc {
  APIkey: string;
  refreshAPIkey: string;
  level: Level;
  scopes: string[];
  grantType: GrantType;
  usageCount?: number;
  IP: string[];
  appName: string;
  appLogo?: string;
  isSandBox: boolean;
  createdDate: string;
}

interface ITransactionAttrs {
  amount: number;
  paymentToken: string;
  traceCode: string;
  status: boolean;
  cardNumber: string;
  paymentSessionID: string;
  orderID: number;
  paymentDesc: string;
  terminalNumber: string;
  paymentProvider: PaymentProvider;
  transactionDate?: string;
}

export interface ITransactionDoc {
  amount: number;
  paymentToken: string;
  paymentSessionID: string;
  status: boolean;
  orderID: number;
  paymentDesc: string;
  terminalNumber: string;
  traceCode?: string;
  cardNumber?: string;
  paymentProvider: PaymentProvider;
  transactionDate: string;
}

export interface IUserDoc extends mongoose.Document {
  email: string;
  username: string;
  emailVerifiedAt: string | null;
  password: string;
  mobile: string;
  firstName: string;
  lastName: string;
  country: string;
  timezone: string;
  organizationName?: string;
  activity: Activity;
  lastLogin: string | null;
  isBanned: boolean;
  role: Role;
  version: number;
  OAuthAPIkey?: IAPIkeyDoc[];
  transaction?: ITransactionDoc[];
  banUser(banned: boolean): IUserDoc;
  fireIncameLogEvent(
    input: string,
    output: string,
    headers: string,
    status: number,
    type: any,
    responseTime: number,
    route: string,
    salePrice: number,
    buyPrice: number,
    provider: string,
    name: string,
    appLogo?: string,
    appName?: string
  ): Promise<any>;
  getBalance(): Promise<number>;
  setRole(role: any): IUserDoc;
  APIkey(attrs: IAPIkeyAttrs): IUserDoc;
  refreshAPIkey(attrs: IRefreshAPIkeyAttrs): IUserDoc;
  editAPIkey(attrs: IAPIkeyEditAttrs): IUserDoc;
}

const userSchema = new mongoose.Schema(
  {
    _id: {
      type: mongoose.Types.ObjectId,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    emailVerifiedAt: {
      type: mongoose.SchemaTypes.Date,
      required: false,
      default: null,
    },
    username: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    mobile: {
      type: String,
      required: true,
      unique: true,
    },
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    country: {
      type: String,
      required: true,
    },
    timezone: {
      type: String,
      required: true,
    },
    organizationName: {
      type: String,
      required: false,
    },
    activity: {
      type: String,
      required: false,
      enum: [
        "blockChain",
        "GOV",
        "cityService",
        "AI",
        "openBanking",
        "IOT",
        "tourism",
        "bourse ",
        "other",
      ],
      default: "other",
    },

    lastLogin: {
      type: mongoose.SchemaTypes.Date,
      required: false,
      default: null,
    },
    isBanned: {
      type: mongoose.SchemaTypes.Boolean,
      required: false,
      default: false,
    },
    role: {
      type: String,
      required: false,
      enum: ["developer", "organization", "operator", "admin"],
      default: "developer",
    },
    OAuthAPIkey: {
      type: [APIkeySchema],
      required: false,
    },
    transaction: {
      type: [],
      required: false,
    },
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at",
    },
    versionKey: "version",
    _id: false,
    toJSON: {
      transform(doc: any, ret: any) {
        delete ret.password;
        ret.id = ret._id;
        delete ret._id;
        delete ret.version;
        delete ret.OAuthAPIkey;
        delete ret.transaction;
      },
    },
  }
);

userSchema.plugin(updateIfCurrentPlugin);

// userSchema.methods.completeTranscation = async function (
//   attrs: ITransactionAttrs
// ): Promise<IUserDoc | undefined> {
//   try {
//     if (!attrs.transactionDate) {
//       attrs.transactionDate = new Date().toISOString();
//     }

//     const user = this as IUserDoc;
//     let session = await global.mongoClient!.startSession();
//     await session.startTransaction();

//     if (user.isBanned) {
//       throw new mspack.custom_error("User has been banned!", 400);
//     }
//     //@ts-ignore
//     user.transaction = [...(user.transaction ? user.transaction : []), attrs];
//     user.balance += attrs.amount;
//     await session.commitTransaction();
//     session.endSession();
//     return user;
//   } catch (error) {
//     throw error;
//   }
// };

userSchema.methods.APIkey = function (
  attrs: IAPIkeyAttrs
): IUserDoc | undefined {
  try {
    const user = this as IUserDoc;

    if (!user.OAuthAPIkey) {
      user.OAuthAPIkey = [];
    }

    user.OAuthAPIkey.push(attrs);
    return user;
  } catch (error) {
    throw error;
  }
};

userSchema.methods.banUser = function (banned: boolean): IUserDoc | undefined {
  try {
    const user = this as IUserDoc;
    if (user.role === ("admin" as unknown as Role)) {
      throw new mspack.custom_error("Requested user to banning is admin!", 400);
    }

    user.isBanned = banned;
    return user;
  } catch (error) {
    throw error;
  }
};

userSchema.methods.setRole = function (role: any): IUserDoc | undefined {
  try {
    const user = this as IUserDoc;
    if (user.isBanned) {
      throw new mspack.custom_error(
        "Requested user to changing role has been banned!",
        400
      );
    }

    if (user.role === ("admin" as unknown as Role)) {
      throw new mspack.custom_error(
        "Requested user to changing role is admin!",
        400
      );
    }
    user.role = role;
    return user;
  } catch (error) {
    throw error;
  }
};

userSchema.methods.refreshAPIkey = function (
  attrs: IRefreshAPIkeyAttrs
): IUserDoc | undefined {
  try {
    const user = this as IUserDoc;
    if (user.isBanned) {
      throw new mspack.custom_error("This account has been banned!", 403);
    }

    const OAuthAPIkey = [...user.OAuthAPIkey!];
    for (let i of OAuthAPIkey) {
      if (
        i.appName === attrs.appName &&
        i.refreshAPIkey === attrs.refreshAPIkey &&
        !mspack.jwt_helper.default.checkToken(i.APIkey, "").isSafe
      ) {
        i.APIkey = attrs.newAPIkey;
      }
    }

    user.OAuthAPIkey = OAuthAPIkey;
    return user;
  } catch (error) {
    throw error;
  }
};

// userSchema.methods.fireTransactionCompletedEvent =
//   async function (): Promise<any> {
//     try {
//       const user = this as IUserDoc;
//       const event = await transactionEventPublisher({
//         id: user.id,
//         email: user.email,
//         transaction: user.transaction!,
//         balance: user.balance,
//         serviceName: "open_banking",
//       });
//       return event;
//     } catch (error) {
//       throw new mspack.custom_error("Error publishing event!", 400);
//     }
//   };

userSchema.methods.getBalance = async function (): Promise<number> {
  try {
    const user = this as IUserDoc;

    const transactions = await Transaction.aggregate([
      {
        $match: {
          $and: [
            { userId: mongoose.Types.ObjectId(user.id) },
            { status: true },
          ],
        },
      },

      {
        $group: {
          _id: "$userId",
          balance: { $sum: "$amount" },
        },
      },
    ]);

    return transactions.length !== 0 ? (transactions[0].balance as number) : 0;
  } catch (error) {
    throw error;
  }
};

userSchema.methods.fireIncameLogEvent = async function (
  input: string,
  output: string,
  headers: string,
  status: number,
  type: any,
  responseTime: number,
  route: string,
  salePrice: number,
  buyPrice: number,
  provider: string,
  name: string,
  appLogo?: string,
  appName?: string
): Promise<any> {
  try {
    const user = this as IUserDoc;

    const event = await incommingLogEventPublisher({
      userID: user.id,
      name,
      input,
      output,
      headers,
      status,
      type,
      responseTime,
      route,
      appName,
      salePrice,
      buyPrice,
      provider,
      appLogo,
    });
    return event;
  } catch (error) {
    throw new mspack.custom_error("Error publishing event!", 400);
  }
};

userSchema.statics.build = async (
  attrs: IUserAttrs
): Promise<IUserDoc | undefined> => {
  try {
    const user = new User(attrs);
    return user;
  } catch (error) {
    throw error;
  }
};

userSchema.statics.fireIncameLogEventStatic = async function (
  id: string,
  input: string,
  output: string,
  headers: string,
  status: number,
  type: any,
  responseTime: number,
  route: string,
  salePrice: number,
  buyPrice: number,
  provider: string,
  name: string,
  appLogo?: string,
  appName?: string
): Promise<any> {
  try {
    const event = await incommingLogEventPublisher({
      userID: id,
      name,
      input,
      output,
      headers,
      status,
      type,
      responseTime,
      route,
      appName,
      salePrice,
      buyPrice,
      provider,
      appLogo,
    });
    return event;
  } catch (error) {
    throw new mspack.custom_error("Error publishing event!", 400);
  }
};

const User = mongoose.model<IUserDoc, IUserModel>("User", userSchema);
export default User;
