import mongoose, { Date } from "mongoose";
import { updateIfCurrentPlugin } from "mongoose-update-if-current";
import transactionEventPublisher from "../events/publishers/user/transaction";
import mspack from "mspack";
declare const global: NodeJS.Global;
enum PaymentProvider {
  "pardakht_novin",
  "fan_ava",
  "saman_kish",
  "zarin_pal",
  "none",
}
export interface ITransactionDoc extends mongoose.Document {
  amount: number;
  userId: string;
  paymentToken: string;
  paymentSessionID: string;
  status: boolean;
  orderID: number;
  paymentDesc: string;
  terminalNumber: string;
  traceCode?: string;
  cardNumber?: string;
  paymentProvider: PaymentProvider;
  transactionDate: string;
  isWithdraw: boolean;
  fireTransactionCompletedEvent(): Promise<any>;
  completeTransaction(
    orderID: number,
    traceCode: string,
    cardNumber: string
  ): Promise<ITransactionDoc>;
}

export interface ITransactionAttrs {
  amount: number;
  userId: string;
  paymentToken: string;
  status: boolean;
  paymentSessionID: string;
  orderID: number;
  paymentDesc: string;
  traceCode?: string;
  cardNumber?: string;
  terminalNumber: string;
  paymentProvider: PaymentProvider;
  transactionDate?: string;
  isWithdraw?: boolean;
}

interface ITransactionModel extends mongoose.Model<ITransactionDoc> {
  build(attrs: ITransactionAttrs): ITransactionDoc;
}

const transactionSchema = new mongoose.Schema(
  {
    amount: {
      type: Number,
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    paymentToken: {
      type: String,
      required: true,
    },
    paymentSessionID: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      default: false,
    },

    orderID: {
      type: Number,
      required: true,
    },
    traceCode: {
      type: String,
      required: false,
    },
    terminalNumber: {
      type: String,
      required: true,
    },
    cardNumber: {
      type: String,
      required: false,
    },
    paymentProvider: {
      type: String,
      enum: ["pardakht_novin", "fan_ava", "saman_kish", "zarin_pal", "none"],
      required: true,
    },
    paymentDesc: {
      type: String,
      required: true,
    },
    isWithdraw: {
      type: Boolean,
      required: true,
    },
    transactionDate: {
      type: mongoose.SchemaTypes.Date,
      required: false,
    },
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at",
    },
    versionKey: "version",
    toJSON: {
      transform(doc: any, ret: any) {
        // delete ret.created_at;
        // delete ret.updated_at;
      },
    },
  }
);
transactionSchema.plugin(updateIfCurrentPlugin);
transactionSchema.statics.build = (
  attrs: ITransactionAttrs
): ITransactionDoc | undefined => {
  try {
    if (attrs.amount < 0) {
      attrs.isWithdraw = true;
    } else {
      attrs.isWithdraw = false;
    }

    const transaction = new Transaction(attrs);

    return transaction;
  } catch (error) {
    throw error;
  }
};

transactionSchema.methods.completeTransaction = async function (
  orderID: number,
  traceCode: string,
  cardNumber: string
): Promise<any> {
  try {
    const transaction = this as ITransactionDoc;

    let session = await global.mongoClient!.startSession();
    await session.startTransaction();

    transaction!.status = true;
    transaction!.traceCode = traceCode;
    transaction!.cardNumber = cardNumber;

    await session.commitTransaction();
    session.endSession();
    return transaction!;
  } catch (error) {
    throw error;
  }
};

transactionSchema.methods.fireTransactionCompletedEvent =
  async function (): Promise<any> {
    try {
      const transaction = this as ITransactionDoc;

      const event = await transactionEventPublisher({
        transaction,
        serviceName: "open_banking",
      });
      return event;
    } catch (error) {
      throw new mspack.custom_error("Error publishing event!", 400);
    }
  };

const Transaction = mongoose.model<ITransactionDoc, ITransactionModel>(
  "Transaction",
  transactionSchema
);
export default Transaction;
