import mongoose, { Date } from "mongoose";

export interface IICSDoc extends mongoose.Document {
  realPersonNationalCode: string;
  legalPersonNationalCode?: string;
  token: string;
  result?: any;
}

export interface IICSAttrs {
  realPersonNationalCode: string;
  legalPersonNationalCode?: string;
  token: string;
}

interface IICSModel extends mongoose.Model<IICSDoc> {
  build(attrs: IICSAttrs): IICSDoc;
}

const IICSSchema = new mongoose.Schema(
  {
    realPersonNationalCode: {
      type: String,
      required: true,
    },
    legalPersonNationalCode: {
      type: String,
      required: false,
    },
    token: {
      type: String,
      required: true,
    },
    result: {
      type: mongoose.Schema.Types.Mixed,
      required: false,
    },
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at",
    },
    versionKey: "version",
    toJSON: {
      transform(doc: any, ret: any) {
        // delete ret.created_at;
        // delete ret.updated_at;
      },
    },
  }
);

IICSSchema.statics.build = (attrs: IICSAttrs): IICSDoc | undefined => {
  try {
    const isc = new ICSToken(attrs);
    return isc;
  } catch (error) {
    throw error;
  }
};

const ICSToken = mongoose.model<IICSDoc, IICSModel>("icstoken", IICSSchema);
export default ICSToken;
