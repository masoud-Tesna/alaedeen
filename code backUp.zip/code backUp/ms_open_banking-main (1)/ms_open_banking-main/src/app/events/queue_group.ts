export default "openBanking_srv_queue_group";
