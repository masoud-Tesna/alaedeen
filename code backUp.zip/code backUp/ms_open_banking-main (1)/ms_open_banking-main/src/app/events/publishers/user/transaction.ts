import mspack, { IUserTransactionCompletedEvent } from "mspack";

export default function (data: IUserTransactionCompletedEvent): Promise<any> {
  return new Promise((resolve, reject) => {
    mspack.nats_connection.default.client.publish(
      mspack.channels.UserTransactionCompleted,
      JSON.stringify(data),
      (err, aGuid) => {
        if (err) reject(err);
        else resolve(aGuid);
      }
    );
  });
}
