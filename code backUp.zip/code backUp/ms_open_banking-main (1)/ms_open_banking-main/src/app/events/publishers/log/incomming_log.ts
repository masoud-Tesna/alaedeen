import mspack, { ILogIncameEvent } from "mspack";

export default function (data: ILogIncameEvent): Promise<any> {
  return new Promise((resolve, reject) => {
    mspack.nats_connection.default.client.publish(
      mspack.channels.LogIncame,
      JSON.stringify(data),
      (err, aGuid) => {
        if (err) reject(err);
        else resolve(aGuid);
      }
    );
  });
}
