import mongoose from "mongoose";
import mspack, { IUserVerfiyedEmailEvent } from "mspack";
import queue_group from "../../queue_group";
import User from "../../../models/user";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.UserVerfiyedEmail,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(
          msg.getData().toString()
        ) as IUserVerfiyedEmailEvent;
        mspack.log(
          `${
            mspack.channels.UserVerfiyedEmail
          } channel recived : ${msg.getData()}`
        );

        await User.updateOne(
          { _id: data.id },
          { emailVerifiedAt: data.emailVerifiedAt! }
        );

        msg.ack();
      } catch (error) {
        console.log(error.message);
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
