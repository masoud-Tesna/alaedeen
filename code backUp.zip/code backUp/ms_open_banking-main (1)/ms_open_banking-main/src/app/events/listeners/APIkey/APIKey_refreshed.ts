import mspack, { IRefreshAPIkeyEvent } from "mspack";
import User from "../../../models/user";
import queue_group from "../../queue_group";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.APIkeyRefreshed,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(
          msg.getData().toString()
        ) as IRefreshAPIkeyEvent;
        const users = await User.find() ;
        console.log("xxxxxx=>" ,data )
        mspack.log(
          `${
            mspack.channels.APIkeyRefreshed
          } channel recived : ${msg.getData()}`
        );
      
        const user = await User.findById(data.id);
        user!.OAuthAPIkey = data.OAuthAPIkey;
        await user!.save();
        msg.ack();
      } catch (error) {
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
