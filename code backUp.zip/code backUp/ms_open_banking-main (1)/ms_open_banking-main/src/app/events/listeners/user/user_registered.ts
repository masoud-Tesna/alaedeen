import mongoose from "mongoose";
import mspack, { IUserCreatedEvent } from "mspack";
import queue_group from "../../queue_group";
import User from "../../../models/user";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.UserRegistered,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(msg.getData().toString()) as IUserCreatedEvent;
        mspack.log(
          `${mspack.channels.UserRegistered} channel recived : ${msg.getData()}`
        );

        const user = await User.build({
          _id: new mongoose.Types.ObjectId(data.id),
          email: data.email,
          password: data.password,
          username: data.username,
          mobile: data.mobile,
          firstName: data.firstName,
          lastName: data.lastName,
          country: data.country,
          timezone: data.timezone,
          organizationName: data.organizationName,
          activity: data.activity,
          isBanned: data.isBanned,
          role: data.role,
        });

        await user.save();
        msg.ack();
      } catch (error) {
        console.log(error.message);
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
