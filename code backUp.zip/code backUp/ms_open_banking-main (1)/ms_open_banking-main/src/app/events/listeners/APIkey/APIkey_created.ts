import mspack, { ICreateAPIkeyEvent } from "mspack";
import User from "../../../models/user";
import queue_group from "../../queue_group";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.APIkeyCreated,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(msg.getData().toString()) as ICreateAPIkeyEvent;
        mspack.log(
          `${mspack.channels.APIkeyCreated} channel recived : ${msg.getData()}`
        );
        const user = await User.findById(data.id);
        user!.OAuthAPIkey = data.OAuthAPIkey;
        await user!.save();
        msg.ack();
      } catch (error) {
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
