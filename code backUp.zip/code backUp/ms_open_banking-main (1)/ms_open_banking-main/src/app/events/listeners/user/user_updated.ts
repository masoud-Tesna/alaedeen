import mongoose from "mongoose";
import mspack, { IUserUpdatedEvent } from "mspack";
import queue_group from "../../queue_group";
import User from "../../../models/user";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.UserUpdated,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(msg.getData().toString()) as IUserUpdatedEvent;
        mspack.log(
          `${mspack.channels.UserUpdated} channel recived : ${msg.getData()}`
        );

        const user = await User.findById(data.id);
        if (user!.version + 1 === data.version) {
          user!.password = data.password;
          user!.mobile = data.mobile;
          user!.firstName = data.firstName;
          user!.lastName = data.lastName;
          user!.role = data.role;
          user!.activity = data.activity;
          user!.country = data.country;
          user!.timezone = data.timezone;
          if (data.organizationName) {
            user!.organizationName = data.organizationName;
          }
          await user!.save();
        }

        msg.ack();
      } catch (error) {
        console.log(error.message);
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
