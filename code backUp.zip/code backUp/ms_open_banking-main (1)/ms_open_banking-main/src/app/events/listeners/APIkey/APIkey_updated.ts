import mspack, { IUpdateAPIkeyEvent } from "mspack";
import User from "../../../models/user";
import queue_group from "../../queue_group";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.APIkeyUpdated,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(msg.getData().toString()) as IUpdateAPIkeyEvent;
        mspack.log(
          `${mspack.channels.APIkeyUpdated} channel recived : ${msg.getData()}`
        );
        if (data.serviceName === "openBanking") {
          return msg.ack();
        }
        const user = await User.findById(data.id);
        user!.OAuthAPIkey = data.OAuthAPIkey;
        await user!.save();
        msg.ack();
      } catch (error) {
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
