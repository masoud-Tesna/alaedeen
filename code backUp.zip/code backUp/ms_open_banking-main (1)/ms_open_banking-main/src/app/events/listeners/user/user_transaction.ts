import mspack, { IUserTransactionCompletedEvent } from "mspack";
import Transaction from "../../../models/transaction";
import queue_group from "../../queue_group";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.UserTransactionCompleted,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(
          msg.getData().toString()
        ) as IUserTransactionCompletedEvent;
        mspack.log(
          `${
            mspack.channels.UserTransactionCompleted
          } channel recived : ${msg.getData()}`
        );

        if (data.serviceName === "open_banking") {
          return msg.ack();
        }
        const transaction = Transaction.build(data.transaction);
        await transaction.save();
        // const user = await User.findById(data.id);
        // user!.transaction = data.transaction;
        // user!.balance = data.balance;
        // await user!.save();
        msg.ack();
      } catch (error) {
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
