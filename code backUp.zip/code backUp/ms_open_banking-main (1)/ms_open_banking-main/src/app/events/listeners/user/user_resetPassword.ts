import mspack, { IUserResetPass } from "mspack";
import queue_group from "../../queue_group";
import User from "../../../models/user";

export default function (): any {
  mspack.nats_connection.default.listener(
    mspack.channels.UserResetPassword,
    queue_group,
    async (msg) => {
      try {
        const data = JSON.parse(msg.getData().toString()) as IUserResetPass;
        mspack.log(
          `${
            mspack.channels.UserResetPassword
          } channel recived : ${msg.getData()}`
        );

        const user = await User.findById(data.id);
        //if (user!.version + 1 === data.version) {
        user!.password = data.password;
        await user!.save();
        //}

        msg.ack();
      } catch (error) {
        console.log(error.message);
        throw new mspack.custom_error(error.message, 400);
      }
    }
  );
}
