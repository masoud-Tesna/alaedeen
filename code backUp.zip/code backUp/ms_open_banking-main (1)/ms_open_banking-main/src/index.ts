import app from "./app";
import db_connection from "./util/database";
import mspack from "mspack";
import listeners from "./listeners";

const start = async () => {
  if (
    !process.env.JWT_REFRESH_SECRET ||
    !process.env.JWT_SECRET ||
    !process.env.PORT ||
    !process.env.APIKEY_JWT_SECRET ||
    !process.env.APIKEY_JWT_REFRESH_SECRET ||
    !process.env.REDIS_CONNECTION_STRING
  ) {
    throw new Error("env varibales must be provided");
  }
  try {
    await db_connection();

    mspack.redis.default.start();
    mspack.nats_connection.default.start(() => {
      app.listen(process.env.PORT, async () => {
        try {
          listeners();
          mspack.log(`server listen on port ${process.env.PORT}`);
        } catch (e) {
          mspack.log(e);
        }
      });
    });
  } catch (error) {
    throw error;
  }
};

(async () => {
  await start();
})();
