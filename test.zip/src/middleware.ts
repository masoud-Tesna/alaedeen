import { withAuth } from 'next-auth/middleware';

export default withAuth(
  async function middleware(req) {},
  {
    callbacks: {
      authorized: ({ req, token }) => {
        if ((req.nextUrl.pathname.startsWith('/dashboard') || req.nextUrl.pathname.startsWith('/auth/createApp')) && token === null) {
          return false;
        }
        return true;
      }
    }
  }
);
