export type AuthSkeletonProps = {
  justInputs?: boolean
}