'use client';

import { Skeleton } from 'antd';
import { FC } from 'react';
import { AuthSkeletonProps } from '@/templates/components/types/authSkeletonProps';

export const AuthSkeleton: FC<AuthSkeletonProps> = ({ justInputs = false }) => {
  return (
    <>
      { !justInputs &&
        <>
          <div>
            <Skeleton.Input
              active
              rootClassName='!w-[25%]'
              className='!w-full !min-w-[auto] !h-[25px]'
            />
          </div>
          
          <div className='mt-2'>
            <Skeleton.Input
              active
              rootClassName='!w-[50%]'
              className='!w-full !min-w-[auto] !h-[20px]'
            />
          </div>
        </>
      }
      
      <div className='mt-[24px] space-y-[38px]'>
        <div>
          <Skeleton.Input
            active
            block
            className='!h-[42px]'
          />
        </div>
        
        <div>
          <Skeleton.Input
            active
            block
            className='!h-[42px]'
          />
        </div>
        
        <div>
          <Skeleton.Input
            active
            block
            className='!h-[42px] mt-[20px]'
          />
        </div>
      </div>
      
      { !justInputs &&
        <>
          <div className='mt-6'>
            <Skeleton.Input
              active
              rootClassName='!w-[40%]'
              className='!w-full !min-w-[auto] !h-[23px]'
            />
          </div>
          
          <div className='mt-2'>
            <Skeleton.Input
              active
              rootClassName='!w-[30%]'
              className='!w-full !min-w-[auto] !h-[23px]'
            />
          </div>
        </>
      }
    </>
  );
};