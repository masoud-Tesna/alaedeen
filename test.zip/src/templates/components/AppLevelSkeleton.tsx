'use client';

import { Skeleton } from '@/templates/UI';

export const AppLevelSkeleton = () => <Skeleton count={ { row: 1, col: 5 } } height={ 370 } />;