import { Form, Form as AntdForm, FormItemProps } from 'antd';
import { HTMLAttributes } from 'react';
import FloatingLabel from './FloatingLabel';
import classNames from 'classnames';

export interface IFormItem extends FormItemProps {
  requiredTitle?: boolean,
  requiredMessage?: string,
  requiredJustInSubmit?: boolean,
  noLabel?: boolean,
  inputmode?: HTMLAttributes<HTMLLIElement>['inputMode'],
  maxLength?: number | string | any,
  minLength?: number | string | any,
  max?: number | string | any,
  placeholder?: string,
  floatingLabel?: boolean,
  floatingLabelBg?: string,
}

const FormItem = (props: IFormItem) => {
  const formRef = AntdForm.useFormInstance();
  
  const {
    requiredTitle,
    requiredMessage,
    requiredJustInSubmit = false,
    noLabel = false,
    required,
    labelAlign = 'start',
    maxLength,
    minLength,
    max,
    extra,
    floatingLabel = true,
    floatingLabelBg = '#FFFFFF',
    className,
    validateFirst = true,
    ...rest
  } = props;
  
  const inputWatch = AntdForm.useWatch(rest?.name, formRef);
  
  if (floatingLabel) {
    return (
      <FloatingLabel
        value={ inputWatch }
        label={ rest?.label }
        placeholder={ rest?.placeholder || rest?.label }
        floatingLabelBg={ floatingLabelBg }
        htmlFor={ rest?.htmlFor }
      >
        <Form.Item
          extra={ extra }
          { ...rest }
          className={ classNames(
            className,
            '[&>.ant-row>.ant-col>div+div>.ant-form-item-explain]:text-captionMd --floatingLabelFormItem'
          ) }
          label={ null }
        >
          { rest.children }
        </Form.Item>
      </FloatingLabel>
    );
  }
  
  return (
    <Form.Item
      extra={ extra }
      { ...rest }
      className={ classNames(className, '[&>.ant-row>.ant-col>div+div>.ant-form-item-explain]:text-captionMd') }
      label={ rest.label }
    >
      { rest.children }
    </Form.Item>
  );
};

export { FormItem };