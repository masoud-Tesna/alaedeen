'use client';

import { Upload as AntdUpload } from 'antd';
import Image from 'next/image';
import { Children, FC, useState } from 'react';
import { UploadChangeParam, UploadFile, UploadProps } from 'antd/es/upload';
import { getBase64 } from '@/utils/helpers';
import { LoadingOutlined } from '@ant-design/icons';
import classNames from 'classnames';
import { TUpload } from '@/templates/UI/types';
import uploadOutlined from '/public/icons/uploadOutlined.svg';

export const Upload: FC<TUpload> = ({ onChange, className, imageProps, handleSaveImageUrl, children, ...rest }) => {
  
  const [ loading, setLoading ] = useState(false);
  
  const [ imageUrl, setImageUrl ] = useState<string>();
  
  const handleChange: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
    if (info?.file?.status === 'uploading') {
      setLoading(true);
      return;
    }
    
    if (info?.file?.status === 'done') {
      getBase64(info?.file?.originFileObj, url => {
        setLoading(false);
        setImageUrl(url);
      });
      
      if (info?.file?.response?.data?.data?.filePath) {
        handleSaveImageUrl(info?.file?.response?.data?.data?.filePath);
      }
    }
  };
  
  const uploadButton = (
    <div className="border-dashed border-neutral-gray-4 w-full h-full flex justify-center items-center flex-col gap-y-2 p-2">
      <div>
        { rest.uploadButtonTitle }
      </div>
      
      <div>
        { loading ? <LoadingOutlined /> : <Image priority src={ uploadOutlined } alt="" /> }
      </div>
    </div>
  );
  
  return (
    <AntdUpload
      onChange={ handleChange }
      className={ classNames(className, '--avatar-uploader', { '[&>div>span]:p-[11px]': !imageUrl }) }
      { ...rest }
    >
      { Children.count(children) ?
        children :
        imageUrl ?
          <Image
            src={ imageUrl }
            { ...imageProps }
            alt={ imageProps?.alt || '' }
          /> :
          uploadButton
      }
    </AntdUpload>
  );
};