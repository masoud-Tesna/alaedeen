import React, { ReactNode, useState } from 'react';
import { FormItemProps } from 'antd';

import classNames from 'classnames';

type FloatInputTypes = {
  children?: ReactNode;
  value?: any;
  required?: boolean;
  placeholder?: Pick<FormItemProps, 'label'> | any;
  onChange?: Function | unknown,
  floatingLabelBg?: string,
  htmlFor?: string
};

const FloatingLabel = ({
  label,
  value,
  placeholder,
  floatingLabelBg,
  htmlFor,
  children
}: FloatInputTypes & Pick<FormItemProps, 'label'>) => {
  const [ focus, setFocus ] = useState(false);
  
  // const [ htmlFor, setHtmlFor ] = useState('');
  
  if (!placeholder) placeholder = label;
  
  const isOccupied = focus || (value && value.length !== 0);
  
  const labelClass = 'absolute pointer-events-none right-[12px] top-[25%] translate-y-[-50%] transition-all duration-[.2s] ease-in z-10 !text-buttonSm text-primary-shade-8';
  
  const isOccupiedClass = '!text-captionMd !text-primary-0 !top-0 px-[5px]';
  
  return (
    <div
      className="!relative mt-[8px] mb-[-40px]"
      onBlur={ () => setFocus(false) }
      onFocus={ () => setFocus(true) }
      /*ref={ (node) => {
        const findId = node?.getElementsByTagName('input')[ 0 ].id as string;
        setHtmlFor(findId);
      } }*/
    >
      { children }
      
      <label
        htmlFor={ htmlFor }
        className={ classNames(labelClass, { [ isOccupiedClass ]: !!isOccupied }) }
        style={ { background: floatingLabelBg } }
      >
        { isOccupied ? label : placeholder }
      </label>
    </div>
  );
};

export default FloatingLabel;
