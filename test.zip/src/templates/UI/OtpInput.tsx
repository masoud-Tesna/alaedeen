'use client';

import { ConfigProvider } from 'antd';
import ReactOtpInput, { AllowedInputTypes } from 'react-otp-input';
import styled from 'styled-components';
import { FormItem, IFormItem } from '@/templates/UI/FormItem';
import { FC } from 'react';

type TOtpInput = {
  numInputs?: number,
  separator?: string,
  inputType?: AllowedInputTypes,
  formItemProps?: IFormItem,
  onChange: (otp: string) => void
}

const Container = styled.div`
  .otpInput {
    background: #FFFFFF;
    border: 1px solid ${ props => props?.theme?.inputBorderColor } !important;
    border-radius: 5px;
    width: 100% !important;
    height: 40px;
    margin: 0;
    padding: 0;
  }
`;

export const OtpInput: FC<TOtpInput> = ({
  numInputs = 6, separator = '', inputType = 'tel', formItemProps, ...rest
}) => {
  const onChange = (otp: string) => {
    rest.onChange(otp);
  };
  return (
    <ConfigProvider>
      <FormItem { ...formItemProps } className='--otpInput'>
        <ReactOtpInput
          renderInput={ props => <input { ...props } autoComplete='new-password' /> }
          numInputs={ numInputs }
          renderSeparator={ separator }
          inputStyle='bg-white border border-primary-shade-9 rounded-[5px] !w-full h-[42px] --input'
          shouldAutoFocus
          inputType={ inputType }
          containerStyle='d-ltr gap-x-[8px]'
          onChange={ onChange }
        />
      </FormItem>
    </ConfigProvider>
  );
};
