import { UploadProps } from 'antd/es/upload';
import { ReactNode } from 'react';
import { ImageProps } from 'next/image';

export type TUpload = UploadProps & {
  uploadButtonTitle: string | ReactNode
  imageProps?: Omit<ImageProps, 'src'>,
  handleSaveImageUrl: (imageUrl: string) => void
}