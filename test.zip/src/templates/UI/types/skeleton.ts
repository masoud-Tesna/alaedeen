export type TSkeleton = {
  count?: {
    row: number,
    col: number
  },
  gutter?: [ number, number ],
  wrapperHeight?: string | number,
  width?: string | number,
  height?: string | number,
  radius?: string | number,
  align?: 'start' | 'center' | 'end',
}