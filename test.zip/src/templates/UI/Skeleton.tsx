'use client';

import { FC } from 'react';
import styled from 'styled-components';
import { Col, Row, Skeleton as AntdSkeleton } from 'antd';
import { isNumber } from '@/utils/helpers';
import { TSkeleton } from '@/templates/UI/types';

const SquareContainer = styled(Row)<Pick<TSkeleton, 'wrapperHeight'>>`
  height: ${ props => isNumber(props?.wrapperHeight) ? `${ props?.wrapperHeight }px` : props?.wrapperHeight };
`;

const SquareContent = styled(Col)<Pick<TSkeleton, 'align' | 'width' | 'height' | 'radius'> & { colSpan: number }>`
  flex: 0 0 ${ props => props?.colSpan }%;
  max-width: ${ props => props?.colSpan }%;
  text-align: ${ props => props?.align };
  
  .ant-skeleton {
    width: ${ props => isNumber(props?.width) ? `${ props?.width }px` : props?.width } !important;
  }
  
  .ant-skeleton-input {
    width: 100% !important;
    height: ${ props => isNumber(props?.height) ? `${ props?.height }px` : props?.height } !important;
    border-radius: ${ props => props?.radius } !important;
  }
`;

export const Skeleton: FC<TSkeleton> = ({
  count = { row: 1, col: 1 }, gutter = [
    16,
    16
  ], wrapperHeight = '100%', width = '100%', height, radius = 0, align = 'center'
}) => {
  const {
    row = 1,
    col = 1
  } = count;
  
  const arrayLength = row * col;
  
  const [ xGutter, yGutter ] = gutter;
  
  const borderRadius = radius ? (isNumber(radius) ? `${ radius }px` : radius) : 'unset';
  
  return (
    <SquareContainer
      gutter={ [ xGutter, yGutter ] }
      wrapperHeight={ wrapperHeight }
    >
      { Array.from({ length: arrayLength })
      ?.map((_, i) => {
        return (
          <SquareContent
            key={ `squareSkeleton_${ i + 1 }` }
            colSpan={ 100 / col }
            width={ width }
            height={ height }
            radius={ borderRadius }
            align={ align }
          >
            <AntdSkeleton.Input active />
          </SquareContent>
        );
      }) }
    </SquareContainer>
  );
};