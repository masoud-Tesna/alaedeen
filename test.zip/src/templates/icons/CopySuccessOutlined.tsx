import { CustomIconComponentProps } from '@ant-design/icons/lib/components/Icon';
import Icon from '@ant-design/icons';

const CopySuccessOutlinedSvg = (props: Partial<CustomIconComponentProps>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="currentColor"
    viewBox="0 0 20 20"
    { ...props }
  >
    <path
      d="M14.25 1.041h-3.5c-3.259 0-4.709 1.45-4.709 4.708v.917a.63.63 0 00.625.625h2.583c2.584 0 3.459.875 3.459 3.458v2.584a.63.63 0 00.625.625h.916c3.259 0 4.709-1.45 4.709-4.709v-3.5c0-3.258-1.45-4.708-4.709-4.708zm-6.959 5v-.292c0-2.583.875-3.458 3.458-3.458h3.5c2.584 0 3.459.875 3.459 3.458v3.5c0 2.584-.875 3.459-3.459 3.459h-.291v-1.959c0-3.258-1.45-4.708-4.709-4.708H7.291z"
    ></path>
    <path
      d="M9.25 6.041h-3.5c-3.259 0-4.709 1.45-4.709 4.708v3.5c0 3.259 1.45 4.709 4.708 4.709h3.5c3.259 0 4.709-1.45 4.709-4.709v-3.5c0-3.258-1.45-4.708-4.709-4.708zm-3.5 11.667c-2.584 0-3.459-.875-3.459-3.459v-3.5c0-2.583.875-3.458 3.458-3.458h3.5c2.584 0 3.459.875 3.459 3.458v3.5c0 2.584-.875 3.459-3.459 3.459h-3.5z"
    ></path>
    <path
      d="M6.691 14.75a.618.618 0 01-.441-.184l-1.625-1.625a.629.629 0 010-.883.629.629 0 01.883 0L6.69 13.24l2.8-2.8a.629.629 0 01.884 0 .629.629 0 010 .883l-3.25 3.242a.62.62 0 01-.434.183z"
    ></path>
  </svg>
);

export const CopySuccessOutlined = (props: Partial<CustomIconComponentProps>) => (
  <Icon component={ CopySuccessOutlinedSvg } { ...props } />
);