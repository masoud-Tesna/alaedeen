import { CustomIconComponentProps } from '@ant-design/icons/lib/components/Icon';
import Icon from '@ant-design/icons';

const DotCircleFilledSvg = (props: Partial<CustomIconComponentProps>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="currentColor"
    viewBox="0 0 11 10"
    { ...props }
  >
    <circle cx="5.5" cy="5" r="5"></circle>
  </svg>
);

export const DotCircleFilled = (props: Partial<CustomIconComponentProps>) => (
  <Icon component={ DotCircleFilledSvg } { ...props } />
);