import type { ThemeConfig } from 'antd';
import type { Config } from 'tailwindcss';

type TailwindcssConfig = Omit<Config, 'content'>;

type AntdConfig = ThemeConfig;

const tailwindcssConfig: TailwindcssConfig = {
  theme: {
    screens: {
      'sm': '576px',
      'md': '768px',
      'lg': '992px',
      'xl': '1200px',
      '2xl': '1600px'
    },
    extend: {
      backgroundImage: {
        auth: 'linear-gradient(180deg, #405189 21.35%, rgba(116, 128, 169, 0.91) 81.25%, rgba(255, 255, 255, 0.66) 100%)'
      },
      spacing: {
        8: '8px',
        16: '16px',
        24: '24px',
        32: '32px',
        40: '40px',
        48: '48px',
        56: '56px',
        64: '64px',
        80: '80px',
        120: '120px',
        160: '160px'
      },
      borderRadius: {
        4: '4px',
        8: '8px',
        16: '16px',
        24: '24px',
        32: '32px',
        64: '64px'
      },
      padding: {
        4: '4px',
        8: '8px',
        16: '16px',
        24: '24px',
        32: '32px'
      },
      margin: {
        4: '4px',
        8: '8px',
        16: '16px',
        24: '24px',
        32: '32px'
      },
      boxShadow: {
        0: '0px 1px 0px 0px #E2E8F0',
        1: '0px -1px 4px 0px rgba(0, 0, 0, 0.04)',
        2: '0px 0px 1px 0px rgba(9, 30, 66, 0.00)',
        3: '0px 8px 13px -3px rgba(0, 0, 0, 0.07)',
        4: '0px 1px 8px 0px rgba(0, 0, 0, 0.12)',
        5: '0px 8px 12px 0px rgba(0, 0, 0, 0.12)',
        6: '0px 8px 16px 0px rgba(0, 0, 0, 0.16)',
        7: '0px 16px 24px 0px rgba(0, 0, 0, 0.16)',
        8: '0px 0px 1px 0px rgba(9, 30, 66, 0.08), 0px 3px 4px 0px rgba(9, 30, 66, 0.05)'
      },
      colors: {
        primary: {
          0: '#405189',
          tint: {
            1: '#F7F8FE',
            2: '#D0D6E9',
            3: '#B9C2DE',
            4: '#A2ADD3',
            5: '#8B99C8',
            6: '#7385BE',
            7: '#5C70B3'
          },
          shade: {
            1: '#4B5FA2',
            2: '#40528B',
            3: '#364473',
            4: '#2B365C',
            5: '#202945',
            6: '#151B2E',
            7: '#0A0D17',
            8: '#54698D',
            9: '#8795AF'
          }
        },
        neutral: {
          white: '#FFFFFF',
          gray: {
            1: '#F9F9F9',
            2: '#EDEDED',
            3: '#E1E1E1',
            4: '#CBCBCB',
            5: '#ADADAD',
            6: '#757575',
            7: '#353535',
            8: '#E5E7EB',
            9: '#F5F7F9'
          },
          black: '#0C0C0C'
        },
        error: {
          0: '#C30000',
          light: '#ED2E2E',
          extraLight: '#FFE4E4'
        },
        success: {
          0: '#00966D',
          light: '#00BA88',
          extraLight: '#DDFFF5'
        },
        warning: {
          0: '#A9791C',
          light: '#F4B740',
          extraLight: '#FFF8E1'
        },
        green: {
          0: '#05A34A',
          light: '#DAF4F0'
        },
        yellow: {
          0: '#FFB300',
          light: '#EFF4E4'
        },
        blue: {
          0: '#299CDD',
          light: '#DFF0FA'
        },
        orange: {
          0: '#F06548',
          light: '#FDE8E4'
        },
        bgColor: '#FAFBFD'
      },
      fontSize: {
        display1: [ '4rem', { lineHeight: '140%', fontWeight: 700 } ],
        display2: [ '3.5rem', { lineHeight: '120%', fontWeight: 700 } ],
        h1: [ '2.75rem', { lineHeight: '140%', fontWeight: 700 } ],
        h2: [ '2.5rem', { lineHeight: '140%', fontWeight: 700 } ],
        h3: [ '2rem', { lineHeight: '140%', fontWeight: 700 } ],
        h4: [ '1.5rem', { lineHeight: '140%', fontWeight: 700 } ],
        h5: [ '1.25rem', { lineHeight: '140%', fontWeight: 700 } ],
        h6: [ '1rem', { lineHeight: '140%', fontWeight: 700 } ],
        h7: [ '1.25rem', { lineHeight: '180%', fontWeight: 700 } ],
        bodyXl: [ '1.25rem', { lineHeight: '180%', fontWeight: 400 } ],
        bodyLg: [ '1.125rem', { lineHeight: '180%', fontWeight: 500 } ],
        bodyMd: [ '1rem', { lineHeight: '180%', fontWeight: 500 } ],
        bodySm: [ '.875rem', { lineHeight: '180%', fontWeight: 400 } ],
        captionLg: [ '.875rem', { lineHeight: '180%', fontWeight: 500 } ],
        captionMd: [ '.75rem', { lineHeight: '180%', fontWeight: 500 } ],
        captionSm: [ '.625rem', { lineHeight: '180%', fontWeight: 400 } ],
        buttonLg: [ '1rem', { lineHeight: '180%', fontWeight: 500 } ],
        buttonSm: [ '.875rem', { lineHeight: '1.5rem', fontWeight: 500 } ],
        overlineLg: [ '1rem', { lineHeight: '180%', fontWeight: 400 } ],
        overlineSm: [ '.75rem', { lineHeight: 'normal', fontWeight: 700 } ]
      },
      fontFamily: {
        vazir: 'vazirFont'
      }
    }
  }
};

const antdConfig: AntdConfig = {
  token: {
    fontSize: 16,
    fontFamily: 'vazirFont',
    colorBgLayout: '#FFFFF',
    colorPrimary: tailwindcssConfig?.theme?.extend?.colors?.primary[ 0 ]
  },
  components: {
    Form: {
      itemMarginBottom: 40
    },
    Input: {
      controlHeight: 41,
      controlHeightLG: 38,
      controlHeightSM: 32,
      colorBorder: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 9 ],
      hoverBorderColor: tailwindcssConfig?.theme?.extend?.colors?.primary[ 0 ],
      activeBorderColor: tailwindcssConfig?.theme?.extend?.colors?.primary[ 0 ],
      activeShadow: '0 0 0 2px rgba(64, 81, 137, 0.1)',
      borderRadius: 4
    },
    Select: {
      controlHeight: 42,
      controlHeightLG: 38,
      controlHeightSM: 32,
      colorBorder: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 9 ],
      colorPrimaryHover: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 3 ],
      optionSelectedBg: tailwindcssConfig?.theme?.extend?.colors?.neutral?.gray[ 8 ],
      borderRadius: 4,
      optionFontSize: 14,
      colorText: tailwindcssConfig?.theme?.extend?.colors?.neutral?.black,
      optionSelectedFontWeight: 500,
      'algorithm': true
    },
    Checkbox: {
      colorBorder: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 9 ],
      colorPrimary: tailwindcssConfig?.theme?.extend?.colors?.primary[ 0 ],
      colorPrimaryHover: tailwindcssConfig?.theme?.extend?.colors?.primary[ 0 ]
    },
    Button: {
      controlHeight: 42
    },
    Upload: {
      colorBorder: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 9 ]
    },
    Layout: {
      headerBg: tailwindcssConfig?.theme?.extend?.colors?.neutral?.white,
      siderBg: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 5 ]
    },
    Menu: {
      itemBg: 'transparent',
      itemActiveBg: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 4 ],
      itemSelectedBg: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 4 ],
      itemHoverBg: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 3 ],
      itemColor: tailwindcssConfig?.theme?.extend?.colors?.bgColor,
      itemHoverColor: tailwindcssConfig?.theme?.extend?.colors?.bgColor,
      itemSelectedColor: tailwindcssConfig?.theme?.extend?.colors?.bgColor,
      itemBorderRadius: 4,
      itemMarginBlock: 8,
      iconMarginInlineEnd: 22
    },
    Breadcrumb: {
      colorText: tailwindcssConfig?.theme?.extend?.colors?.primary[ 0 ],
      colorTextDescription: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 9 ]
    },
    Table: {
      colorText: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 9 ],
      colorTextHeading: tailwindcssConfig?.theme?.extend?.colors?.primary?.shade[ 8 ],
      headerBg: tailwindcssConfig?.theme?.extend?.colors?.neutral?.gray[ 9 ],
      headerBorderRadius: 0
    },
    Typography: {
      marginXXS: 10
    }
  }
};

export { antdConfig, tailwindcssConfig };