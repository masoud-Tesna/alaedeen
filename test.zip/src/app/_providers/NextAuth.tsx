'use client';

import { SessionProvider } from 'next-auth/react';
import { FC, PropsWithChildren } from 'react';
import { Session } from 'next-auth';

const NextAuth: FC<PropsWithChildren<{ session: Session | null }>> = ({ children, session }) => {
  
  return (
    <SessionProvider session={ session }>
      { children }
    </SessionProvider>
  );
};

export default NextAuth;
