import React, { FC, PropsWithChildren } from 'react';
import ReactQuery from '@/app/_providers/ReactQuery';
import AntDesign from '@/app/_providers/AntDesign';
import ReactToastify from '@/app/_providers/ReactToastify';

const CombineProviders: FC<PropsWithChildren> = ({ children }) => {
  return (
    <ReactQuery>
      <AntDesign>
        <ReactToastify>
          { children }
        </ReactToastify>
      </AntDesign>
    </ReactQuery>
  );
};

export default CombineProviders;