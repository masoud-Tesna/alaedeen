import { FC } from 'react';

// register step components
import { Spin } from '@/app/auth/register/components/Spin';
import { Row } from 'antd';
import RegisterForm from '@/app/auth/register/components/RegisterForm';

const Register: FC = () => {
  return (
    <Spin>
      <Row gutter={ [ 0, 24 ] }>
        <RegisterForm />
      </Row>
    </Spin>
  );
};

export default Register;
