import { TVerifyOtp, VerifyOtpZod } from '@/app/auth/register/schema';
import { request } from '@/utils/useRequest';
import { TCommon } from '../../type';
import { useLocalStorage } from '@/utils/helpers';

export const useHandleVerifyOtp = ({ formRef, setCurrentStep }: TCommon) => {
  const { mutateAsync: checkOtpRequest } = request.useMutation<TVerifyOtp>({
    url: '/auth/verifyOtp',
    mutationKey: [ 'auth', 'verifyOtp' ]
  });
  
  return async () => {
    try {
      await formRef.validateFields();
      const formData = <TVerifyOtp>formRef.getFieldsValue(true);
      const verifyOtpZod = VerifyOtpZod.parse(formData);
      const response = await checkOtpRequest(verifyOtpZod);
      
      if (response?.isSuccess) {
        const otpToken = response?.data?.token;
        
        formRef.setFields([
          {
            name: 'otpToken',
            value: otpToken
          }
        ]);
        
        setCurrentStep(current => {
          useLocalStorage.setRegisterStep({ ...formData, otpToken }, current + 1);
          
          return current + 1;
        }); // go to next step
      }
    }
    catch (error) {
      console.log('error in handleSendOtp >>', error);
    }
  };
};
