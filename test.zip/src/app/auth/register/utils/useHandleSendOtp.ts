import { EmailAndPasswordZod, TEmailAndPassword } from '@/app/auth/register/schema';
import { request } from '@/utils/useRequest';
import { TCommon } from '../../type';
import { useLocalStorage } from '@/utils/helpers';

export const useHandleSendOtp = ({ formRef, setCurrentStep }: TCommon) => {
  const { mutateAsync: sendOtpRequest } = request.useMutation<TEmailAndPassword>({
    url: '/auth/requestOtp',
    mutationKey: [ 'auth', 'requestOtp' ]
  });
  
  return async () => {
    try {
      await formRef?.validateFields([ 'email', 'password' ]);
      const formData = <TEmailAndPassword>formRef?.getFieldsValue(true);
      
      const emailAndPasswordZod = EmailAndPasswordZod.parse(formData);
      const res = await sendOtpRequest(emailAndPasswordZod);
      
      if (res?.isSuccess || res?.message === 'otp already has been sent') {
        // go to check otp step or in resend otp
        setCurrentStep(current => {
          useLocalStorage.setRegisterStep(formData, current + 1);
          
          if (current === 0) {
            return current + 1;
          }
          
          return current;
        });
      }
      
    }
    catch (error) {
      console.log('error in handleSendOtp >>', error);
    }
  };
};
