import { CustomerInformationZod, TCustomerInformation } from '@/app/auth/register/schema';
import { TCommon } from '../../type';
import { request } from '@/utils/useRequest';
import { signIn, SignInResponse } from 'next-auth/react';
import { useLocalStorage } from '@/utils/helpers';
import { TSingInResponse } from '@/app/auth/login/types';

export const useHandleRegister = ({ formRef, setCurrentStep }: TCommon) => {
  const registerApi = async (data: TCustomerInformation): Promise<TSingInResponse> => {
    const registerApiResponse = await signIn('registerProvider', {
      ...data,
      redirect: false
    });
    
    return registerApiResponse?.ok ?
      Promise.resolve({ ...registerApiResponse, message: 'registered successfully', isSuccess: true }) :
      Promise.reject({ ...registerApiResponse, message: registerApiResponse?.error, isSuccess: false });
  };
  
  const { mutateAsync: registerRequest } = request.useMutation<TCustomerInformation, TSingInResponse>({
    mutationFn: (data) => registerApi(data),
    mutationKey: [ 'auth', 'register' ]
  });
  
  return async () => {
    try {
      await formRef.validateFields();
      
      const formData = formRef.getFieldsValue(true);
      
      const customerInformationZod = CustomerInformationZod.parse(formData);
      
      const registerResponse = await registerRequest(customerInformationZod);
      
      if (registerResponse?.isSuccess) {
        useLocalStorage.removeRegisterStep(); // remove steps items
      }
      else {
        if (registerResponse?.message === 'otp token is expired') {
          useLocalStorage.setRegisterStep(formData, 0);
          setCurrentStep(0);
        }
        else {
          useLocalStorage.setRegisterStep(formData, 2);
        }
      }
    }
    catch (error) {
      console.log('error in handleRegister >>>', error);
    }
  };
};
