import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';
import { MobileZod, NationalCodeZod } from '@/app/schema';

export const BaseInformationZod = z.object({
  otpToken: z.string().regex(/^([a-zA-Z0-9_=]+)\.([a-zA-Z0-9_=]+)\.([a-zA-Z0-9_\-\+\/=]*)/gm, 'JWT token is not valid'),
  type: z.string({ required_error: setInputRule('requiredSelectBox', { inputName: 'نوع کاربری' }) }),
  mobile: MobileZod.optional()
});

export const LegalCustomerZod = BaseInformationZod.extend({
  companyName: z.string().max(40, setInputRule('maxLength', { inputName: 'نام شرکت', length: 40 })).optional(),
  companyId: z.string().length(11, setInputRule('length', { inputName: 'شناسه ملی شرکت', length: 11 })).optional(),
  companyFinancialId: z.string().optional()
});

export const RealCustomerZod = BaseInformationZod.extend({
  firstName: z.string().min(2).max(20, setInputRule('maxLength', { inputName: 'نام', length: 20 })).optional(),
  lastName: z.string().min(2).max(60, setInputRule('maxLength', { inputName: 'نام خانوادگی', length: 60 })).optional(),
  nationalCode: NationalCodeZod.optional()
});

export const CustomerInformationZod = z
.discriminatedUnion('type', [
  LegalCustomerZod.extend({ type: z.literal('legal') }),
  RealCustomerZod.extend({ type: z.literal('real') })
]);

export type TCustomerInformation = z.infer<typeof CustomerInformationZod>