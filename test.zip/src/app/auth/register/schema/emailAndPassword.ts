import { z } from 'zod';
import { EmailZod, PasswordZod } from '@/app/schema';

export const EmailAndPasswordZod = z.object({
  email: EmailZod,
  password: PasswordZod
});

export type TEmailAndPassword = z.infer<typeof EmailAndPasswordZod>;
