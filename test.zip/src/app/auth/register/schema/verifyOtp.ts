import { z } from 'zod';
import { EmailZod, OtpCodeZod } from '@/app/schema';

export const VerifyOtpZod = z.object({
  code: OtpCodeZod,
  email: EmailZod
});

export type TVerifyOtp = z.infer<typeof VerifyOtpZod>;