'use client';

import { Col, Form } from 'antd';
import { FC, Suspense, useEffect, useState } from 'react';
import { TransitionsComponent } from '@/templates/UI';
import { AuthSkeleton } from '@/templates/components';
import Description from '@/app/auth/register/components/Description';
import { stepsItem } from '@/app/auth/register/components/stepsItem';
import { TSteps } from '../../type';

const RegisterForm: FC = () => {
  const [ formRef ] = Form.useForm();
  
  const registerFields = localStorage.getItem('registerFields');
  const registerStep = localStorage.getItem('registerStep') ?? 0;
  
  const [ currentStep, setCurrentStep ] = useState(+registerStep);
  
  const steps = stepsItem({ currentStep, setCurrentStep });
  
  const activeStep = steps.find(item => item?.key === currentStep) as TSteps;
  
  useEffect(() => {
    if (registerFields) {
      formRef.setFieldsValue(JSON.parse(registerFields));
    }
  }, []);
  
  useEffect(() => {
    if (currentStep === 0) {
      formRef.resetFields([ 'code' ]);
    }
  }, [ currentStep ]);
  
  return (
    <>
      <Col span={ 24 }>
        <Description
          description={ activeStep?.description }
          title={ activeStep?.title }
        />
      </Col>
      
      <Col span={ 24 }>
        <Form
          form={ formRef }
          name="userRegister"
          layout="vertical"
        >
          <TransitionsComponent>
            <Suspense fallback={ <AuthSkeleton justInputs /> }>
              { activeStep?.component }
            </Suspense>
          </TransitionsComponent>
        </Form>
      </Col>
      
      { activeStep?.extra }
    </>
  );
};

export default RegisterForm;
