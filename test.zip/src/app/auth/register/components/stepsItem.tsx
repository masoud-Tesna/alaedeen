'use client';

import { TSteps, TStepsComponentProps } from '../../type';
import { Col, Space } from 'antd';
import Link from 'next/link';
import dynamic from 'next/dynamic';

// steps component
const EmailAndPassword = dynamic(() => import('@/app/auth/register/components/steps/EmailAndPassword'));
const VerifyOtp = dynamic(() => import('@/app/auth/register/components/steps/VerifyOtp'));
const CustomerInformation = dynamic(() => import('@/app/auth/register/components/steps/CustomerInformation'));

export const stepsItem = ({ currentStep, setCurrentStep }: TStepsComponentProps): Array<TSteps> => ([
  {
    key: 0,
    title: 'ثبت نام',
    description: 'برای شروع آدرس ایمیل و مشخصات فردی خود را وارد نمایید',
    component: <EmailAndPassword
      currentStep={ currentStep }
      setCurrentStep={ setCurrentStep }
    />,
    extra: <Col
      span={ 24 }
      className="text-captionMd mt-[60px]"
    >
      <Space
        size={ 16 }
        className="text-captionLg"
      >
        <div className="text-primary-shade-8">
          حساب کاربری دارید؟
        </div>
        
        <div>
          <Link href={ '/auth/login' }>
            ورود
          </Link>
        </div>
      </Space>
    </Col>
  },
  {
    key: 1,
    component: <VerifyOtp
      currentStep={ currentStep }
      setCurrentStep={ setCurrentStep }
    />,
    extra: <Col span={ 24 }>
        <span
          className="!text-captionMd mt-[60px] text-blue-0 hover:text-primary-shade-3 cursor-pointer"
          onClick={ () => setCurrentStep(0) }
        >
          ویرایش آدرس ایمیل
        </span>
    </Col>
  },
  {
    key: 2,
    component: <CustomerInformation currentStep={ currentStep } setCurrentStep={ setCurrentStep } />
  }
]);