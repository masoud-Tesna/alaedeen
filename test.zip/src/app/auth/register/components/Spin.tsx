'use client';

import { FC, PropsWithChildren } from 'react';
import { useIsMutating } from '@tanstack/react-query';
import { Spin as AntdSpin } from 'antd';

export const Spin: FC<PropsWithChildren> = ({ children }) => {
  const isLoading = useIsMutating({ mutationKey: [ 'login-request' ] });
  
  return (
    <AntdSpin spinning={ !!isLoading }>
      { children }
    </AntdSpin>
  );
};