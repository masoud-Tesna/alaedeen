'use client';

import { FC, useEffect, useState } from 'react';
import { OtpInput, TransitionsComponent } from '@/templates/UI';
import { fn_deadline, useCreateAntdZodValidation } from '@/utils/helpers';
import { Button, Form, Space, Statistic } from 'antd';
import { VerifyOtpZod } from '@/app/auth/register/schema';
import { TStepsComponentProps } from '../../../type';
import { useHandleVerifyOtp, useHandleSendOtp } from '@/app/auth/register/utils';
import { useIsMutating } from '@tanstack/react-query';
import Image from 'next/image';
import clockOutlined from '/public/icons/clockOutlined.svg';
import { LoadingOutlined } from '@ant-design/icons';
import classNames from 'classnames';

const VerifyOtp: FC<TStepsComponentProps> = ({ setCurrentStep, currentStep }) => {
  const formRef = Form.useFormInstance();
  
  // state for show btn To resend the verification code:
  const [ resendCode, setResendCode ] = useState(false);
  
  // state for show countdown for resend code (after: 2 Minute):
  const [ resendCodeDeadline, setResendCodeDeadline ] = useState(0);
  
  const isLoading = useIsMutating({ mutationKey: [ 'auth', 'requestOtp' ] });
  
  // handle for set resend code: show resend time
  useEffect(() => {
    let mounted = true;
    
    if (!isLoading && mounted) {
      setResendCodeDeadline(fn_deadline('00:03:01'));
      setResendCode(false);
    }
    
    return () => {
      mounted = false;
    };
  }, [ isLoading ]);
  
  const handleSendOtp = useHandleSendOtp({ formRef, setCurrentStep });
  
  const handleCheckOtp = useHandleVerifyOtp({ formRef, setCurrentStep });
  
  return (
    <>
      <TransitionsComponent.Motion id={ currentStep }>
        <div className="text-primary-shade-8 text-bodySm mb-16">
          کد ارسال شده به ایمیل { formRef.getFieldValue('email') } را وارد کنید
        </div>
        
        <div>
          <OtpInput
            formItemProps={ {
              name: 'code',
              floatingLabel: false,
              validateTrigger: 'onBlur',
              htmlFor: 'userRegister_code',
              rules: [ useCreateAntdZodValidation(VerifyOtpZod) ]
            } }
            onChange={ async (otp) => {
              if (otp?.length === 6) {
                await handleCheckOtp();
              }
            } }
          />
          
          { !resendCode ?
            <Space size={ 7 } className="!text-blue-0 !text-captionMd">
              <Image priority src={ clockOutlined } className="align-middle" alt="clockOutlined" />
              
              <div>
                زمان باقیمانده تا ارسال مجدد کد یکبار مصرف
              </div>
              
              <Statistic.Countdown
                className="[&>div]:!text-blue-0 [&>div]:!text-captionMd"
                value={ resendCodeDeadline }
                onFinish={ () => setResendCode(true) }
                format="(mm:ss)"
              />
            </Space> :
            <div>
              <span
                onClick={ !isLoading ? handleSendOtp : () => {} }
                className={ classNames(
                  'text-blue-0 text-captionMd cursor-pointer',
                  { '!cursor-not-allowed pointer-events-none ': !!isLoading }
                ) }
              >
                { !!isLoading && <LoadingOutlined /> } ارسال مجدد کد
              </span>
            </div>
          }
        
        </div>
      </TransitionsComponent.Motion>
      
      <Button
        type="primary"
        block
        onClick={ handleCheckOtp }
        className="mt-[30px]"
      >
        تایید کد
      </Button>
    </>
  );
};

export default VerifyOtp;
