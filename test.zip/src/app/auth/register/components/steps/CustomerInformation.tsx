'use client';

import { FC, JSX } from 'react';
import { FormItem, TransitionsComponent } from '@/templates/UI';
import { Button, Divider, Form, Input, Select } from 'antd';
import { useCreateAntdZodValidation } from '@/utils/helpers';
import LegalCustomer from '@/app/auth/register/components/steps/components/LegalCustomer';
import RealCustomer from '@/app/auth/register/components/steps/components/RealCustomer';
import { BaseInformationZod } from '@/app/auth/register/schema';
import { TStepsComponentProps } from '../../../type';
import { useHandleRegister } from '@/app/auth/register/utils';

const CustomerInformation: FC<TStepsComponentProps> = ({ currentStep, setCurrentStep }) => {
  
  const formRef = Form.useFormInstance();
  
  const customerType: number = Form.useWatch('type', formRef);
  
  const customerInformationFormItem: {
    [ key: string ]: JSX.Element
  } = {
    real: <RealCustomer />,
    legal: <LegalCustomer />
  };
  
  const handleRegister = useHandleRegister({ formRef, setCurrentStep });
  
  return (
    <>
      <TransitionsComponent.Motion id={ currentStep }>
        <FormItem
          name={ 'type' }
          label={ 'نوع کاربری' }
          placeholder={ 'نوع کاربری خود را انتخاب نمایید. ( اجباری )' }
          validateTrigger={ 'onBlur' }
          htmlFor={ 'userRegister_type' }
          rules={ [ useCreateAntdZodValidation(BaseInformationZod) ] }
        >
          <Select
            options={ [
              {
                value: 'real',
                label: 'کاربر حقیقی'
              },
              {
                value: 'legal',
                label: 'کاربر حقوقی'
              }
            ] }
          />
        </FormItem>
        
        <TransitionsComponent>
          <TransitionsComponent.Motion
            id={ customerType ? customerType?.toString() : 'initial' }
            size={ 50 }
            transition={ {
              duration: .5
            } }
          >
            { customerType ?
              customerInformationFormItem[ customerType ] :
              null
            }
          </TransitionsComponent.Motion>
        </TransitionsComponent>
        
        <Divider
          orientation="left"
          orientationMargin={ 16 }
          className="[&>span]:!p-0 [&>span]:text-neutral-black [&>span]:text-buttonLg"
        >
          اطلاعات تماس
        </Divider>
        
        <div className="text-primary-shade-8 text-bodySm">
          در صورت تمایل به دریافت آخرین اطلاعیه ها و اخبار سامانه، شماره موبایل خود را وارد نمایید
        </div>
        
        <FormItem
          name={ 'mobile' }
          label={ 'موبایل' }
          placeholder={ 'موبایل' }
          rules={ [ useCreateAntdZodValidation(BaseInformationZod) ] }
        >
          <Input onPressEnter={ handleRegister } />
        </FormItem>
      </TransitionsComponent.Motion>
      
      <Button
        type="primary"
        block
        onClick={ handleRegister }
        className="mt-[30px]"
      >
        ثبت نام
      </Button>
    </>
  );
};

export default CustomerInformation;

