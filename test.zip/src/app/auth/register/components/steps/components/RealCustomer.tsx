import { FC } from 'react';
import { Divider, Input } from 'antd';
import { FormItem } from '@/templates/UI';
import { RealCustomerZod } from '@/app/auth/register/schema';
import { useCreateAntdZodValidation } from '@/utils/helpers';

const RealCustomer: FC = () => {
  return (
    <>
      <Divider
        orientation="left"
        orientationMargin={ 16 }
        className="[&>span]:!p-0 [&>span]:text-neutral-black [&>span]:text-buttonLg"
      >
        اطلاعات هویتی
      </Divider>
      
      <div className="text-primary-shade-8 text-bodySm">
        جهت صدور پیش فاکتور و فاکتور رسمی اطلاعات زیر را وارد نمایید
      </div>
      
      <FormItem
        name={ 'firstName' }
        label={ 'نام' }
        placeholder={ 'نام' }
        validateTrigger={ 'onBlur' }
        htmlFor={ 'userRegister_firstName' }
        rules={ [ useCreateAntdZodValidation(RealCustomerZod) ] }
      >
        <Input />
      </FormItem>
      
      <FormItem
        name={ 'lastName' }
        label={ 'نام خانوادگی' }
        placeholder={ 'نام خانوادگی' }
        validateTrigger={ 'onBlur' }
        htmlFor={ 'userRegister_lastName' }
        rules={ [ useCreateAntdZodValidation(RealCustomerZod) ] }
      >
        <Input />
      </FormItem>
      
      <FormItem
        name={ 'nationalCode' }
        label={ 'کد ملی' }
        placeholder={ 'کد ملی' }
        validateTrigger={ 'onBlur' }
        htmlFor={ 'userRegister_nationalCode' }
        rules={ [ useCreateAntdZodValidation(RealCustomerZod) ] }
      >
        <Input />
      </FormItem>
    </>
  );
};

export default RealCustomer;
