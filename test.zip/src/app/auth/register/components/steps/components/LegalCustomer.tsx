import { FC } from 'react';
import { Divider, Input } from 'antd';
import { FormItem } from '@/templates/UI';
import { LegalCustomerZod } from '@/app/auth/register/schema';
import { useCreateAntdZodValidation } from '@/utils/helpers';

const LegalCustomer: FC = () => {
  return (
    <>
      <Divider
        orientation="left"
        orientationMargin={ 16 }
        className="[&>span]:!p-0 [&>span]:text-neutral-black [&>span]:text-buttonLg"
      >
        اطلاعات شرکت
      </Divider>
      
      <div className="text-primary-shade-8 text-bodySm">
        جهت صدور پیش فاکتور و فاکتور رسمی اطلاعات زیر را وارد نمایید
      </div>
      
      <FormItem
        name={ 'companyName' }
        label={ 'نام شرکت' }
        placeholder={ 'نام شرکت' }
        validateTrigger={ 'onBlur' }
        htmlFor={ 'userRegister_companyName' }
        rules={ [ useCreateAntdZodValidation(LegalCustomerZod) ] }
      >
        <Input />
      </FormItem>
      
      <FormItem
        name={ 'companyId' }
        label={ 'شناسه ملی شرکت' }
        placeholder={ 'شناسه ملی شرکت' }
        validateTrigger={ 'onBlur' }
        htmlFor={ 'userRegister_companyId' }
        rules={ [ useCreateAntdZodValidation(LegalCustomerZod) ] }
      >
        <Input />
      </FormItem>
      
      <FormItem
        name={ 'companyFinancialId' }
        label={ 'کد اقتصادی' }
        placeholder={ 'کد اقتصادی' }
        validateTrigger={ 'onBlur' }
        htmlFor={ 'userRegister_companyFinancialId' }
        rules={ [ useCreateAntdZodValidation(LegalCustomerZod) ] }
      >
        <Input />
      </FormItem>
    </>
  );
};

export default LegalCustomer;