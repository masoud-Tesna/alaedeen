'use client';

import { FC } from 'react';
import { FormItem, TransitionsComponent } from '@/templates/UI';
import { Button, Form, Input } from 'antd';
import { useCreateAntdZodValidation } from '@/utils/helpers';
import { EmailAndPasswordZod } from '@/app/auth/register/schema';
import { useHandleSendOtp } from '@/app/auth/register/utils';
import { TStepsComponentProps } from '../../../type';

const EmailAndPassword: FC<TStepsComponentProps> = ({ setCurrentStep, currentStep }) => {
  const formRef = Form.useFormInstance();
  
  const handleSendOtp = useHandleSendOtp({ formRef, setCurrentStep });
  
  // const emailWatch = Form.useWatch([ 'email' ], formRef);
  
  return (
    <>
      <TransitionsComponent.Motion id={ currentStep }>
        <FormItem
          name={ 'email' }
          label={ 'آدرس ایمیل' }
          placeholder={ 'آدرس ایمیل (اجباری)' }
          validateTrigger={ 'onBlur' }
          htmlFor={ 'userRegister_email' }
          // validateTrigger={ emailWatch?.length ? 'onBlur' : 'onSubmit' }
          rules={ [
            useCreateAntdZodValidation(EmailAndPasswordZod), {}
          ] }
        >
          <Input
            // onChange={ () => formRef.setFields([ { name: 'email', errors: [] } ]) }
          />
        </FormItem>
        
        <FormItem
          name={ 'password' }
          label={ 'رمز عبور' }
          placeholder={ 'رمز عبور (اجباری)' }
          validateTrigger={ 'onBlur' }
          htmlFor={ 'userRegister_password' }
          rules={ [ useCreateAntdZodValidation(EmailAndPasswordZod) ] }
        >
          <Input.Password onPressEnter={ handleSendOtp } />
        </FormItem>
      
      </TransitionsComponent.Motion>
      
      <Button
        type="primary"
        block
        onClick={ handleSendOtp }
        className="mt-[30px]"
      >
        ارسال کد یکبار مصرف
      </Button>
    </>
  );
};

export default EmailAndPassword;
