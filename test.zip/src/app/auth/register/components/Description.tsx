import { FC } from 'react';
import { TSteps } from '../../type';

const Description: FC<Pick<TSteps, 'title' | 'description'>> = ({ title, description }) => {
  return (
    <>
      { !!title &&
      typeof title === 'string' ?
        <div className="text-h7 text-primary-0">
          { title }
        </div> :
        title
      }
      
      { !!description &&
      typeof description === 'string' ?
        <div className="text-bodySm text-primary-shade-8">
          { description }
        </div> :
        description
      }
    </>
  );
};

export default Description;