import { FormInstance } from 'antd';
import { TStepsComponentProps } from '@/app/auth/type/stepsItem';

export type TCommon = Omit<TStepsComponentProps, 'currentStep'> & {
  formRef: FormInstance,
}