import { Dispatch, Key, ReactNode, SetStateAction } from 'react';

export type TStepsComponentProps = {
  currentStep: number,
  setCurrentStep: Dispatch<SetStateAction<number>>,
}

export type TSteps = {
  key: Key,
  title?: string | ReactNode,
  description?: string | ReactNode,
  component: ReactNode,
  extra?: ReactNode,
}