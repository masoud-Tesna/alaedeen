'use client';

import { FC, PropsWithChildren, Suspense } from 'react';
import { Col, Row } from 'antd';
import Image from 'next/image';
import { redirect, useSearchParams, useSelectedLayoutSegment } from 'next/navigation';
import { AuthSkeleton } from '@/templates/components';
import { useSession } from 'next-auth/react';

import hubLogo from '/public/images/hubLogo.svg';
import hubLogoWithoutText from '/public/images/hubLogoWithoutText.svg';

const AuthLayout: FC<PropsWithChildren> = ({ children }) => {
  
  const { data: session } = useSession();
  
  const segment = useSelectedLayoutSegment() || '';
  const searchParams = useSearchParams();
  
  const levelSelection = searchParams.get('levelSelection');
  const callbackUrl = searchParams.get('callbackUrl');
  
  if (session) {
    if (!session?.user?.hasApplication && segment !== 'createApp' && !callbackUrl) {
      return redirect('/auth/createApp');
    }
    else if (segment === 'createApp' && session?.user?.hasApplication) {
      return redirect(callbackUrl ?? '/dashboard');
    }
    else if ([ 'register', 'login' ].includes(segment)) {
      return redirect(callbackUrl ?? '/dashboard');
    }
  }
  
  return (
    <Row
      className="h-full"
      align={ 'stretch' }
    >
      <Col span={ levelSelection ? 24 : 12 }>
        <Row gutter={ [ 0, 32 ] }>
          <Col
            span={ 24 }
            className="text-center pt-[65px]"
          >
            <Image
              priority
              src={ hubLogo }
              alt={ 'HUB' }
              layout="responsive"
              className="max-w-[81px]"
            />
          </Col>
          
          <Col
            span={ 24 }
            className="pb-[15px] px-[4%] md:px-[5.5%] lg:px-[6.5%]"
          >
            <Suspense fallback={ <AuthSkeleton justInputs /> }>
              { children }
            </Suspense>
          </Col>
        </Row>
      </Col>
      
      { !levelSelection &&
        <Col
          span={ 12 }
          className="bg-[url('/images/authBg.png')] bg-no-repeat bg-cover max-lg:bg-center"
        >
          <div className="!h-full bg-auth opacity-70 flex justify-center align-middle">
            <Image
              src={ hubLogoWithoutText }
              className="w-[50%] opacity-5 m-auto"
              alt="alt" /*TODO: add alt*/
            />
          </div>
        </Col>
      }
    </Row>
  );
};

export default AuthLayout;
