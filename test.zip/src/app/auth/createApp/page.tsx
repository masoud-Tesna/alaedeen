import { Spin } from 'antd';
import { FC } from 'react';
import CreateAppForm from '@/app/auth/createApp/components/CreateAppForm';

const CreateApp: FC = () => {
  return (
    <Spin spinning={ false }>
      <CreateAppForm />
    </Spin>
  );
};

export default CreateApp;