export type { TDetailProps, TLevelBoxProps } from './appLevelProps';
