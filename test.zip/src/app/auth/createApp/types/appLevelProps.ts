import { Key, MouseEventHandler } from 'react';
import { TLevel, TRateLimit } from '@/app/auth/createApp/schema';

export type TLevelBoxProps = TLevel & {
  onClick: MouseEventHandler<HTMLDivElement>,
  selectedLevelWatch: string | null
}

export type TDetailProps = TRateLimit