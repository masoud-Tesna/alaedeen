import { request } from '@/utils/useRequest';
import { TCommon } from '../../type';
import { ChoseLevelZod, TChoseLevel } from '@/app/auth/createApp/schema/choseLevel';
import { useSession } from 'next-auth/react';
import { requestApi } from '@/utils/axios/requestApi';

export const useHandleChoseLevel = ({ formRef }: Omit<TCommon, 'setCurrentStep'>) => {
  const { update } = useSession();
  
  const { mutateAsync: choseLevelRequest } = request.useMutation<TChoseLevel>({
    mutationKey: [ 'application', 'choseLevel' ],
    mutationFn: variables => requestApi({
      url: `/application/${ variables?.applicationId }/level/${ variables?.levelId }`,
      method: 'patch'
    })
  });
  
  return async () => {
    try {
      await formRef?.validateFields();
      const formData = <TChoseLevel>formRef?.getFieldsValue(true);
      
      const createAppZod = ChoseLevelZod.parse(formData);
      await choseLevelRequest(createAppZod);
      
      await update({ hasApplication: true });
    }
    catch (error) {
      console.log('error in useHandleCreateApp >>', error);
    }
  };
};
