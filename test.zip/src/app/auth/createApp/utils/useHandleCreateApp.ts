import { request } from '@/utils/useRequest';
import { TCommon } from '../../type';
import { CreateAppZod, TCreateApp } from '@/app/auth/createApp/schema';

export const useHandleCreateApp = ({ formRef, setCurrentStep }: TCommon) => {
  const { mutateAsync: createAppRequest } = request.useMutation<TCreateApp>({
    url: '/application/create',
    mutationKey: [ 'application', 'create' ]
  });
  
  return async () => {
    try {
      await formRef?.validateFields();
      const formData = <TCreateApp>formRef?.getFieldsValue(true);
      
      const createAppZod = CreateAppZod.parse(formData);
      const res = await createAppRequest(createAppZod);
      
      formRef.setFields([
        {
          name: 'applicationId',
          value: res?.data?.applicationId
        }
      ]);
      
      setCurrentStep(current => current + 1);
    }
    catch (error) {
      console.log('error in useHandleCreateApp >>', error);
    }
  };
};
