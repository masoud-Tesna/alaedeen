import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect } from 'react';

export const useHandleLevelSelection = (currentStep: number) => {
  const searchParams = useSearchParams();
  const current = new URLSearchParams(Array.from(searchParams.entries())); // -> has to use this form
  const router = useRouter();
  const pathname = usePathname();
  
  useEffect(() => {
    if (currentStep !== 1) {
      current.delete('levelSelection');
      
    }
    else {
      current.set('levelSelection', 'true');
    }
    
    // cast to string
    const search = current.toString();
    // or const query = `${'?'.repeat(search.length && 1)}${search}`;
    const query = search ? `?${ search }` : '';
    
    router.push(`${ pathname }${ query }`);
  }, [ currentStep ]);
};