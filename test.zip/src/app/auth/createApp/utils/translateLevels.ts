export const translateLevels: { [ key: string ]: string } = {
  'startup': 'استارت آپ',
  'small-business': 'کسب و کار کوچک',
  'medium-business': 'کسب و کار متوسط',
  'large-business': 'کسب و کار بزرگ',
  'enterprise': 'اپلیکیشن ویژه',
  'second': 'ثانیه',
  'minute': 'دقیقه',
  'hour': 'ساعت',
  'day': 'روز',
  'week': 'هفته',
  'month': 'ماه',
  'year': 'سال',
  'yearly': 'سالانه'
};