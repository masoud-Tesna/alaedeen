'use client';

import { TSteps, TStepsComponentProps } from '@/app/auth/type';

// steps component
import CreateApp from '@/app/auth/createApp/components/steps/CreateApp';
import AppLevel from '@/app/auth/createApp/components/steps/AppLevel';

export const stepsItem = ({ currentStep, setCurrentStep }: TStepsComponentProps): Array<TSteps> => ([
  {
    key: 0,
    component: <CreateApp
      currentStep={ currentStep }
      setCurrentStep={ setCurrentStep }
    />
  },
  {
    key: 1,
    component: <AppLevel
      currentStep={ currentStep }
      setCurrentStep={ setCurrentStep }
    />
  }
]);