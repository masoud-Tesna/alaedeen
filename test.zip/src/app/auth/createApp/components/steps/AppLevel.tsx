'use client';

import { FC } from 'react';
import { Button, Form, Input, Space } from 'antd';
import { formatNumber } from '@/utils/helpers';
import { m } from 'framer-motion';
import classNames from 'classnames';
import { FormItem, TransitionsComponent } from '@/templates/UI';
import { TDetailProps, TLevelBoxProps } from '@/app/auth/createApp/types';
import { TStepsComponentProps } from '@/app/auth/type';
import { translateLevels, useHandleChoseLevel } from '@/app/auth/createApp/utils';
import { AppLevelSkeleton } from '@/templates/components';
import { TResponseLevels } from '@/app/auth/createApp/schema';
import { request } from '@/utils/useRequest';

const AppLevel: FC<TStepsComponentProps> = ({ setCurrentStep, currentStep }) => {
  const formRef = Form.useFormInstance();
  
  const selectedLevelWatch = Form.useWatch('levelId', formRef) || null;
  
  const { data, isLoading } = request.useQuery<TResponseLevels>({
    queryKey: [ 'application', 'levels' ],
    url: '/application/levels',
    retry: 0
  });
  
  const levels = data?.data?.level || [];
  
  const selectedLevelDetails = levels?.find(item => item?._id === selectedLevelWatch);
  
  const handleChoseLevel = useHandleChoseLevel({ formRef });
  return (
    <>
      <TransitionsComponent.Motion id={ currentStep }>
        <div className="flex flex-col justify-center gap-y-16 text-center mb-64 text-primary-shade-8">
          <div className="text-h5">
            انتخاب سطح
          </div>
          
          <div className="text-bodySm">
            سطح اپلیکیشن خود را براساس میزان فراخوانی مورد نیاز انتخاب نمایید
          </div>
        </div>
        
        <div className="flex gap-x-24">
          <FormItem
            name="levelId"
            hidden
            floatingLabel={ false }
          >
            <Input hidden />
          </FormItem>
          
          { isLoading ?
            <div className="w-full">
              <AppLevelSkeleton />
            </div> :
            levels?.length &&
            levels?.map(item => (
              <div className="w-1/5" key={ item?._id }>
                <LevelBox
                  selectedLevelWatch={ selectedLevelWatch }
                  onClick={ () => {
                    formRef.setFields([
                      {
                        name: 'levelId',
                        value: item?._id
                      }
                    ]);
                  } }
                  { ...item }
                />
              </div>
            ))
          }
        </div>
      </TransitionsComponent.Motion>
      
      <div className="flex gap-x-16 justify-center mt-48">
        <Button
          type="default"
          className="w-1/5"
          onClick={ () => setCurrentStep(current => current - 1) }
        >
          بازگشت
        </Button>
        
        <Button
          type="primary"
          className="w-1/5"
          onClick={ handleChoseLevel }
        >
          { selectedLevelDetails?.type === 'enterprise' ? 'درخواست اپلیکیشن ویژه' : 'انتخاب سطح' }
        </Button>
      </div>
    </>
  );
};

const LevelBox: FC<TLevelBoxProps> = ({ onClick, selectedLevelWatch, ...rest }) => {
  return (
    <m.div
      whileHover={ { scale: 1.065 } }
      whileTap={ { scale: 1 } }
      initial={ {
        scale: rest?.type === 'enterprise' ? 1.04 : 1
      } }
      className="cursor-pointer h-full"
      onClick={ onClick }
    >
      <div
        className={ classNames(
          'bg-primary-tint-1 border-solid border border-neutral-gray-8 rounded-4 p-4 space-y-32 h-full',
          { 'border-primary-0': selectedLevelWatch === rest?._id }
        ) }
      >
        <div
          className={ classNames(
            'flex flex-col items-center justify-center bg-neutral-gray-8 rounded-t-4 border-0 border-b border-dashed border-primary-tint-1 text-primary-0 py-16 space-y-16 h-[172px]',
            { 'bg-primary-0 !text-neutral-white': rest?.type === 'enterprise' }
          ) }
        >
          <div className="text-h4">
            { translateLevels[ rest?.title ] }
          </div>
          
          { rest?.type === 'general' &&
            <>
              <div
                className="w-1/2 mx-auto border-0 border-dashed border-t border-primary-0 h-1"
              />
              
              <div className="text-captionSm">
                اشتراک سالانه
              </div>
              
              <div>
                <Space>
                  <div className="text-h7">
                    { formatNumber(rest?.price) }
                  </div>
                  
                  <div className="text-primary-shade-9 text-captionMd">
                    تومان
                  </div>
                </Space>
              </div>
            </>
          }
        </div>
        
        <div className="--marker-opacity-3 px-32">
          { rest?.type === 'general' ?
            <ul className="list-none p-0 space-y-[13px]">
              { rest?.ratelimits?.map(item => (
                <li key={ rest?.title + '_' + item?.dimension }>
                  <Detail
                    { ...item }
                  />
                </li>
              )) }
            </ul> :
            <div className="text-primary-shade-9 text-captionMd">
              مقادیر فراخوانی مجاز برای اپلیکیشن ویژه به نسبت نیازسنجی انجام شده، تنظیم می‌شوند.
            </div>
          }
        
        </div>
      </div>
    </m.div>
  );
};

const Detail: FC<TDetailProps> = ({ dimension, limit, count }) => {
  const countLabel = count > 1 ? ('در ' + count) : 'در';
  
  const label = dimension === 'year' ?
    'فراخوانی مجاز در سال' :
    `فراخوانی ${ countLabel } ${ translateLevels[ dimension ] }`;
  
  return (
    <Space>
      <div className="text-neutral-gray-7 text-bodySm">
        { formatNumber(limit) }
      </div>
      
      <div className="text-primary-shade-9 text-captionSm">
        { label }
      </div>
    </Space>
  );
  
};

export default AppLevel;
