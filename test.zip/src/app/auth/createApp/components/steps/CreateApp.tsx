'use client';

import { FC } from 'react';
import { Button, Divider, Form, Input } from 'antd';
import { setInputRule, useCreateAntdZodValidation } from '@/utils/helpers';
import { FormItem, TransitionsComponent, Upload } from '@/templates/UI';
import { CreateAppZod } from '@/app/auth/createApp/schema';
import { RcFile } from 'antd/es/upload';
import baseURL from '@/utils/axios/baseURL';
import { TStepsComponentProps } from '@/app/auth/type';
import { useSession } from 'next-auth/react';
import { useHandleCreateApp } from '@/app/auth/createApp/utils';

const CreateApp: FC<TStepsComponentProps> = ({ setCurrentStep, currentStep }) => {
  const { data: session } = useSession();
  
  const formRef = Form.useFormInstance();
  
  const handleCreateApp = useHandleCreateApp({ formRef, setCurrentStep });
  
  const beforeUpload = (file: RcFile) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
    if (!isJpgOrPng) {
      formRef.setFields([
        {
          name: 'logoURL',
          errors: [ setInputRule('imageUploadTypeError', { inputName: 'تصویر لگو', types: 'JPG/PNG' }) ]
        }
      ]);
    }
    const isLt2M = file.size / 1024 / 1024 < 0.5;
    console.log(file.size);
    if (!isLt2M) {
      formRef.setFields([
        {
          name: 'logoURL',
          errors: [ setInputRule('imageUploadSizeError', { inputName: 'تصویر لگو', size: '500 کیلوبایت' }) ]
        }
      ]);
    }
    return isJpgOrPng && isLt2M;
  };
  
  return (
    <>
      <TransitionsComponent.Motion id={ currentStep }>
        <Divider
          orientation="left"
          orientationMargin={ 16 }
          className="[&>span]:!p-0 [&>span]:text-neutral-black [&>span]:text-buttonLg"
        >
          ساخت اپلیکیشن
        </Divider>
        
        <div className="text-primary-shade-8 text-bodySm">
          جهت دریافت توکن و شروع به استفاده از سرویس ها، اپلیکیشن خود را ایجاد نمایید.
        </div>
        
        <FormItem
          name={ 'name' }
          label={ 'نام اپلیکیشن' }
          placeholder={ 'نام اپلیکیشن ( اجباری )' }
          htmlFor={ 'userRegister_name' }
          rules={ [ useCreateAntdZodValidation(CreateAppZod) ] }
        >
          <Input />
        </FormItem>
        
        <Form.Item
          name="logoURL"
          className="--avatar-uploader-formItem"
        >
          <Upload
            name="file"
            listType="picture-card"
            action={ baseURL._serviceURL + '/file/upload' }
            headers={ {
              Authorization: `Bearer ${ session?.user?.accessToken }`
            } }
            handleSaveImageUrl={ imageUrl => {
              formRef.setFields([
                {
                  name: 'logoURL',
                  value: imageUrl
                }
              ]);
            } }
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ beforeUpload }
            imageProps={ {
              alt: 'avatar',
              layout: 'responsive',
              width: 140,
              height: 140,
              className: 'max-w-full max-h-full'
            } }
            uploadButtonTitle={ <div className="text-primary-shade-8 text-buttonSm">بارگذاری تصویر لوگو</div> }
          />
        </Form.Item>
        
        <FormItem
          name="applicationId"
          hidden
          floatingLabel={ false }
        >
          <Input hidden />
        </FormItem>
      </TransitionsComponent.Motion>
      
      <Button
        type="primary"
        block
        onClick={ handleCreateApp }
        className="mt-[30px]"
      >
        ساخت اپلیکیشن
      </Button>
    </>
  );
};

export default CreateApp;
