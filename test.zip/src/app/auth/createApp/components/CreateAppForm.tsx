'use client';

import { FC, Suspense, useState } from 'react';
import { Form } from 'antd';
import { stepsItem } from '@/app/auth/createApp/components/stepsItem';
import { TransitionsComponent } from '@/templates/UI';
import { AppLevelSkeleton, AuthSkeleton } from '@/templates/components';
import { TSteps } from '@/app/auth/type';
import { useHandleLevelSelection } from '@/app/auth/createApp/utils';

const CreateAppForm: FC = () => {
  const [ formRef ] = Form.useForm();
  
  const [ currentStep, setCurrentStep ] = useState(0);
  
  const steps = stepsItem({ currentStep, setCurrentStep });
  
  const activeStep = steps.find(item => item?.key === currentStep) as TSteps;
  
  useHandleLevelSelection(currentStep);
  
  return (
    <Form
      form={ formRef }
      name="userRegister"
      layout="vertical"
    >
      <TransitionsComponent>
        <Suspense fallback={ currentStep === 0 ? <AuthSkeleton justInputs /> : <AppLevelSkeleton /> }>
          { activeStep?.component }
        </Suspense>
      </TransitionsComponent>
    </Form>
  );
};

export default CreateAppForm;