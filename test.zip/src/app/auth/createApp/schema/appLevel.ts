import { z } from 'zod';

const RateLimitZod = z.object({
  dimension: z.enum([
    'second',
    'minute',
    'hour',
    'day',
    'week',
    'month',
    'year'
  ]),
  count: z.number(),
  limit: z.number()
});

const BaseLevelZod = z.object({
  _id: z.string(),
  title: z.string(),
  price: z.number()
});

const GeneralLevelZod = BaseLevelZod.extend({
  type: z.string().default('general'),
  ratelimits: z.array(RateLimitZod)
});

const EnterpriseLevelZod = BaseLevelZod.extend({
  type: z.string().default('enterprise'),
  ratelimits: z.array(RateLimitZod).optional()
});

const LevelZod = z.discriminatedUnion('type', [
  GeneralLevelZod.extend({ type: z.literal('general') }),
  EnterpriseLevelZod.extend({ type: z.literal('enterprise') })
]).brand('LevelZod');

export const LevelsZod = z.array(LevelZod);

export const ResponseLevelsZod = z.object({
  level: z.array(LevelZod)
});

export type TRateLimit = z.infer<typeof RateLimitZod>

export type TLevel = z.infer<typeof LevelZod>

export type TLevels = z.infer<typeof LevelsZod>

export type TResponseLevels = z.infer<typeof ResponseLevelsZod>