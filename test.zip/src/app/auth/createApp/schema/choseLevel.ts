import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';

export const ChoseLevelZod = z.object({
  applicationId: z.string(),
  levelId: z.string()
});

export type TChoseLevel = z.infer<typeof ChoseLevelZod>