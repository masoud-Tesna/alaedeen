import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';

export const CreateAppZod = z.object({
  name: z.string({ required_error: setInputRule('requiredInput', { inputName: 'نام اپلیکیشن' }) }),
  logoURL: z.string().optional()
});

export type TCreateApp = z.infer<typeof CreateAppZod>