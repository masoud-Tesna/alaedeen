import { AuthSkeleton } from '@/templates/components';

export default function Loading() {
  return <AuthSkeleton />;
}