import { SignInResponse } from 'next-auth/react';

export type TSingInResponse = SignInResponse & {
  message: string,
  isSuccess: boolean
}