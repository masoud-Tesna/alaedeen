import { FC, Suspense } from 'react';
import { Col, Row, Space } from 'antd';
import Link from 'next/link';
import LoginForm from '@/app/auth/login/components/LoginForm';
import { AuthSkeleton } from '@/templates/components';
import Spin from '@/app/auth/login/components/Spin';

const Login: FC = () => {
  return (
    <Spin>
      <Row
        gutter={ [ 0, 24 ] }
      >
        <Col span={ 24 }>
          <div className="text-h7 text-primary-0">
            ورود
          </div>
          
          <div className="text-bodySm text-primary-shade-8">
            برای ورود آدرس ایمیل و رمز عبور خود را وارد نمایید!
          </div>
        </Col>
        
        <Col span={ 24 }>
          <Suspense fallback={ <AuthSkeleton justInputs /> }>
            <LoginForm />
          </Suspense>
        </Col>
        
        <Col
          span={ 24 }
          className="text-captionMd mt-[60px]"
        >
          <Space
            size={ 16 }
            className="text-captionLg"
          >
            <div className="text-primary-shade-8">
              حساب کاربری ندارید؟
            </div>
            
            <div>
              <Link
                href={ '/auth/register' }
                className="text-blue-0"
              >
                ثبت نام
              </Link>
            </div>
          </Space>
          
          <div className="text-blue-0 text-captionLg mt-[11px]">
            فراموشی رمز عبور
          </div>
        </Col>
      </Row>
    </Spin>
  );
};

export default Login;
