import { z } from 'zod';
import { EmailZod, PasswordZod } from '@/app/schema';

export const LoginZod = z.object({
  email: EmailZod,
  password: PasswordZod
});

export type TLogin = z.infer<typeof LoginZod>;