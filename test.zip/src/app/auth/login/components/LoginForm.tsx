'use client';

import { FormItem, TransitionsComponent } from '@/templates/UI';
import { useCreateAntdZodValidation } from '@/utils/helpers';
import { LoginZod } from '@/app/auth/login/schema/login';
import { Button, Form, Input } from 'antd';
import { FC } from 'react';
import { useHandleLogin } from '@/app/auth/login/utils/useHandleLogin';

const LoginForm: FC = () => {
  const [ formRef ] = Form.useForm();
  
  const handleLogin = useHandleLogin();
  
  return (
    <Form
      form={ formRef }
      name="user-login"
      onFinish={ handleLogin }
    >
      <TransitionsComponent>
        <TransitionsComponent.Motion id={ 'loginPage' }>
          <FormItem
            name={ 'email' }
            label={ 'آدرس ایمیل' }
            placeholder={ 'آدرس ایمیل (اجباری)' }
            validateTrigger={ 'onBlur' }
            htmlFor={ 'userRegister_email' }
            rules={ [ useCreateAntdZodValidation(LoginZod) ] }
          >
            <Input />
          </FormItem>
          
          <FormItem
            name={ 'password' }
            label={ 'رمز عبور' }
            placeholder={ 'رمز عبور (اجباری)' }
            validateTrigger={ 'onBlur' }
            htmlFor={ 'userRegister_password' }
            rules={ [ useCreateAntdZodValidation(LoginZod) ] }
          >
            <Input.Password />
          </FormItem>
        </TransitionsComponent.Motion>
      </TransitionsComponent>
      
      <Button
        type="primary"
        block
        htmlType="submit"
        className="mt-[30px]"
      >
        ورود
      </Button>
    </Form>
  );
};

export default LoginForm;