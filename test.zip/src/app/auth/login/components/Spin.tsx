'use client';

import { FC, PropsWithChildren } from 'react';
import { Spin as AntdSpin } from 'antd';
import { useIsMutating } from '@tanstack/react-query';

const Spin: FC<PropsWithChildren> = ({ children }) => {
  const isLoading = useIsMutating({ mutationKey: [ 'auth', 'signIn' ] });
  
  return (
    <AntdSpin spinning={ !!isLoading }>
      { children }
    </AntdSpin>
  );
};

export default Spin;
