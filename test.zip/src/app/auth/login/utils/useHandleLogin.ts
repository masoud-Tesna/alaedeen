import { TLogin } from '@/app/auth/login/schema/login';
import { request } from '@/utils/useRequest';
import { signIn } from 'next-auth/react';
import { TSingInResponse } from '@/app/auth/login/types';

export const useHandleLogin = () => {
  const loginApi = async (data: TLogin): Promise<TSingInResponse> => {
    const loginApiResponse = await signIn('loginProvider', {
      ...data,
      redirect: false
    });
    
    return loginApiResponse?.ok ?
      Promise.resolve({ ...loginApiResponse, message: 'logged in successfully', isSuccess: true }) :
      Promise.reject({ ...loginApiResponse, message: loginApiResponse?.error, isSuccess: false });
  };
  
  const { mutateAsync: loginRequest, data } = request.useMutation<TLogin, TSingInResponse>({
    mutationFn: (data) => loginApi(data),
    mutationKey: [ 'auth', 'signIn' ]
  });
  
  return async (values: TLogin) => {
    try {
      await loginRequest(values);
    }
    catch (error) {
      console.log('error in handleLogin >>>', error);
    }
  };
};