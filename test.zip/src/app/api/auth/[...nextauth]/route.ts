import { handler } from '@/libs/auth';

export { handler as GET, handler as POST };