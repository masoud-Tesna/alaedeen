import React from 'react';
import { Col, Row } from 'antd';
import Link from 'next/link';

const Home: React.FC = () => {
  return (
    <Row>
      <Col
        span={ 24 }
        className="mt-[50px] p-64"
      >
        <Link href={ 'auth/login' }>
          Login page
        </Link>
      </Col>
    </Row>
  );
};

export default Home;
