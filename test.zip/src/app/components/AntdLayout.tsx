'use client';

import { FC, PropsWithChildren } from 'react';
import { Layout } from 'antd';

const AntdLayout: FC<PropsWithChildren> = ({ children }) => {
  return (
    <Layout className="h-full">
      <Layout.Content>
        { children }
      </Layout.Content>
    </Layout>
  );
};

export default AntdLayout;
