import { FC } from 'react';

const Dashboard: FC = () => {
  return (
    <div>
      Dashboard page
    </div>
  );
};

export default Dashboard;
