import { FC, PropsWithChildren } from 'react';
import { Layout } from 'antd';
import Sidebar from '@/app/dashboard/components/Sidebar';
import Header from '@/app/dashboard/components/Header';
import Content from '@/app/dashboard/components/Content';
import Breadcrumb from '@/app/dashboard/components/Breadcrumb';

const DashboardLayout: FC<PropsWithChildren> = async ({ children }) => {
  
  return (
    <Layout hasSider>
      <Sidebar />
      
      <Layout className="ms-[15%]">
        <Header />
        
        <Breadcrumb />
        
        <Content className="bg-bgColor p-32 mt-4">
          { children }
        </Content>
      </Layout>
    </Layout>
  );
};

export default DashboardLayout;
