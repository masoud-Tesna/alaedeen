import { Badge } from 'antd';
import bellOutlined from '/public/icons/bellOutlined.svg';
import Image from 'next/image';

const Notifications = () => {
  return (
    <div className="--headerItems --rounded relative">
      <Image priority src={ bellOutlined } alt={ '' } />
      <span className="w-[10px] h-[10px] border-solid border-[2px] border-neutral-white rounded-full bg-error-light absolute top-0 right-0" />
    </div>
  );
};

export default Notifications;
