'use client';

import { Layout } from 'antd';
import { useState } from 'react';
import satpayLogo from '/public/images/satpayLogo.svg';
import textAlignRightFilled from '/public/icons/textAlignRightFilled.svg';
import Image from 'next/image';
import classNames from 'classnames';
import SidebarMenu from '@/app/dashboard/components/SidebarMenu';
import { useSession } from 'next-auth/react';

const { Sider } = Layout;

const Sidebar = () => {
  
  const { data: session } = useSession();
  const [ collapsed, setCollapsed ] = useState(false);
  
  return (
    <Sider
      trigger={ null }
      collapsible
      collapsed={ collapsed }
      collapsedWidth={ 84 }
      className={ classNames(
        'py-32 overflow-auto h-screen !fixed top-0 start-0 bottom-0',
        { 'px-16': collapsed },
        { 'px-24': !collapsed }
      ) }
      width={ '15%' }
    >
      <div className="flex mb-[20px] min-h-[31px]">
        <div
          className={ classNames(
            'text-center w-3/4 transition-all duration-[.45s]',
            { 'w-0': collapsed }
          ) }
        >
          <Image
            priority src={ satpayLogo } alt={ 'SatPay' } className={ classNames(
            'w-full transition-all duration-[.45s]',
            { 'w-0': collapsed }
          ) }
          />
        </div>
        
        <div
          className={ classNames(
            'text-center w-1/4 cursor-pointer transition-all duration-[.45s]',
            { 'w-full': collapsed }
          ) }
          onClick={ () => setCollapsed(current => !current) }
        >
          <Image priority src={ textAlignRightFilled } alt={ '' } />
        </div>
      </div>
      
      <div
        className={ classNames(
          'text-primary-tint-4 text-bodySm mb-8 text-start transition-all duration-[.3s]',
          { 'ps-[12px]': collapsed },
          { 'ps-[18px]': !collapsed }
        ) }
      >
        منو
      </div>
      
      <SidebarMenu collapsed={ collapsed } role={ session?.user?.role } />
    </Sider>
  );
};

export default Sidebar;
