'use client';

import { Menu, MenuProps } from 'antd';
import { FC } from 'react';
import { SidebarMenuProps } from '@/app/dashboard/types/sidebarMenuProps';
import { useSelectedLayoutSegment, useSelectedLayoutSegments } from 'next/navigation';
import { menuItems } from '@/app/dashboard/utils/menuItems';
import Link from 'next/link';

const SidebarMenu: FC<SidebarMenuProps> = ({ collapsed, role }) => {
  
  const segment = useSelectedLayoutSegments();
  
  const filteredItems = menuItems.filter(item => item?.for?.includes('admin'));
  
  const items: MenuProps['items'] = filteredItems?.map(item => (
    {
      key: item?.key,
      icon: item?.icon && item?.icon(collapsed),
      label: item?.link ? <Link href={ item?.link }>{ item?.label }</Link> : item?.label
    }
  ));
  
  return (
    <Menu
      className="max-h-[calc(100%-88.2px)] overflow-y-auto"
      mode="inline"
      selectedKeys={ segment?.length ? segment : [ 'dashboard' ] }
      items={ items }
    />
  );
};

export default SidebarMenu;
