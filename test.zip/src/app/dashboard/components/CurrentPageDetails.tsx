'use client';

import { usePathname } from 'next/navigation';
import { findMenuItemByLink, menuItems } from '@/app/dashboard/utils/menuItems';
import { Col, Row } from 'antd';
import { FC, PropsWithChildren } from 'react';

const CurrentPageDetails: FC<PropsWithChildren> = ({ children }) => {
  const pathname = usePathname();
  
  const currentPage = findMenuItemByLink(menuItems, pathname);
  
  return (
    <Row gutter={ 16 } justify="space-between" align="middle" className="mb-32">
      <Col className="text-primary-shade-8 text-h6">
        { currentPage?.label }
      </Col>
      
      <Col span={ 10 }>
        { children }
      </Col>
    </Row>
  );
};

export default CurrentPageDetails;
