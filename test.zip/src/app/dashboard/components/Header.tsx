'use client';

import { Col, Row, Space } from 'antd';
import Search from '@/app/dashboard/components/Search';
import DarkMode from '@/app/dashboard/components/DarkMode';
import Languages from '@/app/dashboard/components/Languages';
import Profile from '@/app/dashboard/components/Profile';
import Notifications from '@/app/dashboard/components/Notifications';

const Header = () => {
  
  return (
    <Row justify="space-between" align="middle" className="h-[88px] py-16 shadow-0 px-32">
      <Col>
        <Search bordered={ false } className="!shadow-none" />
      </Col>
      
      <Col>
        <Space>
          <div>
            <DarkMode />
          </div>
          
          <div>
            <Languages />
          </div>
          
          <div>
            <Notifications />
          </div>
          
          <div>
            <Profile />
          </div>
        </Space>
      </Col>
    </Row>
  );
};

export default Header;
