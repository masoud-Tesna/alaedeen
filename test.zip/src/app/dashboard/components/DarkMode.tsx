import styled from 'styled-components';
import { useDarkMode } from '@/utils/helpers';
import classNames from 'classnames';
import sunFilled from '/public/icons/sunFilled.svg';
import moonFilled from '/public/icons/moonFilled.svg';

const DarkMode = () => {
  const [ theme, toggleTheme ] = useDarkMode();
  
  return (
    <button
      onClick={ toggleTheme }
      className={ classNames(
        '--headerItems rounded-32 p-[3px] w-[56px] d-ltr transition-all ease-linear duration-[.2s] relative',
        { '!bg-primary-0': theme === 'dark' }
      ) }
    >
      <div
        className={ classNames(
          'w-24 h-24 transition-all ease-linear duration-[.2s] relative rounded-full bg-neutral-white shadow-[0_2px_4px_0_rgba(0,0,0,.20)] translate-x-0 bg-no-repeat bg-center',
          { 'translate-x-[24px]': theme === 'dark' }
        ) }
        style={ {
          backgroundImage: `url(${ theme === 'light' ? sunFilled?.src : moonFilled?.src })`
        } }
      />
    </button>
  );
};

export default DarkMode;
