'use client';

import { Breadcrumb as AntdBreadcrumb, Col, Row } from 'antd';
import Link from 'next/link';
import { findMenuItemsByLink, menuItems } from '@/app/dashboard/utils/menuItems';
import { usePathname } from 'next/navigation';

const Breadcrumb = () => {
  const pathname = usePathname();
  
  const activeMenuItem = findMenuItemsByLink(menuItems, pathname)?.map((item, i, { length }) => (
    {
      label: item?.label,
      title: i + 1 < length ? <Link href={ item?.link }>{ item?.label }</Link> : item?.label
    }
  ));
  
  return (
    <Row justify="space-between" align="middle" className="h-[43px] py-8 shadow-0 px-32">
      <Col className="text-h5 text-primary-0">
        { activeMenuItem[ 0 ]?.label }
      </Col>
      
      <Col>
        <AntdBreadcrumb
          items={ activeMenuItem }
          className="!text-captionMd !leading-[24px]"
        />
      </Col>
    </Row>
  );
};

export default Breadcrumb;
