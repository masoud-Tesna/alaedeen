'use client';

import { Layout } from 'antd';
import { FC, HTMLAttributes, PropsWithChildren } from 'react';
import classNames from 'classnames';

const { Content: AntdContent } = Layout;

const Content: FC<PropsWithChildren<HTMLAttributes<HTMLDivElement>>> = ({ children, ...rest }) => {
  
  return (
    <AntdContent { ...rest }>
      { children }
    </AntdContent>
  );
};

export default Content;
