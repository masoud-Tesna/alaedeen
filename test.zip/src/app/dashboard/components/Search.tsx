import { Input } from 'antd';
import searchNormalOutlined from '/public/icons/searchNormalOutlined.svg';
import Image from 'next/image';
import { FC } from 'react';
import { TSearchProps } from '@/app/dashboard/types/search';
import classNames from 'classnames';

const Search: FC<TSearchProps> = ({
  placeholder = 'برای جستجو تایپ کنید...',
  iconAs = 'prefix',
  ...rest
}) => {
  
  const searchIcon = {
    [ iconAs ]: <Image
      priority
      src={ searchNormalOutlined }
      alt=""
      className={ classNames({ 'me-[6px]': iconAs === 'prefix' }, { 'ms-[6px]': iconAs === 'suffix' }) }
    />
  };
  
  return (
    <Input
      placeholder={ placeholder }
      { ...rest }
      { ...searchIcon }
    />
  );
};

export default Search;