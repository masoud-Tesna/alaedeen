const Languages = () => {
  return (
    <div className="--headerItems --rounded text-primary-0 text-captionMd">
      En
    </div>
  );
};

export default Languages;

