import profileOutlined from '/public/icons/profileOutlined.svg';
import { Dropdown, MenuProps, Space } from 'antd';
import downOutlined from '/public/icons/downOutlined.svg';
import Image from 'next/image';
import { signOut } from 'next-auth/react';

const items: MenuProps['items'] = [
  {
    key: '1',
    label: (
      <span>
        1st menu item
      </span>
    )
  },
  {
    key: '2',
    danger: true,
    onClick: () => signOut(),
    label: 'خروج'
  }
];

const Profile = () => {
  return (
    <Dropdown menu={ { items } } trigger={ [ 'click' ] } className="--headerProfile">
      <Space size={ 10 } className="cursor-pointer">
        <Image priority src={ profileOutlined } alt="" className="opacity-20" />
        
        <Space size={ 20 }>
          <div>
            <div className="text-primary-shade-7 text-bodySm">
              نجمه علوی
            </div>
            
            <div className="text-primary-shade-9 text-captionMd mt-[-5px]">
              Admin
            </div>
          </div>
          
          <Image priority src={ downOutlined } alt="" className="--downIcon" />
        </Space>
      </Space>
    </Dropdown>
  );
};

export default Profile;
