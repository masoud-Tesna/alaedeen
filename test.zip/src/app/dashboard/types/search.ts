import { InputProps } from 'antd';

export type TSearchProps = InputProps & {
  iconAs?: 'prefix' | 'suffix'
}