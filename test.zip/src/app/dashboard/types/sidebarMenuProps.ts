import { Session } from 'next-auth';

export type SidebarMenuProps = {
  collapsed: boolean,
  role: Session['user']['role'] | undefined
}