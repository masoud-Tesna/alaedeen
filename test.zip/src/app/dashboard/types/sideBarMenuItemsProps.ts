export type SideBarMenuItemsProps = {
  collapsed: boolean,
  role: 'admin' | 'customer'
}