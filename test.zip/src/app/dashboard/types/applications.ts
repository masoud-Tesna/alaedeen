import { Key, ReactNode } from 'react';

export type TTableData = {
  key: Key,
  logo: ReactNode,
  applicationName: string,
  ip: string,
  level: string,
  status: string,
  token: string
}