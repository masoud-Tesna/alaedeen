import { ReactNode } from 'react';
import { Session } from 'next-auth';
import { MenuItemType } from 'antd/lib/menu/hooks/useItems';

export type MenuItems = Omit<MenuItemType, 'icon'> & {
  icon?: (collapsed: boolean) => ReactNode,
  link: string,
  breadCrumbItems?: MenuItems[],
  for?: (Session['user']['role'] | undefined)[]
}