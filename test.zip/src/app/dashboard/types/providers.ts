export type TProvidersListProps = {
  status: boolean
}