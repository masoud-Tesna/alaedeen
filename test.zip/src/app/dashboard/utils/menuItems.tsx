import { MenuItems } from '@/app/dashboard/types/menuItems';
import Image from 'next/image';

// menu icons
import categoryOutlines from '/public/icons/categoryOutlines.svg';
import programmingArrowOutlined from '/public/icons/programmingArrowOutlined.svg';
import documentCodeOutlined from '/public/icons/documentCodeOutlined.svg';
import convertCardOutlined from '/public/icons/convertCardOutlined.svg';
import dataOutlined from '/public/icons/dataOutlined.svg';
import receiptTextOutlined from '/public/icons/receiptTextOutlined.svg';
import profile2UserOutlined from '/public/icons/profile2UserOutlined.svg';
import levelOutlined from '/public/icons/levelOutlined.svg';
import layerOutlined from '/public/icons/layerOutlined.svg';
import textAlignJustifyCenterFilled from '/public/icons/textAlignJustifyCenterFilled.svg';

export const menuItems: MenuItems[] = [
  {
    key: 'dashboard',
    label: 'داشبورد',
    icon: (collapsed) => <Image priority src={ categoryOutlines } alt="" width={ collapsed ? 28 : 24 } />,
    link: '/dashboard',
    for: [ 'admin', 'customer' ]
  },
  {
    key: 'applications',
    label: 'مدیریت اپلیکیشن‌ها',
    icon: (collapsed) => <Image priority src={ layerOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '/dashboard/applications',
    for: [ 'admin', 'customer' ],
    breadCrumbItems: [
      {
        key: 'application-list',
        label: 'لیست اپلیکیشن‌ها',
        link: '/dashboard/applications/list'
      }
    ]
  },
  {
    key: 'services',
    label: 'سرویس‌ها',
    icon: (collapsed) => <Image priority src={ programmingArrowOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '/dashboard/services',
    for: [ 'admin', 'customer' ]
  },
  {
    key: 'logs',
    label: 'گزارش‌ها',
    icon: (collapsed) => <Image priority src={ receiptTextOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '/dashboard/logs',
    for: [ 'admin', 'customer' ]
  },
  {
    key: 'apis',
    label: 'مدیریت API ها',
    icon: (collapsed) => <Image priority src={ documentCodeOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '',
    for: [ 'admin' ]
  },
  {
    key: 'providers',
    label: 'پروایدرها',
    icon: (collapsed) => <Image priority src={ convertCardOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '/dashboard/providers',
    for: [ 'admin' ],
    breadCrumbItems: [
      {
        key: 'providers-list',
        label: 'لیست پروایدرها',
        link: '/dashboard/providers/list'
      },
      {
        key: 'create-provider',
        label: 'ساخت پروایدر',
        link: '/dashboard/providers/create'
      }
    ]
  },
  {
    key: 'categories',
    label: 'دسته بندی سرویس ها‌',
    icon: (collapsed) => <Image priority src={ dataOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '',
    for: [ 'admin' ]
  },
  {
    key: 'customers',
    label: 'کاربران',
    icon: (collapsed) => <Image priority src={ profile2UserOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '',
    for: [ 'admin' ]
  },
  {
    key: 'levels',
    label: 'سطح بندی',
    icon: (collapsed) => <Image priority src={ levelOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '',
    for: [ 'admin' ]
  },
  {
    key: 'levels',
    label: 'اپ‌های پیشرفته',
    icon: (collapsed) => <Image priority src={ layerOutlined } alt="" width={ collapsed ? 28 : 24 } />,
    link: '',
    for: [ 'admin' ]
  },
  {
    key: 'pending',
    label: 'در انتظار دسترسی',
    icon: (collapsed) => <Image priority src={ textAlignJustifyCenterFilled } alt="" width={ collapsed ? 28 : 24 } />,
    link: '',
    for: [ 'admin' ]
  }
];

export function findMenuItemByLink(menuItems: MenuItems[], link: string): MenuItems | null {
  const foundMenuItem = menuItems.find(item => item.link === link);
  
  if (foundMenuItem) {
    return foundMenuItem;
  }
  
  for (const menuItem of menuItems) {
    if (menuItem.breadCrumbItems) {
      const found = findMenuItemByLink(menuItem?.breadCrumbItems, link);
      if (found) {
        return found;
      }
    }
  }
  
  return null;
}

function find(t: MenuItems[], func: (node: MenuItems) => boolean): MenuItems[][] {
  let result: MenuItems[][] = [];
  
  for (const node of t) {
    if (func(node)) {
      result.push([ node ]);
    }
    
    if (node.breadCrumbItems) {
      const childResult = find(node?.breadCrumbItems, func);
      if (childResult?.length > 0) {
        result?.push([ node, ...childResult[ 0 ] ]);
      }
    }
  }
  
  return result;
}

export function findMenuItemsByLink(t: MenuItems[], link: MenuItems['link']): MenuItems[] {
  const result = find(t, (node) => node?.link === link);
  return result?.length > 0 ? result[ 0 ] : [];
}
