'use client';

import { FC } from 'react';
import { Table as AntdTable, Typography } from 'antd';
import { ColumnsType } from 'antd/es/table';
import Image from 'next/image';
import { truncatedMiddleText } from '@/utils/helpers';
import { request } from '@/utils/useRequest';
import { TApplication, TApplications } from '@/libs/schema';
import baseURL from '@/utils/axios/baseURL';
import { CopySuccessOutlined, TickSquareFilled } from '@/templates/icons';

const Table: FC = () => {
  
  const { data: applicationsData, isPending } = request.useQuery<{ applications: TApplications }>({
    url: '/user/applications',
    queryKey: [ 'user', 'applications' ]
  });
  
  const applications = applicationsData?.data?.applications || [];
  
  const columns: ColumnsType<TApplication> = [
    {
      title: 'تصویر لوگو',
      align: 'center',
      key: 'logoURL',
      dataIndex: 'logoURL',
      render: (logoURL) => (
        <Image src={ baseURL?._serviceURL + logoURL } alt="" width={ 38 } height={ 38 } />
      )
    },
    {
      title: 'نام اپلیکیشن',
      dataIndex: 'name',
      align: 'center',
      key: 'name'
    },
    {
      title: 'آدرس IP',
      dataIndex: 'ip',
      align: 'center',
      key: 'ip',
      render: () => '---'
    },
    {
      title: 'سطح',
      dataIndex: 'levels',
      align: 'center',
      key: 'levels',
      render: (levels) => (levels[ 0 ]?.type)
    },
    {
      title: 'وضعیت',
      dataIndex: 'isActive',
      align: 'center',
      key: 'isActive',
      render: (isActive) => isActive ? 'فعال' : 'غیر فعال'
    },
    {
      title: 'توکن',
      align: 'center',
      key: 'token',
      render: (_, { token }) => (
        <Typography.Paragraph
          copyable={ {
            icon: [
              <CopySuccessOutlined
                key="CopySuccessOutlined"
                className="!text-primary-shade-9 text-[20px] !align-middle"
              />,
              <TickSquareFilled key="TickSquareFilled" className="!text-primary-shade-9 text-[20px] !align-middle" />
            ],
            text: token
          } }
          className="!text-primary-shade-9 !text-bodySm !m-0"
        >
          { truncatedMiddleText({ text: token }) }
        </Typography.Paragraph>
      )
    }
  ];
  
  /*const dataFromApi = [
    {
      '_id': '656de3183622981f618ccf22',
      'userId': '656de30a3622981f618ccf1d',
      'name': 'sdasdsd',
      'logoURL': '/public/uploads/7692d306cfdda1a6b673d6df7e6f5f9e.png',
      'isActive': true,
      'levels': [
        {
          'type': 'general',
          'title': 'medium-business',
          'price': 6000000,
          'ratelimits': [
            {
              'dimension': 'second',
              'count': 1,
              'limit': 40,
              '_id': '656de31e3622981f618ccf3a'
            },
            {
              'dimension': 'minute',
              'count': 1,
              'limit': 600,
              '_id': '656de31e3622981f618ccf3b'
            },
            {
              'dimension': 'day',
              'count': 1,
              'limit': 4000,
              '_id': '656de31e3622981f618ccf3c'
            }
          ],
          'selectionDate': 1701700382168,
          '_id': '6562ed652172723242c2bd66'
        }
      ],
      'createdAt': '2023-12-04T14:32:56.813Z',
      'updatedAt': '2023-12-04T14:33:02.168Z',
      '__v': 0,
      'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY1NmRlMzE4MzYyMjk4MWY2MThjY2YyMiIsImlhdCI6MTcwMTcwMDM3Nn0.-c6USSlw2b_aCMThozEEv2UUlMuXLN9MH4jrnlitYDA'
    }
  ];
  
  const applicationsZod = ApplicationsZod.parse(dataFromApi);*/
  
  return <AntdTable
    loading={ isPending }
    columns={ columns }
    dataSource={ applications }
    pagination={ false }
    bordered={ false }
  />;
};

export default Table;
