import { FC } from 'react';
import Table from '@/app/dashboard/(pages)/applications/list/components/Table';
import CurrentPageDetails from '@/app/dashboard/components/CurrentPageDetails';

const ApplicationsList: FC = () => {
  return (
    <>
      <CurrentPageDetails />
      
      <div className="bg-neutral-white border-[.3px] border-solid border-neutral-gray-8 rounded-[2px] shadow-8 py-[42px] px-[1.5%]">
        <Table />
      </div>
    </>
  );
};

export default ApplicationsList;
