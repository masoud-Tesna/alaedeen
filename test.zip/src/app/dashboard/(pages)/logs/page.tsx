import { FC } from 'react';

const Logs: FC = () => {
  return (
    <div>
      logs page
    </div>
  );
};

export default Logs;
