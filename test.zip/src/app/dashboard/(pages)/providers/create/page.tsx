import { FC } from 'react';
import List from '@/app/dashboard/(pages)/providers/list/components/List';

const ProvidersList: FC = () => {
  return <List />;
};

export default ProvidersList;
