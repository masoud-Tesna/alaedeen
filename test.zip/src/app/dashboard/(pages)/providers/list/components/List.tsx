'use client';

import { FC } from 'react';
import { Button, Space } from 'antd';
import { TProvidersListProps } from '@/app/dashboard/types/providers';
import classNames from 'classnames';
import { motion } from 'framer-motion';
import CurrentPageDetails from '@/app/dashboard/components/CurrentPageDetails';
import Search from '@/app/dashboard/components/Search';
import { AddCircleOutlined, DotCircleFilled, FilterSearchOutlined } from '@/templates/icons';
import { useRouter } from 'next/navigation';

const List: FC = () => {
  const router = useRouter();
  
  return (
    <>
      <CurrentPageDetails>
        <div className="flex gap-x-8 justify-end">
          <div className="w-[55.555555556%]">
            <Search iconAs="suffix" placeholder="جستجو..." />
          </div>
          
          <div className="w-[42px] h-[42px] flex justify-center align-middle bg-primary-shade-9 rounded-4 cursor-pointer">
            <FilterSearchOutlined className="text-[24px] !text-blue-light" />
          </div>
          
          <div className="w-[33.333333333%]">
            <Button
              block
              type="primary"
              icon={ <AddCircleOutlined className="text-[16px] !text-neutral-white !align-middle" /> }
              onClick={ () => router.push('/dashboard/providers/create') }
            >
              ساخت پروایدر جدید
            </Button>
          </div>
        </div>
      </CurrentPageDetails>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-16">
        { Array.from({ length: 10 }).map((_, i) => (
          <motion.div
            whileHover={ { scale: 1.03 } }
            whileTap={ { scale: .99 } }
            className="cursor-pointer bg-neutral-white border-[.3px] border-solid border-neutral-gray-8 py-32 px-[15%] rounded-4 text-center select-none shadow-8"
            key={ i }
          >
            <Box status={ ![ 2, 5, 8 ].includes(i) } />
          </motion.div>
        )) }
      </div>
    </>
  );
};

const Box: FC<TProvidersListProps> = ({ status }) => {
  return (
    <div className={ classNames('flex justify-between items-stretch', { 'opacity-30': !status }) }>
      <div>
        <Space direction="vertical" size={ 48 }>
          <div className="text-primary-shade-8 text-h5">
            فرابوم
          </div>
          
          <Space className="!text-primary-0 text-captionMd">
            <DotCircleFilled className="text-[10px] !align-middle" />
            
            { status ? 'فعال' : 'غیر فعال' }
          </Space>
        </Space>
      </div>
      
      <div className="ps-48 border-solid border-0 border-s border-neutral-gray-2">
        <div className="h-full flex items-center">
          <Space direction="vertical" className="!flex align-middle">
            <div className="text-primary-0 text-h3">
              123
            </div>
            
            <div className="text-neutral-gray-4 text-captionMd">
              وب سرویس
            </div>
          </Space>
        </div>
      </div>
    </div>
  );
};

export default List;
