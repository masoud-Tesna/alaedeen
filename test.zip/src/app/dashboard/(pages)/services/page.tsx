import { FC } from 'react';

const Dashboard: FC = () => {
  return (
    <div>
      services page
    </div>
  );
};

export default Dashboard;
