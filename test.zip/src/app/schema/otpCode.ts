import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';

export const OtpCodeZod = z.string({ required_error: setInputRule('requiredInput', { inputName: 'رمز یکبار مصرف' }) })
.length(6, setInputRule('minLength', { inputName: 'رمز یکبار مصرف', length: 6 })
);

export type TOtpCode = z.infer<typeof OtpCodeZod>;