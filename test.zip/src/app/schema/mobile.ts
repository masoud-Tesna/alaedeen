import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';

export const MobileZod = z.string({ required_error: setInputRule('requiredInput', { inputName: 'شماره موبایل' }) })
.length(11, setInputRule('minLength', { inputName: 'شماره موبایل', length: 11 }))
.startsWith('09', setInputRule('mobileStartWith'));

export type TMobile = z.infer<typeof MobileZod>;
