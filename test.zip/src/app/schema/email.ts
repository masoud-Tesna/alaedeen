import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';

export const EmailZod = z.string({ required_error: setInputRule('requiredInput', { inputName: 'آدرس ایمیل' }) })
.email({ message: setInputRule('invalidEmail') });

export type TEmail = z.infer<typeof EmailZod>;