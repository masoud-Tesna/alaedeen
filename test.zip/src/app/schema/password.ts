import { z } from 'zod';
import { setInputRule } from '@/utils/helpers';

export const PasswordZod = z.string({ required_error: setInputRule('requiredInput', { inputName: 'رمز عبور' }) }).regex(
  /[A-Z]/,
  'رمز عبور باید حداقل شامل یک حرف بزرگ انگلیسی باشد'
).regex(/[1-9]/, 'رمز عبور باید حداقل شامل یک عدد باشد').min(
  8,
  setInputRule('minLength', { inputName: 'رمز عبور', length: 8 })
);

export type TPassword = z.infer<typeof PasswordZod>;