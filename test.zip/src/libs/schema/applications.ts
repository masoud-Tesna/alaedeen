import { z } from 'zod';
import { LevelsZod } from '@/app/auth/createApp/schema';

export const ApplicationZod = z.object({
  _id: z.string(),
  isActive: z.boolean(),
  levels: LevelsZod,
  logoURL: z.string(),
  name: z.string(),
  token: z.string()
});

export const ApplicationsZod = z.array(ApplicationZod);

export type TApplication = z.infer<typeof ApplicationZod>;

export type TApplications = z.infer<typeof ApplicationsZod>;