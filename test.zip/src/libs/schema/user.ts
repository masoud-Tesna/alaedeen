import { z } from 'zod';
import { ApplicationsZod } from './applications';

export const UserDetailsZod = z.object({
  accessToken: z.string(),
  role: z.enum([ 'customer', 'admin' ]),
  hasApplication: z.boolean()
});

export type TUserDetails = z.infer<typeof UserDetailsZod>;

