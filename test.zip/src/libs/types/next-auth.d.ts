import NextAuth from 'next-auth';
import { TUserDetails } from '@/libs/schema';

declare module 'next-auth' {
  interface Session {
    user: TUserDetails;
  }
}

declare module 'next-auth/jwt' {
  /** Returned by the `jwt` callback and `getToken`, when using JWT sessions */
  interface JWT extends TUserDetails {
  }
}
