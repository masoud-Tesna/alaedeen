import NextAuth, { AuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import axiosInterceptors from '@/utils/axios/axiosInterceptors';
import { CustomerInformationZod } from '@/app/auth/register/schema';
import { UserDetailsZod } from '@/libs/schema';

export const authOptions: AuthOptions = {
  providers: [
    CredentialsProvider({
      type: 'credentials',
      id: 'loginProvider',
      name: 'loginProvider',
      credentials: {
        email: { label: 'email', type: 'text', placeholder: 'email@.com' },
        password: { label: 'password', type: 'password' }
      },
      async authorize(credentials) {
        try {
          const res = await axiosInterceptors({
            url: '/auth/login',
            method: 'post',
            data: {
              email: credentials?.email,
              password: credentials?.password
            }
          });
          
          const response = res?.data;
          
          if (!response?.data?.accessToken) {
            return Promise.reject(new Error(response?.message));
          }
          
          return Promise.resolve(response?.data);
        }
        catch (error) {
          if (error instanceof Error) {
            return Promise.reject(new Error(error?.message));
          }
          return Promise.reject(error);
        }
      }
    }),
    CredentialsProvider({
      type: 'credentials',
      id: 'registerProvider',
      name: 'registerProvider',
      credentials: {},
      async authorize(credentials) {
        try {
          const data = CustomerInformationZod.parse(credentials);
          
          const res = await axiosInterceptors({
            url: '/auth/register',
            method: 'post',
            data
          });
          
          const response = res?.data;
          
          if (!response?.isSuccess) {
            return Promise.reject(new Error(response?.message));
          }
          response.data.hasApplication = false;
          
          return Promise.resolve(response?.data);
        }
        
        catch (error) {
          if (error instanceof Error) {
            return Promise.reject(new Error(error?.message));
          }
          return Promise.reject(error);
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user, trigger, session }) {
      // console.log('in jwt >>>', { token, user, trigger, session });
      
      if (trigger === 'update') {
        token = {
          ...token,
          ...session
        };
      }
      
      return { ...user, ...token };
    },
    async session({ session, token, user }) {
      const userDetailsZod = UserDetailsZod.parse(token);
      
      return { ...session, user: userDetailsZod };
    }
  },
  pages: {
    signIn: '/auth/login'
  },
  session: { strategy: 'jwt' }
};

export const handler = NextAuth(authOptions);