export const useLocalStorage = {
  set: (key: string, value: string) => localStorage.setItem(key, value),
  get: (key: string) => localStorage.getItem(key),
  removeItem: (key: string) => localStorage.removeItem(key),
  clear: () => localStorage.clear(),
  setRegisterStep: (value: object, currentStep: number) => {
    localStorage.setItem('registerFields', JSON.stringify({ ...value, password: null }));
    localStorage.setItem('registerStep', currentStep.toString());
  },
  removeRegisterStep: () => {
    localStorage.removeItem('registerFields');
    localStorage.removeItem('registerStep');
  }
};