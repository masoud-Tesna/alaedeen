import { z, ZodRawShape } from 'zod';
import { useCallback } from 'react';
import { FormInstance, FormRule } from 'antd';

type AntdFormZodSchema<T extends ZodRawShape> =
  | z.ZodObject<T>
  | z.ZodEffects<z.ZodObject<T>>;

export const useCreateAntdZodValidation = <T extends ZodRawShape>(schema: AntdFormZodSchema<T>) => useCallback(
  ({ getFieldsValue }: FormInstance) => ({
    validator: async ({ field }: any) => {
      const values = getFieldsValue();
      const fieldValue = !!values[ field ]?.length ? values[ field ] : undefined;
      
      const result = await schema.safeParseAsync({ [ field ]: fieldValue });
      const error = !result.success && result.error.issues.filter(issue => issue.path.includes(field))[ 0 ]?.message;
      
      return error ? Promise.reject(error) : Promise.resolve();
    }
  }),
  [ schema ]
) as FormRule;

/*export const useCreateAntdZodValidation2 = <T extends ZodRawShape>(schema: AntdFormZodSchema<T>): FormRule => {
  return {
    validator: async ({ field }, value) => {
      const fieldValue = !!value?.length ? value : undefined;
      const result = await schema.safeParseAsync({ [ field ]: fieldValue });
      if (result.success) return Promise.resolve();
      
      const issues = result.error.issues.filter((issue) => issue.path[ 0 ] == field);
      
      const message = issues[ 0 ]?.message;
      if (message) return Promise.reject(new Error(message));
    }
  };
};*/
