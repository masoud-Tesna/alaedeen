type TruncatedMiddleText = {
  text: string,
  startLength?: number,
  endLength?: number
}

export const truncatedMiddleText = ({ text, startLength = 5, endLength = 15 }: TruncatedMiddleText) => {
  const startWords = text.trim().slice(0, startLength);
  const middleDots = '...';
  const endWords = text.trim().slice(text?.length - endLength, text?.length);
  
  return startWords + ' ' + middleDots + ' ' + endWords;
};
