// scroll to top window
export const scrollTop = () => window.scroll({
  top: 0,
  behavior: 'smooth'
});
