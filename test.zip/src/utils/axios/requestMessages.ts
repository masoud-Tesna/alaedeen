import { RequestMessages } from '@/utils/axios/types/requestMessages';

export const requestMessages: RequestMessages[] = [
  {
    en: 'otp already has been sent',
    fa: 'کد احراز هویت قبلا به ایمیل شما ارسال شده است',
    type: 'warning'
  },
  {
    en: 'otp sent successfully',
    fa: 'کد احراز هویت به ایمیل شما ارسال شد',
    type: 'success'
  },
  {
    en: 'logged in successfully',
    fa: 'ورود با موفقیت انجام شد',
    type: 'success'
  },
  {
    en: 'invalid credentials',
    fa: 'اطلاعات ورودی اشتباه است',
    type: 'error'
  },
  {
    en: 'duplicate email',
    fa: 'ایمیل تکراری است',
    type: 'warning'
  },
  {
    en: 'otp token is expired',
    fa: ' زمان مجاز ثبت نام شما به پایان رسیده است',
    type: 'warning'
  },
  {
    en: 'invalid OTP code',
    fa: 'کد احراز هویت نامعتبر است',
    type: 'error'
  },
  {
    en: 'otp done successfully',
    fa: 'احراز هویت با موفقیت انجام شد',
    type: 'success'
  },
  {
    en: 'registered successfully',
    fa: 'ثبت نام با موفقیت انجام شد',
    type: 'success'
  },
  {
    en: 'duplicate app name',
    fa: 'نام اپلیکیشن تکراری است',
    type: 'error'
  },
  {
    en: 'application created successfully',
    fa: 'اپلیکیشن شما با موفقیت ایجاد شد',
    type: 'success'
  },
  {
    en: 'application level updated',
    fa: '...',
    type: 'success'
  }
];