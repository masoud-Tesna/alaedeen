import { TypeOptions } from 'react-toastify';

export type RequestMessages = {
  en: string,
  fa: string,
  type: TypeOptions
}