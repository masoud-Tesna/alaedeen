import axiosInterceptors from '@/utils/axios/axiosInterceptors';
import { AxiosRequestConfig } from 'axios';

export const requestApi = async <TResponse>({
  url,
  method = 'post',
  data,
  params,
  headers,
  ...rest
}: AxiosRequestConfig): Promise<TResponse> => {
  const result = await axiosInterceptors.request(
    {
      method,
      url,
      params,
      data,
      headers,
      ...rest
    }
  );
  
  return result?.data;
};