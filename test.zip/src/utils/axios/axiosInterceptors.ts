import axios, { AxiosError, AxiosResponse } from 'axios';
import baseURL from './baseURL';
import { getSession, signOut } from 'next-auth/react';

// create axios instance
const axiosInterceptors = axios.create({
  baseURL: baseURL?._serviceURL, // default base url
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json'
  }
});

axiosInterceptors.interceptors.request.use(
  async (config) => {
    const session = await getSession();
    
    if (session?.user?.accessToken) {
      config.headers.Authorization = config.headers.Authorization || `Bearer ${ session?.user?.accessToken }`;
    }
    
    return config;
  },
  async (error: AxiosError): Promise<never> => {
    return Promise.reject(error);
  }
);

axiosInterceptors.interceptors.response.use(
  async (response: AxiosResponse): Promise<AxiosResponse> => {
    if (response?.data?.isSuccess) {
      return Promise.resolve(response);
    }
    else {
      return Promise.reject(response?.data);
    }
  },
  async (error: AxiosError | any): Promise<AxiosError> => {
    if (error?.response?.status === 401) {
      await signOut();
      
      return Promise.reject(error?.response?.data);
    }
    
    return Promise.reject(error?.response?.data);
  }
);

export default axiosInterceptors;
