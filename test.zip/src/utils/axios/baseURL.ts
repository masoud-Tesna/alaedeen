type BaseUrlType = {
    _baseURL: string,
    _serviceURL: string
}

const baseURL: BaseUrlType = {
    _baseURL: process.env.NEXT_PUBLIC_APP_BACKEND_URL as string,

    _serviceURL: process.env.NEXT_PUBLIC_APP_BACKEND_URL as string
};

export default baseURL;
