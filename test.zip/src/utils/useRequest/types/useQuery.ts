import { TRequest, TDefaultResponse } from '@/utils/useRequest/types/common';
import { UndefinedInitialDataOptions } from '@tanstack/react-query';

export interface TUseQuery<TResponse> extends TRequest, UndefinedInitialDataOptions<TDefaultResponse<TResponse>> {
  body?: object,
}