import { Method, RawAxiosRequestHeaders } from 'axios';
import { z } from 'zod';

export interface TRequest {
  // API url
  url?: string,
  params?: object,
  method?: Method,
  customRequestHeader?: RawAxiosRequestHeaders
}

export type TDefaultResponse<T> = {
  isSuccess: boolean,
  message: string,
  data?: T
}
