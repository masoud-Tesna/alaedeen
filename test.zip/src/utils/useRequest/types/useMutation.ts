import { UseMutationOptions } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { TDefaultResponse, TRequest } from '@/utils/useRequest/types/common';

export interface TUseMutation<TBody, TResponse> extends TRequest, UseMutationOptions<TDefaultResponse<TResponse>, AxiosError | Error, TBody> {
  // show message in mutation request or not (true by default)
  showMessage?: boolean | {
    success?: boolean
    error?: boolean
  },
  // mutation request custom message for success
  customSuccessMessage?: string,
  // mutation request custom message for error
  customErrorMessage?: string,
}