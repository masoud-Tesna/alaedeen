export type THandleOnSettled = {
  toastType: 'error' | 'success',
  toastId: string,
  message?: string
  customMessage?: string
};
