import { useQuery as customUseQuery } from '@/utils/useRequest/useQuery';
import { useMutation as customUseMutation } from '@/utils/useRequest/useMutation';

export namespace request {
  export const useQuery = customUseQuery;
  export const useMutation = customUseMutation;
}
