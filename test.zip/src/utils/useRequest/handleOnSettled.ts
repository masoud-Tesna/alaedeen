import { requestMessages } from '@/utils/axios/requestMessages';
import { toast } from 'react-toastify';
import { THandleOnSettled } from '@/utils/useRequest/types/handleOnSettled';

export const handleOnSettled = ({
  toastType,
  message,
  toastId,
  customMessage
}: THandleOnSettled) => {
  const findMessage = requestMessages.find(item => item?.en === message);
  
  const toastCustomMessage = toastType == 'success' ? 'عملیات با موفقیت انجام شد' : 'خطای ارائه دهنده';
  
  toast(customMessage || findMessage?.fa || (process.env.NODE_ENV === 'development' ?
    message : toastCustomMessage), {
    toastId,
    type: findMessage?.type || toastType
  });
};