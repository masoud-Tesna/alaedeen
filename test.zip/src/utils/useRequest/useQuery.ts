import { useQuery as tanstackUseQuery } from '@tanstack/react-query';
import { requestApi } from '@/utils/axios/requestApi';
import { AxiosResponse } from 'axios';
import { TUseQuery } from '@/utils/useRequest/types/useQuery';
import { TDefaultResponse } from '@/utils/useRequest/types/common';

export const useQuery = <TResponse = AxiosResponse['data']>(
  {
    method = 'get',
    queryKey = [],
    ...rest
  }: TUseQuery<TResponse>
) => {
  return tanstackUseQuery({
    queryKey,
    queryFn: () => requestApi<TDefaultResponse<TResponse>>({
      url: rest?.url,
      method,
      params: rest?.params,
      data: rest?.body,
      headers: rest?.customRequestHeader
    }),
    refetchOnWindowFocus: false,
    retry: 2,
    ...rest
  });
};
