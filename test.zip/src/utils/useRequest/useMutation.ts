import { useMutation as useTanstackMutation } from '@tanstack/react-query';
import { AxiosResponse } from 'axios';
import { requestApi } from '@/utils/axios/requestApi';
import { TUseMutation } from '@/utils/useRequest/types/useMutation';
import { TDefaultResponse } from '@/utils/useRequest/types/common';
import { handleOnSettled } from '@/utils/useRequest/handleOnSettled';

export const useMutation = <TBody, TResponse = AxiosResponse['data']>(
  {
    url,
    params = {},
    method = 'post',
    showMessage = true,
    customSuccessMessage,
    customErrorMessage,
    customRequestHeader,
    ...rest
  }: TUseMutation<TBody, TResponse>
) => {
  
  let requestMessage: {
    success: boolean,
    error: boolean
  } = {
    success: true,
    error: true
  };
  
  if (typeof showMessage === 'boolean') {
    requestMessage = {
      success: showMessage,
      error: showMessage
    };
  }
  else {
    requestMessage = {
      ...requestMessage,
      ...showMessage
    };
  }
  
  return useTanstackMutation({
    mutationFn: (request: TBody) => requestApi<TDefaultResponse<TResponse>>({
      url,
      method,
      params,
      data: request,
      headers: customRequestHeader
    }),
    onSettled: (response, error) => {
      if (response?.isSuccess) {
        if (!!requestMessage?.success) {
          handleOnSettled({
            toastType: 'success',
            toastId: `mutationRequestSuccess/${ url }`,
            customMessage: customSuccessMessage,
            message: response?.message
          });
        }
      }
      else {
        if (!!requestMessage?.error) {
          handleOnSettled({
            toastType: 'error',
            toastId: `mutationRequestError/${ url }`,
            customMessage: customErrorMessage,
            message: error?.message
          });
        }
      }
    },
    retry: false,
    ...rest
  });
};
